//�߼������򿪹ر�
function search_open(obj , divid){
	alert("in it");
	if (!obj.attr('opened')){
		obj.attr('opened' , 'close');
	}
	obj.bind("click", function(){
		if (obj.attr('opened') == 'close'){
			alert("in ");
			divid.fadeIn();
			obj.find('span').removeClass('imgbtn_search_open').addClass('imgbtn_search_close')
			obj.attr('opened' , 'open')
		}else{
			alert("out");
			divid.slideUp();
			obj.find('span').removeClass('imgbtn_search_close').addClass('imgbtn_search_open');
			obj.attr('opened' , 'close')
		}
	});
} 

//输入提示搜索框
function input_open(obj , divid){

	if (!obj.attr('opened')){
		obj.attr('opened' , 'close');
	}
	obj.bind("click", function(){
		if (obj.attr('opened') == 'close'){
			divid.fadeIn();
			obj.find('span').removeClass('imgbtn_search_open').addClass('imgbtn_search_close')
			obj.attr('opened' , 'open')
		}else{

			divid.slideUp();
			obj.find('span').removeClass('imgbtn_search_close').addClass('imgbtn_search_open');
			obj.attr('opened' , 'close')
		}
	});
} 
//����ɹ�������ʾ
function openPrivacyLayer(layerID){  

	var top1;  
	var left1;  
	var diffY;  
	if (document.documentElement && document.documentElement.scrollTop)  
	{  
		diffY = document.documentElement.scrollTop;  
		left1 = document.documentElement.scrollLeft;  
		}  
	else if (document.body){  
		diffY = document.body.scrollTop;  
		left1 = document.body.scrollLeft;  
	}  
	else  
		{ }  
	var privacyLayer = $('#'+layerID);  
	var xWidth = privacyLayer.width(); 
	var xHeight = privacyLayer.height();  
	if (xWidth == 'null' || xWidth == '')  
	{  
		xWidth = window.getComputedStyle(privacyLayer,null).style.width;  
		xHeight = window.getComputedStyle(privacyLayer,null).style.width;  
	} 
	privacyLayer.css('display' , 'block')
	privacyLayer.css('left' , left1+((window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body.offsetWidth)-xWidth)/2+'px');
	privacyLayer.css('top' , diffY + ((window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body.offsetHeight)-xHeight)/7+'px');

}

function closePrivacy(layerID){  
	$('#'+layerID).fadeOut(500);
} 

function saveOkTip(msg , clicked , btnID){
	$('body').append('<div class="saveOkTip" id="' + clicked + '">' + msg + '</div>')
	openPrivacyLayer(clicked);
	if (clicked == 'btn'){
		$('#'+btnID).removeAttr('onclick');
		$('#'+btnID).css('color' , 'C3C3C3');
	}
	if (clicked == 'on_load'){
		setTimeout("closePrivacy('on_load')",700);
	}
}

//tooltip
;(function($){
    jQuery.fn.extend({
        showTip:function(settings)
        {
            $(this).each(function(){
                //��ʼ��������Ϣ
                var options = jQuery.extend({
                    flagCss:"tip",
                    flagWidth:$(this).outerWidth(),
                    flagInfo:$(this).attr("title"),
                    isAnimate:false
                },
                settings);
                if(!options.flagInfo)
                {
                    return;
                }
                $(this).removeAttr("title");
                $(this).mouseover(function(){
                    //������ʾ��Ϣ��С���Ϊ163
                    options.flagWidth = (parseInt(options.flagWidth) < 100) ? 163 : parseInt(options.flagWidth);
                    var oTip = $("<div class='ui-slider-tooltip  ui-corner-all'></div>");
                    var oPointer = $("<div class='ui-tooltip-pointer-down'><div class='ui-tooltip-pointer-down-inner'></div></div>");
                    var oTipInfo = $("<div>" + options.flagInfo + "</div>").attr("class",options.flagCss).css("width",options.flagWidth + "px");
                    //�ϲ���ʾ��Ϣ
                    var oToolTip = $(oTip).append(oTipInfo).append(oPointer);
                    //��ӵ���Ч��
                    if(options.isAnimate)
                    {
                        $(oToolTip).fadeIn(500);
                    }
                    $(this).after(oToolTip);
                    
                    //������ʾ��Ϣ��top��left��width
                    var position = $(this).position();
                    var oTipTop = eval(position.top + $(oTip).outerHeight() - 12);
                    var oTipLeft = position.left - 21;
                    $(oToolTip).css("top" , oTipTop + "px").css("left" , oTipLeft + "px");
                    
                    $(this).mouseout(function(){
                        $(oToolTip).remove();
                    });
                });
            });
            return this;
        }
    })
})(jQuery);
 