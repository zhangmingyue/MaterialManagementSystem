 //document.onkeydown = forceKeyInput;
 var ControlUtils = {
	getValue : function(id){
		var control = document.getElementById(id);
		
		switch(control.type){
			case "text":							
				return control.value;								
			case "select-one":
				return control.options[control.selectedIndex].value;
				break;
			case "select-multiple":								
				return control.options[control.selectedIndex].value;
				break;				
			case "hidden":								
				return control.value;
				break;
			case "file":
				return control.value;
			default:
				alert(control.type);
				alert("control type is not correct ,suggest see source code!");
			
		}
	},
	getValues : function(id){
				
	},
	getText : function(id){
		var control = document.getElementById(id);
		
		switch(control.type){
			case "text":							
				return control.value;
			case "select-one":
				return control.options[control.selectedIndex].text;
				break;
			case "hidden":								
				return control.value;
				break;
			default:
				alert("control type is not correct ,suggest see source code!");
			
		}
	},
	getControl: function(id){
		var control = document.getElementById(id);		
		if(control==null){
			control = document.getElementsByName(id);
		}
		return control;
	},
	getControlByName: function(name){
		var control = document.getElementsByName(name);
		return control;
	}
	
}