package com.igd.base.page;

public class Pager {
	private int currentPage = 1;
	private int totalSize ;
	private int pageSize ;
	private int totalPage ;
	private boolean hasFirst;
	private boolean hasPervious;
	private boolean hasNext;
	private boolean hasLast;
	
	public Pager(int currentPage,int totalSize,int pageSize){
		if(currentPage*pageSize-totalSize>pageSize){
			this.currentPage = 1;
			this.totalSize = totalSize;
			this.pageSize = pageSize;
		}else{
			this.currentPage = currentPage;
			this.totalSize = totalSize;
			this.pageSize = pageSize;
		}
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(int totalSize) {
		this.totalSize = totalSize;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalPage() {
		this.totalPage = this.totalSize / this.pageSize ;
		if(this.totalSize % this.pageSize != 0){
			this.totalPage++;
		}
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public boolean isHasFirst() {
		if(this.currentPage == 1) return false;
		return hasFirst;
	}

	public void setHasFirst(boolean hasFirst) {
		this.hasFirst = hasFirst;
	}

	public boolean isHasPervious() {
		if(this.isHasFirst()) return true;
		return false;
	}

	public void setHasPervious(boolean hasPervious) {
		this.hasPervious = hasPervious;
	}

	public boolean isHasNext() {
		if(this.isHasLast()) return true;
		return false;
	}

	public void setHasNext(boolean hasNext) {
		this.hasNext = hasNext;
	}

	public boolean isHasLast() {
		if(this.currentPage == this.getTotalPage()) return false;
		return true;
	}

	public void setHasLast(boolean hasLast) {
		this.hasLast = hasLast;
	}
}
