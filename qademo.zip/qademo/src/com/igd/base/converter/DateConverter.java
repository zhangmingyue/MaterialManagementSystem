package com.igd.base.converter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.struts2.StrutsException;
import org.apache.struts2.util.StrutsTypeConverter;

public class DateConverter extends StrutsTypeConverter {


	public Object convertFromString(Map context, String[] values, Class toClass) {
		return doConvertToDate(values[0]);
	}

	public String convertToString(Map context, Object o) {
		String result = null;
		DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		if (o instanceof Date) {
			result = format1.format(o);
		}
		return result;
	}

	private Date doConvertToDate(Object value) {
		Date result = null;
		DateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
		if (value instanceof String) {
			try {
				//空处理
				if("".equals((String)value.toString().trim())) 
					return result;
				
				result = format2.parse((String) value);
			} catch (ParseException e) {
				throw new StrutsException("不能转换日期类型", e);
			}
		}
		return result;
	}
}
