package com.igd.base.converter;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.struts2.StrutsException;
import org.apache.struts2.util.StrutsTypeConverter;

import com.igd.base.utils.date.SqlDateUtils;

public class TimestampConverter extends StrutsTypeConverter {

	
	public Object convertFromString(Map context, String[] values, Class toClass) {
	        return doConvertToDate(values[0]);
	}
	public String convertToString(Map context, Object o) {
	        String result = null;	    
	        if (o instanceof Timestamp) {
	            result = SqlDateUtils.getTimestamp_YMDHMS((Timestamp)o);
	        }
	        return result;
	}
	
	private Date doConvertToDate(Object value) {
	        Date result = null;
	        if (value instanceof String) {
	            try {
	                result = new Timestamp(new SimpleDateFormat().parse((String) value).getTime());
	            } catch (ParseException e) {
	                throw new StrutsException("时间类型转换错误!", e);
	            }
	        }
	        return result;
	}
}
