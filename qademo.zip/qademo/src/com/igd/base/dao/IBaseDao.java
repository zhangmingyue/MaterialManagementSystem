package com.igd.base.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.util.Collection;
import java.util.List;

import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;


public interface IBaseDao {

	/** 加载指定ID的持久化对象 */
	public Object loadById(Class clazz,Serializable id);
	
	/** 加载满足条件的持久化对象 */
	public Object loadObject(String hql);
	
	/** 加载满足条件的持久化对象 占位符*/
	public Object loadObject(String hql,Object[]args);
	
	/** 删除指定ID的持久化对象 */
	public void delById(Class clazz,Serializable id);
	
	/** 保存指定的持久化对象 */
	public void save(Object obj); 
	 
	/** 保存或更新指定的持久化对象 */
	public void saveOrUpdate(Object obj);
	
	/** 装载指定类的所有持久化对象 */
	public List listAll(String clazz);
	
	/** 分页装载指定类的所有持久化对象 */
	public List listAll(String clazz,int pageNo,int pageSize);
	
	/** 统计指定类的所有持久化对象 */
	public int countAll(String clazz);
	
	/** 查询指定类的满足条件的持久化对象 */
	public List query(String hql);
	
	/** 查询指定类的满足条件的持久化对象 占位符*/
	public List query(String hql,Object[]args);
	
	/** 分页查询指定类的满足条件的持久化对象 */
	public List query(String hql,int pageNo,int pageSize);
	
	public Page pagedQuery(Condition p_condition);
	
	public Page lastOfPagedQuery(Condition p_condition);
	
	/** 统计指定类的查询结果 */
	public int countQuery(String hql);
	
	/** 条件更新数据 */
	public int update(String hql);
	
	/** 更新表中某个字段 */
	public void updateObject(String filedName,Object obj);
	
	/** 通过hql语句检索数据库表中记录，但是结果集为托管状态，延迟加载会不起作用 **/
	public List queryDetachedObjects(String p_hql);
	
	/** 通过ID检索数据库表中记录，但是结果为托管状态，延迟加载会不起作用 **/
	public Object queryDetachedById(Class p_obj, Serializable p_obj_id);
	
	/**  批量更新 **/
	public void bulkUpdate(String p_hql);
	
	/**批量删除数据库表中记录 **/
	public void deleteObjects(Collection cols) ;
	
	/**检查持久类集合中是否有与当前对象某些属性重复现象 **/
	public boolean checkRepeatObject(String hqlString);
	
	/**根据规则定义产生最大层次码 **/
	public String generator(int level, String codeRule, String prefix,String hqlString) throws Exception;
	
	/**向数据库表中更新多条记录，如果记录不存在，则新增该记录**/
	public void saveOrUpdateObjects(Collection p_cols);
	
	/**
	 * 向数据库表中删除记录
	 * 
	 * @param p_obj 要删除的Object
	 */
	public void delete(Object p_obj);
	   
	/** 从连接池中取得一个JDBC连接 */
	public Connection getConnection();
	/**
	 * 清除session缓存
	 */
	public void sessionClear();

}
