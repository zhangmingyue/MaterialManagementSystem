package com.igd.base.interceptor;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.igd.admin.model.Menu;
import com.igd.admin.model.User;
import com.igd.admin.service.IMenuTreeService;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

//import com.ssdr.manage.model.User;

/** session过期、登录有效性及操作的权限验证拦截器 */
public class LoginedCheckInterceptor extends AbstractInterceptor {

	private IMenuTreeService menuTreeService;
	private List<Menu> menulist;

	/** 拦截请求并进行登录有效性验证 */
	public String intercept(ActionInvocation ai) throws Exception {
		// 取得请求的URL
		String url = ServletActionContext.getRequest().getRequestURL().toString();
		User user = null;
		// 验证Session是否过期
		if (!ServletActionContext.getRequest().isRequestedSessionIdValid()) {
			// session过期,转向session过期提示页,最终跳转至登录页面
			return "tologin";
		} else {
			// 对登录与注销请求直接放行,不予拦截
			if (url.indexOf("reLogin.action") != -1 || url.indexOf("login.action") != -1 || url.indexOf("savepwd.action") != -1) {
				return ai.invoke();
			} else {
				user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
				// 验证是否已经登录
				if (user == null) {
					// 尚未登录,跳转至登录页面
					return "tologin";
				} else {
					// 过滤权限菜单，判断访问的菜单是否有访问的权限
					menulist = menuTreeService.getAccreditMenu(user.getRole().getId());
					for (Menu menu : menulist) {
						//System.out.println("---url--"+url);
						//System.out.println("---add--"+menu.getLinkAddress());
						// 如果有访问权限就放行
						if (null != menu.getLinkAddress() && !"".equals(menu.getLinkAddress())) {
							if (url.split("!")[0].indexOf(menu.getLinkAddress().split("!")[0]) != -1) {
								//System.out.println("----放行---");
								return ai.invoke();
							}
						}
					}
					// 没有权限跳转到首页
					return "tologin";
				}
			}
		}
	}

	public IMenuTreeService getMenuTreeService() {
		return menuTreeService;
	}

	public void setMenuTreeService(IMenuTreeService menuTreeService) {
		this.menuTreeService = menuTreeService;
	}

	public List<Menu> getMenulist() {
		return menulist;
	}

	public void setMenulist(List<Menu> menulist) {
		this.menulist = menulist;
	}

}