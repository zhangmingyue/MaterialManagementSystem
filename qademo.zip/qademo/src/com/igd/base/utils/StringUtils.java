package com.igd.base.utils;

import java.io.InputStream;
import java.text.StringCharacterIterator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

public final class StringUtils {	
	private static final String EMPTY = "";
	/**
	 * <p>判断字符串是否为null，""</p>
	 * <br>
	 * 样例:<br>
	 * isEmpty(null)=true;<br>
	 * isEmpty("")=true;<br>
	 * isEmpty(" ")=false;<br>
	 * isEmpty("abcd")=false;<br>
	 * @param p_str String 待判断字符
	 * @return boolean
	 */
	public static boolean isEmpty(String p_str){
		if(p_str==null || p_str.length()==0) return true;		
		return false;
	}
	/**
     * <p>字符反转</p>
     * <br>
     * 样列:<br>
     * reverse(null)=null;<br>
     * reverse("")="";<br>
     * reverse("123")="321";<br> 
     * @param p_str	待处理字符
     * @return String 顺序反转后的字符串
     */
    public static String reverse(String p_str){
    	if(null==p_str) return null;
    	StringBuilder _sb = new StringBuilder();
    	_sb.append(p_str);
    	return _sb.reverse().toString();
    }
    /**
     * <p>判断字符串中是否包含制定的字符串,字符大小写敏感</p>
     * <br>
     * 样例:<br>
     * contains("abcd","ab")=true;<br>
     * contains("abcd","Ab")=false;<br>
     * contains("abcd","ac")=false;<br>
     * @param p_str String 字符串
     * @param p_searchStr String 查询字符串
     * @return 含有字符串返回true，不含：false
     */
    public static boolean contains(String p_str, String p_searchStr) {
        if (p_str == null || p_searchStr == null) {
            return false;
        }
        return p_str.indexOf(p_searchStr) >= 0;
    }
    /**
     * <p>判断字符串中是否包含制定的字符串,字符大小写不敏感</p>
     * <br>
     * containsIgnoreCase("abcd","ab")=true;<br>
     * containsIgnoreCase("abcd","Ab")=true;<br>
     * containsIgnoreCase("abcd","ac")=false;<br>
     * @param p_str String 字符串
     * @param p_searchStr String 查询字符串
     * @return 含有字符串返回true，不含：false
     */
    public static boolean containsIgnoreCase(String p_str, String p_searchStr) {
        if (p_str == null || p_searchStr == null) {
            return false;
        }
        return contains(p_str.toUpperCase(), p_searchStr.toUpperCase());
    }
    /**
     * <p>内部使用类，判断字符串中是否以指定字符串开头(需指定大小写敏感开关)</p>
     * <br>
     * 样例:<br>
     * _startsWith("abcd","ab",true)=true;<br>
     * _startsWith("abcd","ab",false)=true;<br>
     * _startsWith("abcd","Ab",true)=false;<br>
     * _startsWith("abcd","Ab",false)=true;<br>
     * @param p_str String 字符串
     * @param p_prefix String 指定字符串
     * @param p_caseSensitive boolean 大小写是否敏感(敏感：true；不敏感：false)
     * @return 
     */
    private static boolean _startsWith(String p_str, String p_prefix, boolean p_caseSensitive) {
        if (p_str == null || p_prefix == null) {
            return (p_str == null && p_prefix == null);
        }
        if (p_prefix.length() > p_str.length()) {
            return false;
        }
        return p_str.regionMatches(p_caseSensitive, 0, p_prefix, 0, p_prefix.length());
    }
    /**
     * <p>判断字符串中是否以指定字符串开头(大小写敏感)</p>
     * <br>
     * 样例:<br>
     * startsWith(null,null) = true;<br>
     * startsWith(null,"ab") = false;<br>
     * startsWith("abcd",null) = false;<br>
     * startsWith("abcd","abc") = true;<br>
     * startsWith("abcd","Abc") = false;<br>
     * @param p_str String 字符串
     * @param p_prefix String 指定开始字符串
     * @return 
     */
    public static boolean startsWith(String p_str, String p_prefix) {
        return _startsWith(p_str, p_prefix, false);
    }
    /**
     * <p>判断字符串中是否以指定字符串开头(大小写不敏感)</p>
     * <br>
     * 样例：<br>
     * startsWithIgnoreCase(null,null) = true;<br>
     * startsWithIgnoreCase(null,"ab") = false;<br>
     * startsWithIgnoreCase("abcd",null) = false;<br>
     * startsWithIgnoreCase("abcd","abc") = true;<br>
     * startsWithIgnoreCase("abcd","Abc") = true;<br>
     * @param p_str String 字符串
     * @param p_prefix String 指定开始字符串
     * @return 
     */
    public static boolean startsWithIgnoreCase(String p_str, String p_prefix) {
        return _startsWith(p_str, p_prefix, true);
    }
    /**
     * <p>内部使用类，判断字符串中是否以指定字符串结尾(需指定大小写敏感开关)</p>
     * <br>
     * 样例：<br>
     * endsWith(null,null,true)=true;<br>
     * endsWith(null,"ab",true)=false;<br>
     * endsWith("abcd",null,true)=false;<br>
     * endsWith("abcd","cd",true)=true;<br>
     * endsWith("abcd","Cd",true)=false;<br>
     * endsWith("abcd","Cd",false)=true;<br>
     * @param p_str String 字符串
     * @param p_suffix String 指定结尾字符串
     * @param p_caseSensitive 
     * @return
     */
    private static boolean _endsWith(String p_str, String p_suffix, boolean p_caseSensitive) {
        if (p_str == null || p_suffix == null) {
            return (p_str == null && p_suffix == null);
        }
        if (p_suffix.length() > p_str.length()) {
            return false;
        }
        int strOffset = p_str.length() - p_suffix.length();
        return p_str.regionMatches(p_caseSensitive, strOffset, p_suffix, 0, p_suffix.length());
    }    
    /**
     * <p>判断字符串中是否以指定字符串结尾(大小写敏感)</p>
     * <br>
     * 样例:
     * endsWith(null,null)=true;<br>
     * endsWith(null,"ab")=false;<br>
     * endsWith("abcd",null)=false;<br>
     * endsWith("abcd","cd")=true;<br>
     * endsWith("abcd","Cd")=false;<br>
     * @param p_str String 字符串
     * @param p_suffix String 指定结尾字符串
     * @return
     */
    public static boolean endsWith(String p_str, String p_suffix) {
        return _endsWith(p_str, p_suffix, false);
    }
    /**
     * <p>判断字符串中是否以指定字符串结尾(大小写不敏感)</p>
     * <br>
     * 样例：<br>
     * endsWithIgnoreCase(null,null)=true;<br>
     * endsWithIgnoreCase(null,"ab")=false;<br>
     * endsWithIgnoreCase("abcd",null)=false;<br>
     * endsWithIgnoreCase("abcd","cd")=true;<br>
     * endsWithIgnoreCase("abcd","Cd")=true;<br>
     * @param p_str String 字符串<br>
     * @param p_suffix String 指定结尾字符串
     * @return
     */
    public static boolean endsWithIgnoreCase(String p_str, String p_suffix) {
        return _endsWith(p_str, p_suffix, true);
    }
    /**
     * <p>获取字符串匹配数量</p>
     * <br>
     * 样例:<br>
     * countMatches(null,null)=0;<br>
     * countMatches("abcdabcd",null)=0;<br>
     * countMatches(null,"ab")=0;<br>
     * countMatches("abcdabcd","ab")=2;<br>
     * countMatches("abcdabcd","ok")=0;<br>
     * @param p_str String 字符串
     * @param p_search String 指定匹配字符串
     * @return
     */
    public static int countMatches(String p_str, String p_search) {
        if (isEmpty(p_str) || isEmpty(p_search)) {
            return 0;
        }
        int count = 0;
        int idx = 0;
        while ((idx = p_str.indexOf(p_search, idx)) != -1) {
            count++;
            idx += p_search.length();
        }
        return count;
    }
    /**   
     * <p>将一个字串的首字母大写</p>
     * <br>   
     * 样例：<br>
     * toUpperCaseFirstLetter("abcd")="Abcd"<br>
     * toUpperCaseFirstLetter("123")="123"<br>
     * toUpperCaseFirstLetter(" 23")=" 23"<br>
     * toUpperCaseFirstLetter("中国23")="中国23"<br>
     * @param p_str String 源字串   
     * @return String 首字母大写后的字串   
     */    
    public static String toUpperCaseFirstLetter(String p_str){  
        return isEmpty(p_str)?p_str:p_str.substring(0, 1).toUpperCase() + p_str.substring(1);   
    }   
    /**   
     * <p>将一个字串的首字母小写</p>  
     * <br>
     * 样例：<br>
     * toLowerCaseFirstLetter("ABCD")="aBCD"<br> 
     * toUpperCaseFirstLetter("123")="123"<br>
     * toUpperCaseFirstLetter(" 23")=" 23"<br>
     * toUpperCaseFirstLetter("中国23")="中国23"<br>
     * @param p_str String 源字串   
     * @return String 首字母小写后的字串   
     */
    public static String toLowerCaseFirstLetter(String p_str){  
        return isEmpty(p_str)?p_str:p_str.substring(0, 1).toLowerCase() + p_str.substring(1);   
    } 
    /**
     * <p>删除字符串中所有空格(半角及全角)</p>
     * <br>
     * 样例:<br>
     * trim(null)=null;<br>
     * trim("")="";<br>
     * trim(" ab cd ")="abcd";<br>
     * @param p_str String 字符串
     * @return String 
     */
    public static String trim(String p_str){
    	if(null==p_str) return null;
    	String _reg = "[　 ]*";    	
    	return p_str.replaceAll(_reg,"");    	
    }
    /**
     * <p>删除字符串左侧空格(半角及全角)</p>
     * <br>
     * 样例:<br>
     * lTrim(null)=null;<br>
     * lTrim("")="";<br>
     * lTrim(" ab cd ")="ab cd ";<br>
     * @param p_str String 待处理字符串
     * @return String 去除左侧空格后的字符串
     */
    public static String lTrim(String p_str){    	
    	if(null==p_str) return null;
    	 String regStartSpace = "^[　 ]*";  
    	 return p_str.replaceAll(regStartSpace, "");
    }

    /**
     * <p>删除字符串右侧空格(半角及全角)</p>
     * <br>
     * 样例:<br>
     * rTrim(null)=null;<br>
     * rTrim("")="";<br>
     * rTrim(" ab cd ")=" ab cd";<br>
     * @param p_str	String 待处理字符串
     * @return String 去除右侧空格后的字符串
     */
    public static String rTrim(String p_str){    	
    	if(null==p_str) return null;
    	 String regEndSpace = "[　 ]*$"; 
    	 return p_str.replaceAll(regEndSpace, "");   
    	//return reverse(lTrim(reverse(p_str)));
    }
   
    /**   
     * <p>由指定位置截取指定长度子字符串</p>
     * <br>
     * 样例:<br>
     * subStr(null,2,2)=null;<br>
     * subStr("",2,2)=""<br>
     * subStr("abcd",2,2)="cd"<br>
     * @param p_str String 待截取字符串
     * @param p_begin String 开始截取位置
     * @param p_len int 截取长度
     * @return String 截取后的字符串 
     */
    public static  String subStr(String p_str,int p_begin ,int p_len) throws Exception{
    	if(null==p_str) return null;
        String strNew = p_str;    
        String myStr = "";  
        if(p_begin<0) p_begin = 0 ;
        if(p_begin>p_str.length()) return "";
        
        if (strNew.length() >= p_begin + p_len) {  
            myStr = strNew.substring(p_begin,p_begin + p_len);   
        }else { 
            myStr = strNew.substring(p_begin);
        }
        return myStr;  
    }   
    /**   
     * <p>由前取指定字符串的指定长度子字串</p>
     * <br>
     * 样例：<br>
     * left(null,2)=null;<br>
     * left("",2)="";<br>
     * left("abcd",2)=ab;<br>
     * left("abcd",8)=abcd;<br>
     * @param p_str String 待截取字符串
     * @param p_len int 截取长度
     * @return String 截取后的字符串 
     */
    public static final String left(String p_str, int p_len) throws Exception{    	
    	return subStr(p_str,0,p_len);
    } 
    /**
     * <p>由后取指定字符串的指定长度子字串</p>
     *<br>
     * 样例：<br>
     * right(null,2)=null;<br>
     * right("",2)="";<br>
     * right("abcd",2)="cd";<br>
     * left("abcd",8)="abcd";<br>
     * @param p_str String 字符串
     * @param p_len int 截取长度
     * @return
     */
    public static String right(String p_str, int p_len) {
        if (p_str == null) {
            return null;
        }
        if (p_len < 0) {
            return EMPTY;
        }
        if (p_str.length() <= p_len) {
            return p_str;
        }
        return p_str.substring(p_str.length() - p_len);
    }
    /**
      * <p>字符串替换</p>
      * <br>
      * 样例:<br>
      * replace(null,"ab","12")=null;<br>
      * replace("abcdabcd",null,null)="abcdabcd";<br>
      * replace("abcdabcd","ab","12")="12cd12cd";<br>
      * replace("abcdabcd","Ab","12")="abcdabcd";<br>
      * @param p_str			搜索字符串
      * @param p_findStr		要查找字符串
      * @param p_replaceStr		要替换字符串
      * @return String
      */
    public static String replace(String p_str, String p_findStr, String p_replaceStr) {
    	if (p_str == null) return null;
        if(null==p_findStr || null==p_replaceStr) return p_str;        
        int i = 0; 
        if ((i = p_str.indexOf(p_findStr, i)) >= 0){
            char ac[] = p_str.toCharArray();
            char ac1[] = p_replaceStr.toCharArray();
            int j = p_findStr.length();
            StringBuffer stringbuffer = new StringBuffer(ac.length);
            stringbuffer.append(ac, 0, i).append(ac1);
            i += j;
            int k;
            for (k = i;(i = p_str.indexOf(p_findStr, i)) > 0; k = i){
                stringbuffer.append(ac, k, i - k).append(ac1);
                i += j;
            }
            stringbuffer.append(ac, k, ac.length - k);
            return stringbuffer.toString();
        }else{
            return p_str;
        }
    }   
   
    /**
     * <p>字符串替换大小写不敏感</p>
     * <br>
     * 样例:<br>
     * replaceIgnoreCase(null,"ab","12")=null;<br>
     * replaceIgnoreCase("abcdabcd",null,null)="abcdabcd";<br>
     * replaceIgnoreCase("abcdabcd","ab","12")="12cd12cd";<br>
     * replaceIgnoreCase("abcdabcd","Ab","12")="12cd12cd";<br>
     * @param p_str	String	搜索字符串
     * @param p_findStr	String 要查找字符串
     * @param p_replaceStr String 要替换字符串
     * @return
     */
    public static final String replaceIgnoreCase(String p_str,String p_findStr,String p_replaceStr){
        if(p_str == null) return null;
        if(null==p_findStr || null==p_replaceStr) return p_str;
        String s3 = p_str.toLowerCase();
        String s4 = p_findStr.toLowerCase(); 
        int i = 0;
        if((i = s3.indexOf(s4, i)) >= 0){ 
            char ac[] = p_str.toCharArray();
            char ac1[] = p_replaceStr.toCharArray();
            int j = p_findStr.length();
            StringBuffer stringbuffer = new StringBuffer(ac.length);
            stringbuffer.append(ac, 0, i).append(ac1); 
            i += j; 
            int k;
            for (k = i;(i = s3.indexOf(s4, i)) > 0; k = i) {
                stringbuffer.append(ac, k, i - k).append(ac1); 
                i += j; 
            }  
            stringbuffer.append(ac, k, ac.length - k);
            return stringbuffer.toString(); 
        }else{ 
            return p_str; 
        }
    } 
  
    /** 
     * <p>如果字符串p_str为空则转换为p_defaultStr</p> 
     * <br>
     * 样例:<br>
     * getValidateStr(null,"1")="1"<br>
     * getValidateStr("","1")="1";<br>
     * getValidateStr("123","1")="123";<br>
     * @param p_str String 待判断字符
     * @param p_defaultStr 默认值，如果p_str为null,"null",""等，则返回默认值
     * @return String
     */ 
    public static String getValidateStr(String p_str, String p_defaultStr) { 
        if (isEmpty(p_str)){
            return p_defaultStr; 
        }else{ 
            return p_str;   
        }
    }
  
    /**
     * <p>此方法将给出的字符串p_str使用p_delim划分为单词数组。</p>
     * <br>
     * 样例:<br>
     * split(null,".")={null};<br>
     * split("",".")={""};<br>
     * split("1.2.3",".")={"1","2","3"};<br>
     * @param p_str String 需要进行划分的原字符串
     * @param p_delim String 单词的分隔字符串  
     * @return String[] 划分以后的数组，如果p_str为null的时候返回以p_str为唯一元素的数组，  
     *         如果p_delim为null则使用逗号作为分隔字符串。
     */  
    public static String[] split(String p_str, String p_delim) { 
        String[] _wordLists;   
        if (p_str == null || "".equals(p_str)) { 
            _wordLists = new String[1]; 
            _wordLists[0] = p_str; 
            return _wordLists;  
        } 
        if (p_delim == null) { 
            p_delim = ",";  
        }   
        StringTokenizer _st = new StringTokenizer(p_str, p_delim); 
        int _total = _st.countTokens();  
        _wordLists = new String[_total]; 
        for (int i = 0; i < _total; i++) { 
            _wordLists[i] = _st.nextToken(); 
        }   
        return _wordLists;  
    }
    
     /**  
     * <p>将set的所有记录合并成一个以 delim 分隔的字符串</p>
     * <br>
     * 样例:<br>
     * combine(null,".")="";<br>
     * combine(new HashSet(){"1","2","3"},".")="1.2.3";<br>
     * @param p_set Set 字符串对象 
     * @param p_delim String 分割符，默认值为""
     * @return String 以','为分隔的合并后的字符串  
     * @deprecated
     */
    public static String combine(Set p_set, String p_delim) {  
        if(p_set == null || p_set.size() == 0) {  
            return "";   
        }   
        if (p_delim == null) { 
            p_delim = "";  
        }   
        StringBuffer sb = new StringBuffer(100);
        for(Iterator iter = p_set.iterator(); iter.hasNext(); ) {  
            sb.append(iter.next());   
            sb.append(p_delim);   
        }   
        if(sb.length() >= p_delim.length()) {
            sb.delete(sb.length() - 1 - p_delim.length(), sb.length() - 1); 
        }   
        return sb.toString();  
    }   
 
    /** 
     * <p>将字符串数组合并成一个以 delim 分隔的字符串</p>
     * <br>  
     * 样例:<br>
     * combine(null,".")="";
     * combine(new String[]{"1","2","3"},".")="1.2.3";<br>
     * @param p_array String[] 字符串数组  
     * @param p_delim String 分隔符，为null的时候使用""作为分隔符（即没有分隔符） 
     * @return String 以p_delim为分隔的合并后的字符串  
     */ 
    public static String combine(String[] p_array, String p_delim) {
        if (p_array == null || p_array.length == 0) {  
            return "";  
        }   
        int length = p_array.length - 1;   
        if (p_delim == null) {   
            p_delim = "";   
        }   
        StringBuffer result = new StringBuffer(length * 8);
        for (int i = 0; i < length; i++) {   
            result.append(p_array[i]);   
            result.append(p_delim);  
        }   
        result.append(p_array[length]); 
        return result.toString();  
    }   
   
    /**  
     * <p>将int数组使用指定的分隔符合并成一个字符串</p>  
     * <br>
     * 样例:<br>
     * combine(null,".")="";<br>
     * combine(new int[]{1,2,3},".")="1.2.3";<br>
     * @param p_array int[] int 数组
     * @param p_delim String 分隔符，为null的时候使用""作为分隔符（即没有分隔符） 
     * @return String 以p_delim作为分隔符的合并后的字符串  
     */  
    public static String combine(int[] p_array, String p_delim) { 
        if (p_array == null || p_array.length == 0) {   
            return "";   
        }   
        int length = p_array.length - 1;   
        if (p_delim == null) {   
            p_delim = "";   
        }   
        StringBuffer result = new StringBuffer();   
        for (int i = 0; i < length; i++) {   
            result.append(Integer.toString(p_array[i]));  
            result.append(p_delim); 
        } 
        result.append(Integer.toString(p_array[length])); 
        return result.toString();
    }   
 
  
    /**  
     * <p>将字符串List使用指定的分隔符合并成一个字符串。</p>
     * <br>
     * 样例：<br>
     * combine(null,".")="";<br>
     * combine(new ArrayList(){1,2,3},".")="1.2.3";<br>
     * @param p_list List 内部存储字符串对象
     * @param p_delim String  分隔符
     * @return String  返回以p_delim为分隔的合并后的字符串
     */  
    public static String combine(List p_list, String p_delim) { 
        if(p_list == null || p_list.size() == 0){ 
            return "";   
        }else{   
            StringBuffer result = new StringBuffer();  
            for (int i = 0; i < p_list.size() - 1; i++) { 
                result.append(p_list.get(i));   
                result.append(p_delim);   
            }
            result.append(p_list.get(p_list.size() - 1));  
            return result.toString();  
        }
    }   
  
    /**  
     * <p>以指定的字符和长度生成一个该字符的指定长度的字符串。</p>
     * <br>
     * 样例: <br>
     * fillString('a',10)="aaaaaaaaaa";<br>
     * @param p_chr char 指定的字符  
     * @param p_len int 指定的长度  
     * @return 最终生成的字符串 
     * @since  0.6  
     */  
    public static String fillString(char p_chr, int p_len) {
        String ret = "";   
        for (int i = 0; i < p_len; i++) { 
            ret += p_chr;   
        }   
        return ret;   
    }
  
    /**  
     * <p>字符串数组中是否包含指定的字符串。</p>
     * <br>
     * 样例：<br>
     * contains(null,"ab",true)=false;<br>
     * contains(new String[]{"a","ab",null},"ab",true)=true;<br>
     * contains(new String[]{"a","ab",null},"Ab",false)=true;<br>
     * contains(new String[]{"a","ab",null},"Ab",true)=false;<br>
     * @param p_strs String[] 字符串数组 
     * @param p_key String 字符串 
     * @param p_caseSensitive boolean 是否大小写敏感 
     * @return 包含时返回true，否则返回false 
     */  
    private static boolean _contains(String[] p_strs, String p_key,boolean p_caseSensitive) { 
    	if(null==p_strs) return false;    	
        for (int i = 0; i < p_strs.length; i++) { 
        	if(null==p_strs[i]){
        		if( null==p_key) return true;
        	}else{
	            if (p_caseSensitive == true) {
	            	
	                if (p_strs[i].equals(p_key)) {
	                    return true;  
	                }
	            } else { 
	                if (p_strs[i].equalsIgnoreCase(p_key)) {
	                    return true;
	                }
	            } 
        	}
        }  
        return false; 

    }   
  
    /**  
     * <p>字符串数组中是否包含指定的字符串。大小写敏感。</p>
     * <br>
     * 样例:<br>
     * contains(null,"ab")=false;<br>
     * contains(new String[]{"a","ab",null},"ab")=true;<br>
     * contains(new String[]{"a","ab",null},"Ab")=false;<br>
     * contains(new String[]{"a","ab",null},"abc")=false;<br>
     * @param p_strs String[] 字符串数组  
     * @param p_key String 字符串 
     * @return 包含时返回true，否则返回false 
     * @since  0.4 
     */  
    public static boolean contains(String[] p_strs, String p_key) {  
        return _contains(p_strs, p_key, true);   
    }   
  
    /** 
     * <p>不区分大小写判定字符串数组中是否包含指定的字符串。</p>
     * <br>
     * 样例:<br>
     * containsIgnoreCase(null,"ab")=false;<br>
     * containsIgnoreCase(new String[]{"a","ab",null},"ab")=true;<br>
     * containsIgnoreCase(new String[]{"a","ab",null},"Ab")=true;<br>
     * containsIgnoreCase(new String[]{"a","ab",null},"abc")=false;<br>
     * @param p_strs String[] 字符串数组
     * @param p_key String 字符串  
     * @return boolean 包含时返回true，否则返回false  
     * @since  0.4
     */  
    public static boolean containsIgnoreCase(String[] p_strs, String p_key) { 
        return _contains(p_strs, p_key, false); 
    }   
    
    /**  
     * <p>得到字符串的"字节"长度</p>
     * <br>
     * 样例:<br>
     * getByteLength(null)=0;<br>
     * getByteLength("")=0;<br>
     * getByteLength("abcd")=4;<br>
     * getByteLength("中国")=4;<br>
     * @param p_str String 字符串  
     * @return 字符串的字节长度 
     * @since  0.6  
     */  
    public static int getByteLength(String p_str) { 
    	if(null==p_str) return 0;
        int len = 0;   
        for (int i = 0; i < p_str.length(); i++) {  
            char c = p_str.charAt(i);  
            int highByte = c >>> 8;  
            len += highByte == 0 ? 1 : 2;  
        }   
        return len; 
    } 
    
    /** 
     * <p>判断字符是否为双字节字符，如中文</p>
     * <br>
     * 样例:<br>
     * isDoubleByte('a')=false;<br>
     * isDoubleByte('中')=true;<br>
     * @param p_chr char 待判断字符
     * @return boolean
     */  
    public static boolean isDoubleByte(char p_chr) {
        return! ( (p_chr >>> 8) == 0);  
    }   
    
    
    /**
     * <p> 根据转义列表对字符串进行转义(escape)</p>。  
     * <br>
     * 样例：<br>
     * escapeCharacter(null,null)=null;<br>
     * escapeCharacter("",null)="";<br>
     * escapeCharacter("abcdabcd",new HashMap())="abcdabcd";<br>
     * escapeCharacter("abcdabcd",new HashMap(){a=1,b=2,c=3})="123d123d";<br>
     * @param source String 待转义的字符串  
     * @param escapeCharMap HashMap 转义列表  
     * @return String 转义后的字符串 
     */
    public static String escapeCharacter(String source,HashMap escapeCharMap) { 
        if (source == null || source.length() == 0) { 
            return source; 
        }  
        if (null==escapeCharMap || escapeCharMap.size() == 0) {  
            return source;
        }   
        StringBuffer sb = new StringBuffer(source.length() + 100); 
        StringCharacterIterator sci = new StringCharacterIterator(source);
        for (char c = sci.first();  
            c != StringCharacterIterator.DONE; 
            c = sci.next()) {
            String character = String.valueOf(c);  
            if (escapeCharMap.containsKey(character)) {
                character = (String) escapeCharMap.get(character); 
            }   
            sb.append(character); 
        } 
        return sb.toString();   
  
    }
    /**
     * <p>以指定'p_in'字符集读入字符串，然后转换为'p_out'字符集</p>
     * convert("中国","GBK","UTF-8");
     * @param p_str String 读入字符串
     * @param p_in String 指定字符集
     * @param p_out String 转换后的字符集
     * @return String 转换后的字符串
     * @throws Exception
     */
    public static String convert(String p_str,String p_in,String p_out) throws Exception{
    	if(isEmpty(p_str)) return p_str;
		byte[] _bytes = p_str.getBytes(p_in); 
		return new String(_bytes, p_out);
    }
    
    /**
     * 将文本输入流转换为字符串
     * @param p_is InputStream 文本输入流
     * @return String 文本字符
     */
    public static final String streamToString(InputStream p_is) { 
      StringBuffer sb=new StringBuffer("");  
      byte[] buffer = new byte[4096];  
      int bytes_read;  
      try {
        while ( (bytes_read = p_is.read(buffer)) != -1) {
          sb.append(new String(buffer, 0, bytes_read, "GBK")); 
        }
         return sb.toString();
      }catch(Exception ex) { 
    	  ex.printStackTrace();
        return null;  
      } 
    } 
    /**  
     * 输出固定字节长度的字符串  
     * @param p_str String 待处理字符串
     * @param p_len int  输出字符长度
     * @param p_exChar String 
     * @param p_exStr String 
     * @return String  
     */  
    public static String getByteSubStr(String p_str, int p_len, String p_exChar,String p_exStr) { 
        if (p_str == null || getByteLength(p_str) <= p_len) { 
            return p_str;  
        }   
        StringBuffer result = new StringBuffer();
        char c = '\u0000';   
        int i = 0, j = 0;  
        for (; i < p_len; j++) {  
            result.append(c);  
            c = p_str.charAt(j); 
            i += isDoubleByte(c) ? 2 : 1;   
        }   
        /**  
         * 到这里i有两种情况：等于len或是len+1，如果是len+1，说明是双字节，并多出一个字节  
         * 这时候就只能append(exChar)，否则就append(c)  
         */  
        if (i > p_len) {
            result.append(p_exChar); 
        } else {   
            result.append(c);   
        }   
        result.append(p_exStr);  
        return result.toString(); 
    }
  
    /**
     * 生成制定长度的随机字符串（字符+数字）
     * @param p_len
     * @return
     */
    public static String random(int p_len){
    	return null;
    }
    
    public static void main(String[] args) throws Exception{
    	
    	//split
    	//combine(String[] p_array, String p_delim)
    	//contains
    	//convert
    	//判断字符串是否为null
//    	System.out .println("******************《1》判断字符串是否为null********************");
		String str = "";
//		System.out.println("【" + str + "】是否为空:" + isEmpty(str));
		
		//字符反转
		System.out .println("*********************字符反转****************************");
		str = "abcdefg";
		System.out.println("【" + str + "】反转后：" + reverse(str));
		
//		//获取字符串匹配数量
//		System.out.println("******************获取字符串匹配数量**********************");
//		str = "a123bc123de123fg";
//		System.out.println("【" + str + "】中123的个数：" + countMatches(str, "123"));
//		//由指定位置截取指定长度子字符串
//		System.out.println("***************由指定位置截取指定长度子字符串***************");
//		str = "abcdefg";
//		System.out.println("【" + str + "】从3的位置上截取3个字符：" + subStr(str, 3, 3));
//		//删除字符串中所有空格(半角及全角)
//		System.out.println("***************删除字符串中所有空格(半角及全角)**************");
//		str = "a b c d e f g";
//		System.out.println("【" + str + "】去空格：" + trim(str));
//		//判断字符是否为双字节字符，如中文
//		System.out.println("*****************判断字符是否为双字节字符，如中文************");
//		char chr = '哦';
//		System.out.println("【" + chr + "】是否为双字节" + isDoubleByte(chr));
    }
    
}
