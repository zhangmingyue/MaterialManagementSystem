package com.igd.base.utils.date;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class SqlDateUtils {
	 public static void main(String[] args) throws Exception{		 
		 Timestamp v = getNDayAfterDate(getCurrentTimestamp(),10);
	 }
	 
	 /** 
	 * 取得系统当前时间后n天 
	 * @param n int 
	 * @return String yyyy-mm-dd 
	 */ 
	 public static Timestamp getNDayAfterDate(Timestamp t,int n) {
		 Calendar c = Calendar.getInstance();
		 c.setTimeInMillis(t.getTime());
		 c.add(c.DAY_OF_MONTH, n);
		 return new Timestamp(c.getTime().getTime());		  
	 } 
	 public static long getHourDiff(Timestamp t1,Timestamp t2){
		 //t1.setSeconds(0);
		 //t2.setSeconds(0);
		 long t1_=t1.getTime();
		 long t2_=t2.getTime();
		 return (t2_-t1_)/(60*60*1000);		 
	 }
	 public static long getMinuteDiff(Timestamp t1,Timestamp t2){
		 //t1.setSeconds(0);
		 //t2.setSeconds(0);
		 long t1_=t1.getTime();
		 long t2_=t2.getTime();
		 return ((t2_-t1_)/(60*1000))%60;		 
	 }
	 
	 public static int getYear(Timestamp t){
		 Calendar c = Calendar.getInstance(); //这句好像很浪费，我也不知道该怎么处理
		 c.setTimeInMillis(t.getTime());//将Date或Timestamp放进去
		return c.get(Calendar.YEAR);    //取出年份 
	 }
	 public static int getMonth(Timestamp t){
		 Calendar c = Calendar.getInstance(); //这句好像很浪费，我也不知道该怎么处理
		 c.setTimeInMillis(t.getTime());//将Date或Timestamp放进去
		return c.get(Calendar.MONTH)+1; 
	 }

	 public static Timestamp stringDate2Timestamp(String str) throws Exception{
		 java.sql.Date d =  SqlDateUtils.string2Date(str);		 
		 return new java.sql.Timestamp(d.getTime());
	 }
	public static Timestamp getCurrentTimestamp(){
		 Calendar cal = Calendar.getInstance();
		  long millis = cal.getTime().getTime();
		  return new Timestamp(millis);

	}
	/**
	 * 转换为中文时间格式（2000年12月12日12时12分）
	 * 
	 * @param t
	 * @return
	 */
	public static String getTimestamp_zh_CN(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		sb.append(1900+t.getYear()).append("年");
		sb.append(t.getMonth()+1).append("月");
		sb.append(t.getDate()).append("日");
		sb.append(t.getHours()).append("时");
		sb.append(t.getMinutes()).append("分");
		return sb.toString();
	}
	public String getTimestamp_zh_CN_(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		sb.append(1900+t.getYear()).append("年");
		sb.append(t.getMonth()+1).append("月");
		sb.append(t.getDate()).append("日");
		sb.append(t.getHours()).append("时");
		sb.append(t.getMinutes()).append("分");
		return sb.toString();
	}
	/**
	 * 转换为中文时间格式（2000年12月12日12时12分）
	 * 
	 * @param t
	 * @return
	 */
	public static String getYMDHM_zh_CN(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		sb.append(1900+t.getYear()).append("年");
		sb.append(t.getMonth()+1).append("月");
		sb.append(t.getDate()).append("日");
		sb.append(t.getHours()).append("时");
		sb.append(t.getMinutes()).append("分");
		return sb.toString();
	}	
	/**
	 * 转换为中文时间格式（12日12时12分）
	 * 
	 * @param t
	 * @return
	 */
	public static String getDHM_zh_CN(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		sb.append(t.getDate()).append("日");
		sb.append(t.getHours()).append("时");
		sb.append(t.getMinutes()).append("分");
		return sb.toString();
	}	
	/**
	 * 转换为中文时间格式（2000年12月12日）
	 * 
	 * @param t
	 * @return
	 */
	public static String getYMD_zh_CN(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		sb.append(1900+t.getYear()).append("年");
		sb.append(t.getMonth()+1).append("月");
		sb.append(t.getDate()).append("日");		
		return sb.toString();
	}	
	/**
	 * 转换为标准时间格式（2000-12-12 12:12:12）
	 * 
	 * @param t
	 * @return
	 */
	public static String getTimestamp_YMDHMS(Timestamp t) {
		
		if (t == null)
			return "";		
		StringBuffer sb = new StringBuffer();
		sb.append(1900+t.getYear()).append("-");
		sb.append(formate(t.getMonth()+1)).append("-");		
		sb.append(formate(t.getDate())).append(" ");
		sb.append(formate(t.getHours())).append(":");
		sb.append(formate(t.getMinutes())).append(":");
		sb.append(formate(t.getSeconds()));
		return sb.toString();
	}
	public static String formate(int num){
		return num>=10?""+num:"0"+num;
	}
	/**
	 * 转换为标准时间格式（2000-12-12 12:12）
	 * @param t
	 * @return
	 */
	public static String getTimestamp_YMDHM(Timestamp t){
		try{
			if (t == null)
				return "";
			StringBuffer sb = new StringBuffer();
			sb.append(1900+t.getYear()).append("-");
			sb.append(wrapTime(t.getMonth()+1)).append("-");
			sb.append(wrapTime(t.getDate())).append(" ");
			sb.append(wrapTime(t.getHours())).append(":");
			sb.append(wrapTime(t.getMinutes()));
			return sb.toString();
		}catch(Exception e){
			return null;
		}
	}
	/**
	 * 转换为标准日期格式（2000-12-12）
	 * 
	 * @param t
	 * @return
	 */
	public static String getTimestamp_YMD(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		String  year = Integer.toString(1900+t.getYear());
		String month = "";
		String date = "";
		int m = t.getMonth()+1;
		if(m < 10){
			
			month = "0"+ m;
		}else{
			month = Integer.toString(m);
		}
		int d = t.getDate();
		if(d<10){			
			date = "0"+ d;
		}else{
			date = Integer.toString(d);
		}
		 
		sb.append(year).append("-");
		sb.append(month).append("-");
		sb.append(date);		
		return sb.toString();
	}
	/**
	 * 转换为中文时间格式（2000年12月12日）
	 * 
	 * @param t
	 * @return
	 */
	public static String getDate_zh_CN(Timestamp t) {
		if (t == null)
			return "";
		StringBuffer sb = new StringBuffer();
		sb.append(1900+t.getYear()).append("年");
		sb.append(t.getMonth()+1).append("月");
		sb.append(t.getDate()).append("日");		
		return sb.toString();
	}

	 public static Timestamp stringDateTimestamp(String str) throws Exception{
		 Timestamp d =  SqlDateUtils.string2Time(str);		 
		 return new java.sql.Timestamp(d.getTime());
	 }

	/**
	 * method 将字符串类型的日期转换为一个timestamp（时间戳记java.sql.Timestamp）
	 * 
	 * @param dateString
	 *            需要转换为timestamp的字符串
	 * @return dataTime timestamp
	 */
	public final static java.sql.Timestamp string2Time(String dateString)
			throws java.text.ParseException {
		DateFormat dateFormat;
//		dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss.SSS",
//				Locale.ENGLISH);// 设定格式
		 dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss",
		 Locale.ENGLISH);
		dateFormat.setLenient(false);
		java.util.Date timeDate = dateFormat.parse(dateString);// util类型
		java.sql.Timestamp dateTime = new java.sql.Timestamp(timeDate.getTime());// Timestamp类型,timeDate.getTime()返回一个long型
		return dateTime;
	}

	/**
	 * method 将字符串类型的日期转换为一个Date（java.sql.Date）
	 * 
	 * @param dateString
	 *            需要转换为Date的字符串
	 * @return dataTime Date
	 */
	public final static java.sql.Date string2Date(String dateString)
			throws java.lang.Exception {
		DateFormat dateFormat;
		dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA);
		dateFormat.setLenient(false);
		java.util.Date timeDate = dateFormat.parse(dateString);// util类型
		java.sql.Date dateTime = new java.sql.Date(timeDate.getTime());// sql类型
		return dateTime;
	}
	public static String wrapTime(int time) throws Exception{
		if(time<10) return "0"  + Integer.toString(time);
		return Integer.toString(time);
	}
	/**
	 * 得到所选时间的上一年
	 * @author 王勇
	 * @param t 2006-09-01
	 * @return  2005-09-01
	 * @throws Exception
	 */
	public static String aboveYear (Timestamp t) throws Exception{
		StringBuffer sb = new StringBuffer();
		String year = Integer.toString(1900 + t.getYear()-1);
		String month = "";
		String date = "";
		int m = t.getMonth() + 1;
		if (m < 10) {
			month = "0" + m;
		} else {
			month = Integer.toString(m);
		}
		int d = t.getDate();
		if (d < 10) {
			date = "0" + d;
		} else {
			date = Integer.toString(d);
		}
		sb.append(year).append("-");
		sb.append(month).append("-");
		sb.append(date);
		String Currentday = sb.toString();
		return Currentday;
	}
}
