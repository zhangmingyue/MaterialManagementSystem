package com.igd.base.utils.date;

public class Quarter {
	private String valueQ;
	private String nameQ;
	public void setNameQ(String nameQ) {
		this.nameQ = nameQ;
	}
	public String getNameQ() {
		return nameQ;
	}
	public void setValueQ(String valueQ) {
		this.valueQ = valueQ;
	}
	public String getValueQ() {
		return valueQ;
	}
}
