package com.igd.base.utils;

import java.util.List;

public class LevelCodeGenerator {
	
	/**
	 * 代码生成器
	 * @param level     层次
	 * @param codeRule  位数
	 * @param prefix    前缀
	 * @param maxCode   最大值
	 * @return   符合规则要求的字符串
	 * <br>样例<br>
	 * generator(1, "2", "", "select max(role.id) from Role as role")
	 * @throws Exception
	 */
	
	public static String generator(int level, String codeRule, String prefix,String maxCode) throws Exception {
		int curLayer = Integer.parseInt(codeRule.substring(level - 1, level));
		// 2.找出当前最大号
		if (maxCode == null)
			maxCode = "0";
		// 3.去掉前缀字符
		String code = "";
		String curCode = "";
		if (maxCode.equals("0")) {
			code = "0";
			curCode = "0";
		} else {
			if (prefix.equals("")) {
				code = maxCode.substring(0);
			} else {
				code = maxCode.substring(prefix.length() - 1);
			}
			curCode = code.substring(code.length() - curLayer);
		}
		// 4.转换字符串为整形,并进行加1
		String maxInt = "1";
		if (curLayer == 1) {
			if (curCode.equals("9")) {
				curCode = "a";
			} else {
				curCode = "" + (char) ((int) (curCode.charAt(0)) + 1);
			}
			if (curCode.equals("z"))
				throw new Exception("超过最大限z!");
		} else {
			String suffix = "";
			for (int i = 0; i < curLayer; i++) {
				suffix += "0";
			}
			maxInt += suffix;
			curCode = Integer.toString(Integer.valueOf(curCode).intValue() + 1);
			if (Integer.parseInt(maxInt) <= Integer.parseInt(curCode))
				throw new Exception("超过最大限" + maxInt + "!");
			int length = curCode.length();
			String zeros = "";
			for (int i = 0; i < curLayer - length; i++) {
				zeros += "0";
			}
			curCode = zeros + curCode;
		}
		return prefix + curCode;
		
	}
	
	/**
	 * <p>数字右侧补零；</p>
	 * @param value(int类型数字；)
	 * @param level(显示位数；)
	 * @return(补齐后的字符串；)
	 * @throws Exception
	 */
	public static String patchZeroToSequence(int value,int level) throws Exception{
		String txtValue = Integer.toString(value);
		int len = level - txtValue.length();
		for(long i=0;i<len;i++){
			txtValue = "0" + txtValue;
		}	
		return txtValue;
	}
	
	
	public static String patchZeroToSequence(long value,int level) throws Exception{
		String txtValue = Long.toString(value);
		int len = level - txtValue.length();
		for(long i=0;i<len;i++){
			txtValue = "0" + txtValue;
		}	
		return txtValue;
	}
	
	/**
	 * 自动产生代码；前缀 + 特定长度顺序号
	 * @param prefix
	 * @param suffixNum
	 * @param suffixLength
	 * @return
	 * 
	 */
	public static String prepareSequenceNumber(String prefix,long suffixNum,int suffixLength) throws Exception{		
		return prefix + patchZeroToSequence(suffixNum,suffixLength);
	}
    
	/**
	 * 获取不重复的顺序号码
	 * @param list   最大顺序号"select max(dept.id) from Dept as dept where dept.parent='" + parent +"'"
	 * @param prefix  前缀 
	 * @param suffixLength  长度
	 * @return
	 * <br>样例<br>
	 * getNonRepeatedSequenceNumber_(lst, dept.getParent(), 3)
	 * @throws Exception
	 */
	public static String getNonRepeatedSequenceNumber_(List list,String prefix,int suffixLength) throws Exception{
		if(null!=list && list.size()>0){
			String max = (String) list.get(0);
			if(null!=max && max.length()>0){
				//

				String value = max.substring(prefix.length());
				return prepareSequenceNumber(prefix,Integer.parseInt(value) + 1,suffixLength);	
			}
		}
		return prepareSequenceNumber(prefix,1,suffixLength);	
	}
	
}
