package com.igd.base.utils;

import java.io.InputStream;
import java.util.Properties;

/**
 * 读写properties文件;
 */

public class PropertiesUtils {
	public static Properties loadProperty() throws Exception{
		 Properties property = new Properties();
		 InputStream is = PropertiesUtils.class.getClassLoader().getResourceAsStream("config.properties");
		 property.load(is);
		 return property;
	}
	//读属性值
	public static String getPropertyValue(String param) throws Exception{
		Properties p = PropertiesUtils.loadProperty();
		return p.getProperty(param);
	}
}
