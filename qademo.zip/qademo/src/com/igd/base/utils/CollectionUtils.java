package com.igd.base.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;


public class CollectionUtils {
	/**
	 * <p>判断集合是否为空</p>
	 * <br>
	 * 样例:<br>
	 * Collection _c = new HashSet();<br>
	 * isEmpty(_c)=true;<br>
	 * _c.add("a");<br>
	 * isEmpty(_c)=false;<br>
	 * @param p_c Collection 集合
	 * @return 如果null,size<1,返回true；
	 */
	public static boolean isEmpty(Collection p_c){
		if(null==p_c || p_c.isEmpty()) return true;
		return false;
	}
	/**
	 * <p>数组内容反转</p>
	 * <br>
	 * 样例：<br>
	 * String[] _strs = new String[]{"1","2","3"};<br>
	 * CollectionUtils.reverse(_strs);<br>
	 * _strs={"3","2","1"};<br>
	 * @param p_array 对象数组
	 */
    public static void reverse(Object[] p_array) {
        if (p_array == null) {
            return;
        }
        int i = 0;
        int j = p_array.length - 1;
        Object _obj;
        while (j > i) {
            _obj = p_array[j];
            p_array[j] = p_array[i];
            p_array[i] = _obj;
            j--;
            i++;
        }
    }
    
	/**
     * <p>将数组转换为ArrayList</p>
     * <br>
     * 样例:<br>
     * convertArray2List(null)=null;<br>
     * convertArray2List(new String[]{}).size()=0;<br>
     * String[] _strs = new String[]{"1",null,"3"};<br>
	 * convertArray2List(_strs)=List{"1",null,"3"};<br>
     * @param p_array Object[] 待转换的数组
     * @return ArrayList 转换后的ArrayList
     */
    public static ArrayList convertArray2List(Object[] p_array) {
        if(null==p_array) return null;
        ArrayList _list = new ArrayList();       
    	if(p_array.length<1) return _list;
        for (int i = 0; i < p_array.length; i++) {
            _list.add(p_array[i]); 
        }
        return _list;
    }
    
    /**
     * <p>将list转换为数组</p>
     * <br>
     * 样例:<br>
     * convertList2Array(null);<br>
     * convertList2Array(new ArrayList());<br>
     * List _list = new ArrayList();<br>
     * _list.add("0");<br>
     * _list.add("1");<br>
     * _list.add("2");<br>
     * convertList2Array(_list)=Object[]{"0","1","2"};<br>
     * @param p_list List 列表数据
     * @return 转换后的数组
     */
    public static Object[] convertList2Array(List p_list){    	
        if(null==p_list || p_list.isEmpty()) return null;
        return p_list.toArray();
    }

    /**
     * <p>将Set转换为List</p>
     * <br>
     * 样例:<br>
     * convertSet2List(null)=null;<br>
     * convertSet2List(new HashSet()).size()=0;<br>
     * Set _set = new HashSet();<br>
     * _set.add("0");<br>
     * _set.add("1");<br>
     * _set.add("2");<br>
     * convertSet2List(_set).size()=3;<br>
     * @param p_set Set 集合数据
     * @return
     */
    public static ArrayList convertSet2List(Set p_set){
    	ArrayList _list = new ArrayList();
        if(null==p_set) return null;
        for(Iterator _it = p_set.iterator();_it.hasNext();){
        	_list.add(_it.next());
        }
    	return _list;
    }
    
    /**
     * <p>将List转换为Set</p>
     * <br>
     * 样例:<br>
     * convertList2Set(null)=null;<br>
     * convertList2Set(new ArrayList()).size()=0;<br>
     * List _list = new ArrayList();<br>
     * _list.add("0");<br>
     * _list.add("1");<br>
     * _list.add("2");<br>
     * convertList2Set(_list).size()=3;<br>
     * @param p_list List 列表数据
     * @return
     */
    public static Set convertList2Set(List p_list){
    	Set _set = new HashSet();
        if(null==p_list) return null;
        for(Iterator _it = p_list.iterator();_it.hasNext();){
        	_set.add(_it.next());
        }
    	return _set; 
    }
    /**
     * <p>通过Map创建Properties对象,如果null则返回一个空的properties对象</p>
     * <br>
     * 样例:<br>
     * toProperties(null).size()=0;<br>
     * toProperties(new HashMap()).size()=0;<br>
     * Map _map = new HashMap();<br>
     * _map.put("1", "a");<br>
     * _map.put("2", "b");<br>
     * _map.put("3", "c");<br>
     * Properties _p = CollectionUtils.toProperties(_map);<br>
     * _p.getProperty("1")="a";<br>
     * _p.getProperty("2")="b";<br>
     * _p.getProperty("3")="c";<br>
     * @param p_map  待转换为Properties的Map对象
     * @return properties对象
     */
    public static Properties toProperties(final Map p_map) {
        Properties _answer = new Properties();
        if (p_map != null) {
            for (Iterator iter = p_map.entrySet().iterator(); iter.hasNext();) {
                Map.Entry _entry = (Map.Entry) iter.next();
                Object _key = _entry.getKey();
                Object _value = _entry.getValue();
                _answer.put(_key, _value);
            }
        }
        return _answer;
    }
    /**
     * <p>判断两个集合是否相等</p>
     * <br>
     * 样例:<br>
     * 
     * @param p_c1 Collection 第一个集合
     * @param p_c2 Collection 第二个集合
     * @return 
     * @throws Exception
     * @see #removeAll(Collection, Collection)
     */
    public static boolean isEqual(Collection p_c1,Collection p_c2) throws Exception{    	
    	if(null==p_c1 && null==p_c2) return true;
    	if(null==p_c1 || null==p_c2) return false;
    	List _list1 = removeAll(p_c1,p_c2);
    	List _list2 = removeAll(p_c2,p_c1);    	
    	if(_list1.isEmpty() && _list2.isEmpty()) return true;    	
    	return false;
    }
    /**
     * <p>两个集合相减</p>
     * <br>
     * 样例:<br>
     * subtract(null,null)=null;<br>
     * subtract(new ArrayList(),null)={};<br>
     * List _list1 = new ArrayList();<br>
     * _list1.add("0");<br>
     * _list1.add("1");<br>
     * _list1.add("2");<br>
     * List _list2 = new ArrayList();<br>
     * _list2.add("1");<br>
     * _list2.add("2");<br>
     * _list2.add("3");<br>    	
     * subtract(_list1, _list2)={"0"};<br>
     * @param p_list1 List 减集合
     * @param p_list2 List 被减集合
     * @return
     */
    public static List subtract(final List p_list1, final List p_list2) {
    	if(null==p_list1) return null;
    	if(isEmpty(p_list2)) return new ArrayList(p_list1);    	
        final ArrayList result = new ArrayList(p_list1);
        final Iterator iterator = p_list2.iterator();
        while (iterator.hasNext()) {
            result.remove(iterator.next());
        }
        return result;
    }
    /**
	 * <p>获取在两个集合中都包含的数据内容(交集)</p>
	 * <br>
	 * 样例:<br>
	 * intersection(null,null)=null;<br>
	 * intersection(new ArrayList(),null)=null;<br>
	 * List _list1 = new ArrayList();<br>
     * _list1.add("0");<br>
     * _list1.add("1");<br>
     * _list1.add("2");<br>
     * List _list2 = new ArrayList();<br>
     * _list2.add("1");<br>
     * _list2.add("2");<br>
     * _list2.add("3");<br>
     * intersection(_list1, _list2)={"1","2"};<br>
     * @param p_list1  List 第一个集合
     * @param p_list2  List 第二个集合
     * @return 返回两个集合的交集
     */
    public static List intersection(final List p_list1, final List p_list2) {
    	if(null==p_list1 || null==p_list2) return null;
        final ArrayList _result = new ArrayList();
        final Iterator _iterator = p_list2.iterator();
        while (_iterator.hasNext()) {
            final Object _o = _iterator.next();
            if (p_list1.contains(_o)) {
                _result.add(_o);
            }
        }
        return _result;
    }
    /**
     * Returns a List containing all the elements in <code>collection</code>
     * that are also in <code>retain</code>. The cardinality of an element <code>e</code>
     * in the returned list is the same as the cardinality of <code>e</code>
     * in <code>collection</code> unless <code>retain</code> does not contain <code>e</code>, in which
     * case the cardinality is zero. This method is useful if you do not wish to modify
     * the collection <code>c</code> and thus cannot call <code>collection.retainAll(retain);</code>.
     * 
     * @param collection  the collection whose contents are the target of the #retailAll operation
     * @param retain  the collection containing the elements to be retained in the returned collection
     * @return a <code>List</code> containing all the elements of <code>c</code>
     * that occur at least once in <code>retain</code>.
     * @throws NullPointerException if either parameter is null
     * @since Commons Collections 3.2
     */
    public static List retainAll(Collection collection, Collection retain) {
        List list = new ArrayList(Math.min(collection.size(), retain.size()));

        for (Iterator iter = collection.iterator(); iter.hasNext();) {
            Object obj = iter.next();
            if (retain.contains(obj)) {
                list.add(obj);
            }
        }
        return list;
    }
    /**
     * <p>将两个集合求并集，相加不做任何处理(distinct)</p>
     * <br>
     * 样例:<br>
     * union(null,null)=null;<br>
     * union(new ArrayList(),null)={};<br>
     * List _list1 = new ArrayList();<br>
     * _list1.add("0");<br>
     * _list1.add("1");<br>
     * _list1.add("2");<br>
     * List _list2 = new ArrayList();<br>
     * _list2.add("1");<br>
     * _list2.add("2");<br>
     * _list2.add("3");<br>
     * union(_list1, _list2)={"0","1","2","1","2","3"};<br>
     * @param p_list1 List 第一个集合
     * @param p_list2 List 第二个集合
     * @return 返回相加后的集合；
     */
    public static List union(final List p_list1, final List p_list2) {
    	if(null==p_list1 && null==p_list2) return null;
    	ArrayList _result1 = null;
    	ArrayList _result2 = null;
    	if(null==p_list1){
    		_result1 = new ArrayList();
    	}else{
    		_result1 = new ArrayList(p_list1);
    	}
    	
    	if(null==p_list2){
    		_result2 = new ArrayList();
    	}else{
    		_result2 = new ArrayList(p_list2);
    	}
        _result1.addAll(_result2);
        return _result1;        
    }
    /**
     * <p>两个集合相加，去除两个集合{@link #Collection}中相同的内容；</p>
     * <br>
     * 样例:<br>
     * sum(null,null)=null;<br>
     * sum(new ArrayList(),null)={};<br>
     * List _list1 = new ArrayList();<br>
     * _list1.add("0");<br>
     * _list1.add("1");<br>
     * _list1.add("2");<br>
     * List _list2 = new ArrayList();<br>
     * _list2.add("1");<br>
     * _list2.add("2");<br>
     * _list2.add("3");<br>
     * sum(_list1, _list2)={"0","1","2","3"};<br>
     * @param p_list1  List 第一个集合 
     * @param p_list2  List 第二个集合
     * @return  返回他们相加后的结果集合
     * @see com.olive.framework.utils.CollectionUtils#toProperties(Map)
     * @see com.olive.framework.utils.CollectionUtils#sum(List, List)
     * @throws NullPointerException if either list is null
     */
    public static List sum(final List p_list1, final List p_list2) {
        return subtract(union(p_list1, p_list2), intersection(p_list1, p_list2));
    }
    /**
     * <p>获取在第一个集合中存在，且在第二个集合中不存在的元素列表</p>
     * <br>
     * 样例:<br>
     * removeAll(null,null)=null;<br>
     * removeAll(new ArrayList(),null);<br>
     * removeAll(new ArrayList(),null).isEmpty()=true;<br>
     * List _list1 = new ArrayList();<br>
     * _list1.add("0");<br>
     * _list1.add("1");<br>
     * _list1.add("2");<br>
     * List _list2 = new ArrayList();<br>
     * _list2.add("1");<br>
     * _list2.add("2");<br>
     * _list2.add("3");<br>
     * List _rList = CollectionUtils.removeAll(_list1, _list2);<br>
     * _rList!=null;<br>
     * _rList.size()==1;<br>
     * _rList.get(0)="0";<br>
     * @param p_collection Collection 第一个集合
     * @param p_remove Collection 第二个集合
     * @return
     */
    public static List removeAll(Collection p_collection, Collection p_remove) {
    	if(null==p_collection) return null;  
    	List _list =null;
    	if(null==p_remove){
    		_list = new ArrayList(p_collection);
    		return _list;
    	}
   		_list= new ArrayList();         
        for (Iterator iter = p_collection.iterator(); iter.hasNext();) {
            Object obj = iter.next();
            if (p_remove.contains(obj) == false) {
                _list.add(obj);
            }
        }
        return _list;
    }
    /**
     * <p>如果至少一个元素存在于两个集合中,则返回<code>true</code>;
     * 换句话说,如果{@link #intersection} 的 <i>p_c1</i> 和 <i>p_c2</i>返回值不为空，该方法返回 <code>true</code>
     * @param p_c1  Collection 第一个集合
     * @param p_c2  Collection 第二个集合
     * @return 如果集合的交集不为空，则<code>true</code> 
     * @see #intersection(List, List)
     */
    public static boolean containsAny(final Collection p_c1, final Collection p_c2) {
    	if(null==p_c1 || null==p_c2) return false;
        if (p_c1.size() < p_c2.size()) {
            for (Iterator it = p_c1.iterator(); it.hasNext();) {
                if (p_c2.contains(it.next())) {
                    return true;
                }
            }
        } else {
            for (Iterator it = p_c2.iterator(); it.hasNext();) {
                if (p_c1.contains(it.next())) {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * <p消除p_list集合中重复的元素,要求：集合内对象复写equals方法</p>
     * @param p_list 待处理集合对象
     * @return List 消除重复对象后的集合
     * @throws Exception
     */
    public static List distinct(List p_list) throws Exception{
    	List _list2 = new ArrayList();
		for(int i=0;i<p_list.size();i++){
			if(!_list2.contains(p_list.get(i))){
				_list2.add(p_list.get(i));
			}
		}
		return _list2;
    }
    
    public static void main(String[] args)throws Exception {
    	List _c1 = new ArrayList();
    	List _c2 = new ArrayList();
    	_c1.add("1");
    	_c1.add("2");
    	_c1.add("2");
    	
    	
    	_c2.add("a");
    	_c2.add("b");
    	_c2.add("c");
    	_c2.add("d");
    
    	
    	List _c = CollectionUtils.distinct(_c1);
    	
		System.out.println("=========="+_c);
	}
}
