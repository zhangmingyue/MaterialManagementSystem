package com.igd.base.utils;


/** 工具类 */
public class Tools {



	
	/** 取得随机主文件名 */
	public synchronized static String getRndFilename(){
		return String.valueOf(System.currentTimeMillis());
	}
	
	
	
	/**
	 * 生成随机数(数字+字母)
	 * @param len 生成数的位数 len>=1
	 * @return 字符串
	 */
	public static String getRandomChar(int len){
		String sRand="";
		for (int i=0;i<len;i++){
			String tmp = getRandomChar();
            sRand += tmp;
		}
		return sRand;
	}
	
    private static String getRandomChar()
    {
		int rand = (int)Math.round(Math.random() * 2);
		long itmp = 0;
		char ctmp = '\u0000';
		switch (rand)
		{
			case 1:
				itmp = Math.round(Math.random() * 25 + 65);
				ctmp = (char)itmp;
				return String.valueOf(ctmp);
			case 2:
				itmp = Math.round(Math.random() * 25 + 97);
				ctmp = (char)itmp;
				return String.valueOf(ctmp);
			default :
				itmp = Math.round(Math.random() * 9);
				return String.valueOf(itmp);
		}
    }
    
    /** 截取指定字节数的字符串,且确保汉字不被拆分 */
	public static String cutString(String text, int textMaxChar){   
        int size,index;   
        String result = null;  
        if(textMaxChar<=0){   
        	result= text;   
        }else{   
            for(size=0,index=0;index<text.length()&&size<textMaxChar;index++){   
                size += text.substring(index,index+1).getBytes().length;   
            }   
            result = text.substring(0,index);   
        }  
        return result;   
    }
	
	
	/** 为以逗号分隔的字符串的每个单元加入引号,如:aa,bb-->'aa','bb' */
	public static String formatString(String src) {
		StringBuffer result = new StringBuffer();
		result.append("");
		if (src != null) {
			String[] tmp = src.split(",");
			result.append("'" + tmp[0] + "'");
			for (int i = 1; i < tmp.length; i++) {
				result.append(",'" + tmp[i] + "'");
			}
		}
		return result.toString();
	}
	
	
	public static void main(String[] args){
		for (int i=0;i<100;i++){
		System.out.println(getRandomChar(4));
		}
	}

}
