package com.igd.base.utils.selector;

/**
 * @author Administrator
 * 下拉选择列表内容
 */
public class SelectOptions {
	/**
	 * 显示内容
	 */
	private String texts;
	/**
	 * 显示值
	 */
	private String values;
	
	public String getTexts() {
		return texts;
	}
	public void setTexts(String texts) {
		this.texts = texts;
	}
	public String getValues() {
		return values;
	}
	public void setValues(String values) {
		this.values = values;
	}
	/**
	 * 默认构造函数
	 */
	public SelectOptions() {
		super();
	}
	/**
	 * 自定义构造函数
	 * @param text
	 * @param value
	 */
	public SelectOptions(String values, String texts) {
		super();
		this.texts = texts;
		this.values = values;
	}
	public boolean equals(Object obj) {
		if(obj instanceof SelectOptions){
			if(((SelectOptions)obj).getValues().equals(this.getValues())) return true;
		}
		return false;
	}
	
}
