package com.igd.base.utils.selector;

import java.util.List;

import com.igd.base.action.BaseAction;
import com.igd.base.utils.collection.CollectionUtils;




public class SelectTagAction extends BaseAction{	

	private static final long serialVersionUID = 6805221078847149935L;

	/**
     * 页面查询列表
     * @param list
     * @param value
     * @param text
     * @return
     */
    protected List prepareQueryTag(List p_list, String p_value, String p_text) throws Exception{
       List _queryList = CollectionUtils.wrapToOptions(p_list, p_value, p_text);       
       _queryList.add(0, new SelectOptions("%", "全部"));       
       return _queryList;
    }
    
    /**
     * 页面选择列表
     * @param list
     * @param value
     * @param text
     * @return
     */
    protected List prepareInputTag(List p_list, String p_value, String p_text) throws Exception{
        List _inputList = CollectionUtils.wrapToOptions(p_list, p_value, p_text);
        _inputList.add(0, new SelectOptions("%", "请选择"));
        return _inputList;
    }
}
