package com.igd.base.utils;

public class UtilArgumentException extends Exception{
	public UtilArgumentException(){
		super("ERROR:输入参数非法");
	}
	public UtilArgumentException(String p_message){
		super(p_message);
	}
}
