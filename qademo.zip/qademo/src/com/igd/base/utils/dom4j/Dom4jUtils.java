
package com.igd.base.utils.dom4j;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.DocumentResult;
import org.dom4j.io.DocumentSource;
import org.dom4j.io.SAXReader;

/**
 * @author Administrator
 * 
 */
public class Dom4jUtils {
	/**字符集常量*/
	private static final String DEFAULT_ENCODE = "GB2312";
	/*************************创建文档对象*********************************/
	/**
   * 使用默认值创建xml文档
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocument() {
		org.dom4j.Document document = org.dom4j.DocumentHelper.createDocument();
		return document;
	}	
	/**
   * 根据指定的url对象创建一个Document
   * @param url URL URL对象
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocument(URL url){
		if (url == null) {
			System.out.println("URL对象无效，不能创建对象!");
			return null;
		}
		try {
			org.dom4j.Document document = new org.dom4j.io.SAXReader().read(url);
			return document;
		} catch (Exception de) {
			System.out.println("DOM对象创建失败，相关信息如下：" + de.getMessage());
			return null;
		}
	}
	/**
   * 根据指定的字符串创建一个Document
   * @param str String 源字符串
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocument(String str){
		if ((str == null) || (str.equals(""))) {
			System.out.println("源字符串无效，不能创建对象!");
			return null;
		}
		try {
			org.dom4j.Document document = new org.dom4j.io.SAXReader().read(new StringReader(str));
			return document;
		} catch (Exception de) {
			System.out.println("DOM对象创建失败，相关信息如下：" + de.getMessage());
			return null;
		}
	}
	/**
   * 根据指定的Document文档建立Document文档
   * @param document org.dom4j.Document DOM对象
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocument(org.dom4j.Document document) {
		if (document == null) {
			System.out.println("DOM对象无效，不能创建对象!");
			return null;
		}
		return (org.dom4j.Document) document.clone();
	}
	/**
   * 创建一个空文档，并且加入用户指定名称的样式单
   * @param strStylePath String 指定样式单的路径信息
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocumentWithStyle(String strStylePath) {
		if ((strStylePath == null) || (strStylePath.equals(""))) {
			System.out.println("请指定样式单的路径信息!");
			return null;
		}
		String str = "type=\"text/xsl\" href= \"" + strStylePath + "\"";
		try {
			org.dom4j.Document document = createDocument();
			document.addProcessingInstruction("xml-stylesheet", str);
			return document;
		} catch (Exception e) {
			System.out.println("样式单信息无效，不能创建对象!");
			return null;
		}
	}
	/**
   * 创建一个空文档，根据用户指定的名称创建根节点
   * @param rootName String 根元素名称
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocumentWithRoot(String rootName) {
		if ((rootName == null) || (rootName.equals(""))) {
			System.out.println("根元素名称无效，不能创建对象!");
			return null;
		}
		org.dom4j.Document document = org.dom4j.DocumentHelper.createDocument();
		document.addElement(rootName);
		return document;
	}
	/**
   * 根据指定的文件对象创建一个Document
   * @param file File File对象
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocumentFromFile(File file){
		if (file == null) {
			System.out.println("File对象无效，不能创建对象!");
			return null;
		}
		try {			
			SAXReader saxReader = new SAXReader();
			saxReader.setEntityResolver(new   NoopEntityResolver());
			return saxReader.read(file);
		} catch (Exception de) {
			System.out.println("DOM对象创建失败，相关信息如下：" + de.getMessage());
			return null;
		}
	}
	/**
   * 根据指定的文件路径创建一个Document
   * @param filePath String 文件路径
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document createDocumentFromFilePaht(String filePath){
		if (filePath == null) {
			System.out.println("文件路径无效，不能创建对象!");
			return null;
		}
		try {			
			SAXReader saxReader = new SAXReader();
			saxReader.setEntityResolver(new   NoopEntityResolver());
			return saxReader.read(filePath);
		} catch (Exception de) {
			System.out.println("DOM对象创建失败，相关信息如下：" + de.getMessage());
			return null;
		}
	}
	/*****************************************************************************************/
	/**
   * 将Document对象转换成字符串;
   * @param document org.dom4j.Document DOM对象
   * @return String
   */
	public static String toString(org.dom4j.Document document){
		return toString(document, DEFAULT_ENCODE);
	}
	/**
   * 将Document对象转换成字符串;
   * @param document org.dom4j.Document DOM对象
   * @param strEncode String 字符集名称
   * @return String
   */
	public static String toString(org.dom4j.Document document, String strEncode){
		if (document == null) {
			System.out.println("DOM对象无效，不能完成转换!");
			return null;
		}
		if ((strEncode == null) || (strEncode.equals(""))) {
			System.out.println("字符集名称无效，不能完成转换!");
			return null;
		}
		try {
			/***建立格式化对象，整齐格式*/
			org.dom4j.io.OutputFormat format = org.dom4j.io.OutputFormat.createPrettyPrint();
			format.setEncoding(strEncode);
			format.setExpandEmptyElements(true);
			//建立字符输出流对象
			StringWriter out = new StringWriter();
			//使用格式化对象在字符输出流上建立Document的输出对象
			org.dom4j.io.XMLWriter writer = new org.dom4j.io.XMLWriter(out, format);
			//将document文档写入
			writer.write(document);
			writer.close();
			//转换成字符串然后返回
			return out.toString();
		} catch (IOException ioe) {
			System.out.println("IO异常:" + ioe.getMessage());
			return null;
		}
	}
	/*****************************************************************************************/
	/**
   * 根据输入的文档将该文档写入到参数指定的文件中;
   * @param document org.dom4j.Document DOM对象
   * @param filePathName String 目标文件路径
   */
	public static void writeDocumentToFile(org.dom4j.Document document,String filePathName) throws Exception  {
		writeDocumentToFile(document, DEFAULT_ENCODE, filePathName);
	}
	/**
   * 根据输入的文档将该文档写入到参数指定的文件中;
   * @param document org.dom4j.Document DOM对象
   * @param strEncode String 字符集名称
   * @param filePathName String 文件路径
   */
	public static void writeDocumentToFile(org.dom4j.Document document,String strEncode,String filePathName)throws Exception {
		if (document == null) System.out.println("DOM对象无效!");
		if ((strEncode == null) || (strEncode.equals(""))) System.out.println("字符集名称无效，不能完成转换!");
		if ((filePathName == null) || (filePathName.equals(""))) System.out.println("文件路径无效!");
		//设置格式
		org.dom4j.io.OutputFormat format = org.dom4j.io.OutputFormat.createPrettyPrint();
		format.setEncoding(strEncode);
		//根据格式在文件上建立输出流对象
		org.dom4j.io.XMLWriter writer =new org.dom4j.io.XMLWriter(new FileWriter(filePathName), format);
		//输出对象将文档内容写入
		writer.write(document);
		writer.close();
	}
	/*************************************************************************************************/
	/**
   * 根据样式单转换xml到html文档
   * @param document org.dom4j.Document DOM对象
   * @param stylestring String xslt样式单字符串
   * @return org.dom4j.Document
   */
	public static org.dom4j.Document styleDocumentToHtml(org.dom4j.Document document,String stylestring){
		if (document == null) {
			System.out.println("DOM对象无效!");
			return null;
		}
		if ((stylestring == null) || (stylestring.equals(""))) {
			System.out.println("样式单内容无效!");
			return null;
		}
		try {
			//建立类工厂实例
			TransformerFactory factory = TransformerFactory.newInstance();
			//根据xslt路径字符串建立翻译模型
			Transformer transformer =factory.newTransformer(new StreamSource(new StringReader(stylestring)));
			//根据给定的Document建立文档源
			DocumentSource source = new DocumentSource(document);
			//建立一个空的文档结果
			DocumentResult result = new DocumentResult();
			//根据给定xslt进行翻译
			transformer.transform(source, result);
			//返回翻译后的文档
			org.dom4j.Document transformedDoc = result.getDocument();
			return transformedDoc;
		} catch (TransformerException tfe) {
			System.out.println("转换异常:" + tfe.getMessage());
			return null;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	/**
   * 根据样式单转换xml到html文档
   * @param strDoc String 源字符串
   * @param stylestring String xslt样式单字符串
   * @return String
   */
	public static org.dom4j.Document styleDocumentToHtml(String strDoc, String stylestring){
		if ((strDoc == null) || (strDoc.equals(""))) {
			System.out.println("源字符串无效!");
			return null;
		}
		org.dom4j.Document doc = createDocument(strDoc);
		return styleDocumentToHtml(doc, stylestring);
	}
	/*************************************************************************************************/
	/**
   * 校验xml文档是否正确,重载的方法
   * @param file File File对象
   * @throws Exception
   */
	public static void parseXML(Document document) throws Exception {
		try {
			document.normalize();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	/**
   * 校验xml文档是否正确
   * @param strDoc String 源字符串
   */
	public static void parseXML(String strDoc) throws Exception {
		try {
			parseXML(createDocument(strDoc));
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	/**
   * 校验xml文档是否正确,重载的方法
   * @param file File File对象
   * @throws Exception
   */
	public static void parseXML(File file) throws Exception {
		try {
			parseXML(createDocumentFromFile(file));
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	/*********************************************************************************/
	/**
   * 在指定的元素下根据属性值查找元素
   * @param element org.dom4j.Element 父元素
   * @param attname String 属性名称
   * @param attrvalue String 属性值
   * @return List
   */
	public static List queryElementsByAttrValue(org.dom4j.Element element,String attname,String attrvalue) {
		if (element == null) {
			System.out.println("父元素无效!");
			return null;
		}
		if (attname == null) {
			System.out.println("属性名称无效!");
			return null;
		}
		if (attrvalue == null) {
			System.out.println("属性值无效!");
			return null;
		}
		List list = element.elements();
		List listrtn = new Vector();
		for (int i = 0; i < list.size(); i++) {
			org.dom4j.Element ele = (org.dom4j.Element) list.get(i);
			if (ele.attributeValue(attname).equals(attrvalue)) {
				listrtn.add(ele);
			}
		}
		return listrtn;
	}
	/**
	 * * 添加根节点的child *
	 * 
	 * @param nodeName* 节点名 *
	 * @param nodeValue 节点值
	 */
	public static void addElementFromRoot(Document document,String nodeName, String nodeValue) {
		Element root = document.getRootElement();
		Element level1 = root.addElement(nodeName);
		level1.addText(nodeValue);
	}
	/**
	 * * 获得某个节点的值 *	 * 
	 * @param nodeName 节点名称
	 */
	public static String getElementValue(Document document,String nodeName) {
		try {
			Node node = document.selectSingleNode("//" + nodeName);
			return node.getText() == null ? "" : node.getText();
		} catch (Exception e1) {
			System.out.println("getElementValue() Exception：" + e1.getMessage());
			return null;
		}
	}

	/**
	 * 获得某个节点的子节点的值 * 
	 * @param nodeName *
	 * @param childNodeName *
	 * @return
	 */
	public static String getElementValue(Document document,String nodeName, String childNodeName) {
		try {
			Node node = document.selectSingleNode("//" + nodeName + "/"+ childNodeName);
			return node.getText() == null ? "" : node.getText();
		} catch (Exception e1) {
			System.out.println("getElementValue() Exception：" + e1.getMessage());
			return null;
		}
	}

	/**
	 * * 设置一个节点的text  
	 * @param nodeName 节点名
	 * @param nodeValue 节点值
	 */
	public static void setElementValue(Document document,String nodeName, String nodeValue) {
		try {
			Node node = document.selectSingleNode("//" + nodeName);
			node.setText(nodeValue);
		} catch (Exception e1) {
			System.out.println("setElementValue() Exception:" + e1.getMessage());
		}
	}
	/**
	 * * 设置一个节点值  
	 * @param nodeName 父节点名 *
	 * @param childNodeName 节点名 *
	 * @param nodeValue 节点值
	 */
	public static void setElementValue(Document document,String nodeName, String childNodeName,String nodeValue) {
		try {
			Node node = document.selectSingleNode("//" + nodeName + "/"+ childNodeName);
			node.setText(nodeValue);
		} catch (Exception e1) {
			System.out.println("setElementValue() Exception:" + e1.getMessage());
		}
	}	
}

