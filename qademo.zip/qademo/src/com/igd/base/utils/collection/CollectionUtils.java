package com.igd.base.utils.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.igd.base.utils.ClassUtils;
import com.igd.base.utils.selector.SelectOptions;


/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CollectionUtils {
	public static List wrapToOptions(List list,String value,String text) throws Exception{
		List wrapList = new ArrayList();
//		wrapList.add(new SelectOptions("%","请选择"));
		if(list==null) return wrapList;
		for(Iterator it = list.iterator(); it.hasNext();){
			Object obj = it.next();
			if(obj==null) continue;
			
			Object objValue = ClassUtils.getValue(obj, value);
			Object objText = ClassUtils.getValue(obj, text);
			if(objValue!=null){
				wrapList.add(new SelectOptions((String)objValue,(String)objText));
			}
		}
		return wrapList;
	}
}
