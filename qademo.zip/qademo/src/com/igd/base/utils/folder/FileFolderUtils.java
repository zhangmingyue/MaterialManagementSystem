package com.igd.base.utils.folder;

import java.io.File;

/**
 * 创建和删除web服务器下的文件夹。
 */
public class FileFolderUtils {
	/**
	 * 判断文件夹是否存在。
	 * @param 文件夹路径
	 * @return true 不存在 false 存在。
	 * @throws Exception
	 */
	public static boolean checkFileFold(String strFoldName) throws FolderCreateException,Exception{
		
		File fileCreateF = new File(strFoldName);
		if(!fileCreateF.exists()){
			return true;
		 }else{ 			
			return false;
		 }
	}
	/**
	 * 根据文件夹路径创建文件夹。
	 * @param 文件夹路径
	 * @return true 成功。
	 * @throws Exception
	 */
	public static boolean createFileFold(String strFoldName) throws FolderCreateException,Exception{
		
		File fileCreateF = new File(strFoldName);
		if(!fileCreateF.isDirectory()){
			try{
				fileCreateF.mkdir();
			}catch(Exception e){
				e.printStackTrace();
				throw new FolderCreateException("创建新文件夹失败！");
			}
		 }else{ 			
			throw new FolderCreateException("指定的文件夹名称和现有的文件夹名称重复，请重新指定一个新的文件夹名称！");
		 }
		 return true;
	}
	
	/**
	 * 根据文件夹路径删除文件夹。
	 * @param 文件夹路径。
	 * @return true 成功。
	 * @throws Exception
	 */
	public static boolean deleteFileFold(String strFileDelF) throws FolderDeleteException,Exception{
		File fileDelF = new File(strFileDelF);
  		try{
			if(fileDelF.exists()){				
				File[] fileArrCheck = fileDelF.listFiles();
				if(!(fileArrCheck.length > 0)){
					fileDelF.delete();
				}else{
					for(int i = 0 ;i < fileArrCheck.length ; i++){
						fileArrCheck[i].delete();
					}
					fileDelF.delete();
				} 
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new FolderDeleteException("文件夹删除操作错误！");
		}
		return true;
	}
	
	/**
	 * 删除文件夹。
	 * @param 文件夹路径。
	 * @throws Exception
	 */
	public static void delFolder(String folderPath) {
	     try {
	        delAllFile(folderPath); //删除完里面所有内容
	        String filePath = folderPath;
	        filePath = filePath.toString();
	        java.io.File myFilePath = new java.io.File(filePath);
	        myFilePath.delete(); //删除空文件夹
	     } catch (Exception e) {
	       e.printStackTrace(); 
	     }
	}

	/**
	 * 删除指定文件夹下所有文件。
	 * @param 文件夹路径。
	 * @throws Exception
	 */
	public static boolean delAllFile(String path) {
	       boolean flag = false;
	       File file = new File(path);
	       if (!file.exists()) {
	         return flag;
	       }
	       if (!file.isDirectory()) {
	         return flag;
	       }
	       String[] tempList = file.list();
	       File temp = null;
	       for (int i = 0; i < tempList.length; i++) {
	          if (path.endsWith(File.separator)) {
	             temp = new File(path + tempList[i]);
	          } else {
	              temp = new File(path + File.separator + tempList[i]);
	          }
	          if (temp.isFile()) {
	             temp.delete();
	          }
	          if (temp.isDirectory()) {
	             delAllFile(path + "/" + tempList[i]);//先删除文件夹里面的文件
	             //delFolder(path + "/" + tempList[i]);//再删除空文件夹
	             flag = true;
	          }
	       }
	       return flag;
	     }
}
