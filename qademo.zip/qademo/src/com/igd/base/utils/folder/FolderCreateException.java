package com.igd.base.utils.folder;

/**
 * @author Administrator
 * 创建文件夹异常
 */
public class FolderCreateException extends Exception {
	/**
	 * @param message
	 */
	public FolderCreateException(String message) {
		super(message);
	}
	
}
