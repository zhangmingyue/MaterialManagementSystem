package com.igd.base.utils.folder;

/**
 * @author Administrator
 * 删除文件夹异常
 */
public class FolderDeleteException extends Exception {
	/**
	 * @param message
	 */
	public FolderDeleteException(String message) {
		super(message);
	}
	
}
