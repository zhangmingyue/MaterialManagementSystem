/**
 * 
 */
package com.igd.base.utils.file;

/**
 * @author Administrator
 * 文件操作异常处理
 */
public class FileUtilException extends Exception {

	public FileUtilException() {
		super();
	}

	public FileUtilException(String message) {
		super(message);
	}


}
