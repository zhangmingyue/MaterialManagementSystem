package com.igd.base.utils.excle;

import java.io.OutputStream;
/**
 * 数据导出excel接口
 * @author zhangdayu
 */
public interface ExcelOut {
	public void writeExcel(OutputStream os) throws Exception;
}
