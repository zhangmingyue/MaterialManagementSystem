/*
 * 创建日期 2005-2-18
 *
 * 更改所生成文件模板为
 * 窗口 > 首选项 > Java > 代码生成 > 代码和注释
 */
package com.igd.base.utils.excle;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.Result;
import com.opensymphony.xwork2.ognl.OgnlValueStack;




/**
 * @author Administrator
 *
 * 更改所生成类型注释的模板为
 * 窗口 > 首选项 > Java > 代码生成 > 代码和注释
 */
public class ExportExcelResult implements Result {	
	private ByteArrayOutputStream exportExcel;
	private String fileName; /** * 文件名称 */
	public void execute(ActionInvocation arg0) throws Exception {
		OgnlValueStack stack = (OgnlValueStack) ServletActionContext.getRequest().getAttribute("webwork.valueStack");		
		fileName = (String) stack.findValue("fileName");
		exportExcel = (ByteArrayOutputStream) stack.findValue("exportExcel");
		if (exportExcel == null) {
			throw new NullPointerException("No exportExcel found");
		}
		System.out.println("result");
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("application/vnd.ms-excel;charset=utf-8");
		response.setContentLength(exportExcel.size());
		//String fn=new String("库存台帐".getBytes("GB2312"),"ISO-8859-1");
		response.setHeader("Content-Disposition", "attachment; filename="+fileName);
		OutputStream out = response.getOutputStream();
		//ServletOutputStream out = response.getOutputStream();
		exportExcel.writeTo(out);	            
		exportExcel.close();
		//out.flush();
	}
}
