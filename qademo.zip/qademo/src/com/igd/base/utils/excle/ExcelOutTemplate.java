package com.igd.base.utils.excle;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

//import com.olive.path.ResourcePath;

/**
 * 数据导出excel显示
 * @author liangwj
 * jsp调用如下：
 *	 ＜%@page import="com.olive.Jexcel.out.ExcelOutTemplate" %＞
 *	 ＜%
 *	　 response.reset();
 *	　 response.setContentType("application/vnd.ms-excel");
 *	   ExcelOutTemplate excelOut = new ExcelOutTemplate();
 *	　 excelOut.writeExcel(response.getOutputStream());
 *	 %＞
 *
 */
public class ExcelOutTemplate implements ExcelOut {
	//缺省数据字体大小
	protected int defaultDataFontsize = 12;
	//缺省标题字体大小
	protected int defaultTitleFontsize = 20;
	//缺省条件字体大小
	protected int defaultCondFontsize = 12;
	//指定数据单元格的各种属性
	protected WritableCellFormat wcfFCD = null;
	//指定标题单元格的各种属性
	protected WritableCellFormat wcfFCT = null;
	//指定条件单元格的各种属性
	protected WritableCellFormat wcfFCC = null;
	
	//初始化
	{
		setDefaultDataFont();
		setDefaultTitleFont();
		setDefaultCondFont();
	}
	
	/**
	 * 测试数据1
	 * @return List 数据
	 */
	public List getData(){
		ArrayList list = new ArrayList();
		String[] data = new String[5];
		for(int i=0;i<10;i++){
			data[0] = "当你孤单你会想起当你孤单你会想起";
			data[1] = "比朋友多一点";
			data[2] = "孤单北半球";
			data[3] = "你听得到";
			data[4] = "天才白痴往日情";
			list.add(i,data);
		}				
		return list;
	}
	
	/**
	 * 测试数据2
	 * @return List 数据
	 */
	public List getData1(){
		ArrayList list = new ArrayList();
		String[] data = new String[5];
		for(int i=0;i<20;i++){
			data[0] = "测试";
			data[1] = "成功";
			data[2] = "半球";
			data[3] = "天才";
			data[4] = "白痴";
			list.add(i,data);
		}				
		return list;
	}
	
	public void writeExcel(OutputStream os) throws Exception {
		
		//报表演示1
		Object work = newWork(os);
		
		Object sheet = newSheet(work,0,"测试");
		
		setColumnWidth(sheet,1,new int[] {10,20,20,20,20,20});
		
		setMergeCells(sheet,1,2,6,2);
		
		setTitle(sheet,"我的歌曲列表测试",1,2,500);
		
		setMergeCells(sheet,1,4,6,4);
		
		setCondition(sheet,"单位：傲立公司                                              日期：2004-11-29",1,4,300);
		
		setRowHeight(sheet,5,400);
		setRowHeight(sheet,6,400);
		setData(sheet,"序号",1,5,1,6,0);
		setData(sheet,"中国歌曲",2,5,4,5,0);
		setData(sheet,"外国歌曲",5,5,6,5,0);
		setData(sheet,"抒情",2,6,0);
		setData(sheet,"美声",3,6,0);
		setData(sheet,"摇滚",4,6,0);
		setData(sheet,"抒情",5,6,0);
		setData(sheet,"摇滚",6,6,0);
		
		setMutiRowDataAndIndex(sheet,getData(),1,7,5, new int[] {0,4,1,0,2,1},300);
		
		closeWork(work);
		
		//报表演示2
		
//		Object workbook = newWorkBook(new File(getResourceFilePath("template/Test.xls")));
//		Object work = newWork(workbook,os);
//		Object sheet = getSheet(work,0);
//		
//		setData(sheet,"1",3,4,0);
//		setData(sheet,"2",5,6,0);
//		setData(sheet,"3",7,8,0);
//		
//		closeWork(work);
	}
	
	//建立文件,以文件方式
	public Object newWorkBook(File file) throws Exception {
		try {
			Workbook wb = Workbook.getWorkbook(file);	
			return wb;
		} catch (IOException e) {
			System.out.println("建立文件错误：newWork");
			e.printStackTrace();
			throw e;
		}
	}
	
	//建立文件,以输出流方式
	public Object newWork(Object wb,OutputStream os) throws Exception {
		try {
			WritableWorkbook wwb = Workbook.createWorkbook(os,(Workbook) wb);			
			return wwb;
		} catch (IOException e) {
			System.out.println("建立文件错误：newWork");
			e.printStackTrace();
			throw e;
		}
	}	
	
	//建立文件,以输出流方式
	public Object newWork(OutputStream os) throws Exception {
		try {
			WritableWorkbook wwb = Workbook.createWorkbook(os);	
			return wwb;
		} catch (IOException e) {
			System.out.println("建立文件错误：newWork");
			e.printStackTrace();
			throw e;
		}
	}
	
	//写入Exel工作表，关闭Excel工作薄对象
	public void closeWork(Object wwb) throws Exception {
		try {
			((WritableWorkbook) wwb).write();
			((WritableWorkbook) wwb).close();			
		} catch (IOException e) {
			System.out.println("关闭Excel工作薄对象错误：closeWork");
			e.printStackTrace();
			throw e;
		}
	}
	
	//写入Exel工作表，关闭Excel工作薄对象
	 public void closeWorkBook(Object wb){
		  ((Workbook) wb).close();			  
	 }
	
	//获得一个工作表对象,0-代表第一个，1-代表第二个,...
	public Object getSheet(Object wwb,int series) throws Exception {
		if(wwb == null || !(wwb instanceof WritableWorkbook)){
			System.out.println("文件为空错误");
			throw new Exception("文件为空错误");
		}else{
			WritableSheet ws = ((WritableWorkbook) wwb).getSheet(series);
			return ws;
		}
	}
	
	//获得工作表数目
	  public int getNumberOfSheets(Object wwb) throws Exception {
		  if(wwb == null || !(wwb instanceof WritableWorkbook)){
			  System.out.println("文件为空错误");
			  throw new Exception("文件为空错误");
		  }else{			  
			  return ((WritableWorkbook) wwb).getNumberOfSheets();
		  }
	  }
	
	//建立一个工作表对象,0-代表第一个，1-代表第二个,...
	public Object newSheet(Object wwb,int series,String title) throws Exception {
		if(wwb == null || !(wwb instanceof WritableWorkbook)){
			System.out.println("文件为空错误");
			throw new Exception("文件为空错误");
		}else{
			WritableSheet ws = ((WritableWorkbook) wwb).createSheet(title, series);
			return ws;
		}
	}
	
	//删除一个工作表对象,0-代表第一个，1-代表第二个,...
	  public void removeSheet(Object wwb,int series) throws Exception {
		  if(wwb == null || !(wwb instanceof WritableWorkbook)){
			  System.out.println("文件为空错误");
			  throw new Exception("文件为空错误");
		  }else{
			  ((WritableWorkbook) wwb).removeSheet(series);
		  }
	  }
	
	//复制一个工作表对象,,org-代表被复制表号，title-代表复制表名,target-复制表号
	  public void copySheet(Object wwb,int org,String title,int target) throws Exception {
		  if(wwb == null || !(wwb instanceof WritableWorkbook)){
			  System.out.println("文件为空错误");
		  	throw new Exception("文件为空错误");
		  }else{
			  ((WritableWorkbook) wwb).copySheet(org,title,target);
			 
		  }
	  }	
	
	//设置行的高度
	public void setRowHeight(Object ws,int row,int height) throws Exception {		
		try {
			((WritableSheet) ws).setRowView(row,height); 
		} catch (RowsExceededException e) {
			System.out.println("设置行高度错误：setRowHeight");
			e.printStackTrace();
			throw e;
		}
	}
	
	//设置列的宽度
	public void setColumnWidth(Object ws,int column,int width){		
		((WritableSheet) ws).setColumnView(column,width); 		
	}
	
	//设置列的宽度,从开始列起，按照width数组的数据顺序设置列宽
	public void setColumnWidth(Object ws,int startcolumn,int[] width){
		for(int i = 0;i < width.length;i++){		
			setColumnWidth(ws,startcolumn,width[i]);	
			startcolumn++;
		}	
	}
	
	//合并单元
	public void setMergeCells(Object ws,int column,int row,int mergecolumn,int mergerow) throws Exception {
		((WritableSheet) ws).mergeCells(column,row,mergecolumn,mergerow);
	}
	
	//添加数据，多行操作
	public void setMutiRowData(Object ws,List list,int startcolumn,int startrow,int columns,int[] align) throws Exception {
		try {
			for(int i=0;i<list.size();i++){
				String[] tmpstr = (String[])list.get(i);
				for(int j=0;j<columns;j++){
					setData(ws,tmpstr[j],startcolumn + j,startrow + i,align[j]);
				}
			}	
		} catch (Exception e) {
			System.out.println("添加数据，多行操作错误：setMutiRowData");
			e.printStackTrace();
			throw e;
		}	
	}
	
	//添加数据，多行操作,可设置行高
	public void setMutiRowData(Object ws,List list,int startcolumn,int startrow,int columns,int[] align,int rowheight) throws Exception {
		try {
			for(int i=0;i<list.size();i++){
				String[] tmpstr = (String[])list.get(i);
				for(int j=0;j<columns;j++){
					setData(ws,tmpstr[j],startcolumn + j,startrow + i,align[j]);
					setRowHeight(ws,startrow + i,rowheight);
				}
			}	
		} catch (Exception e) {
			System.out.println("添加数据，多行操作错误：setMutiRowData");
			e.printStackTrace();
			throw e;
		}	
	}
	
	//添加数据，多行操作，带序号
	public void setMutiRowDataAndIndex(Object ws,List list,int startcolumn,int startrow,int columns,int[] align) throws Exception {
		try {
			for(int i=0;i<list.size();i++){
				setData(ws,Integer.toString(i + 1),startcolumn,startrow + i,0);				
				String[] tmpstr = (String[])list.get(i);
				for(int j=0;j<columns;j++){
					setData(ws,tmpstr[j],startcolumn + j + 1,startrow + i,align[j]);
				}
			}	
		} catch (Exception e) {
			System.out.println("添加数据，多行操作错误：setMutiRowDataAndIndex(Object ws,List list,int startcolumn,int startrow,int columns,int[] align)");
			e.printStackTrace();
			throw e;
		}	
	}
	
	//添加数据，多行操作,可设置行高，带序号
	public void setMutiRowDataAndIndex(Object ws,List list,int startcolumn,int startrow,int columns,int[] align,int rowheight) throws Exception {
		try {
			for(int i=0;i<list.size();i++){
				setData(ws,Integer.toString(i + 1),startcolumn,startrow + i,0);
				String[] tmpstr = (String[])list.get(i);
				for(int j=0;j<columns;j++){
					setData(ws,tmpstr[j],startcolumn + j + 1,startrow + i,align[j]);
					setRowHeight(ws,startrow + i,rowheight);
				}
			}	
		} catch (Exception e) {
			System.out.println("添加数据，多行操作错误：setMutiRowDataAndIndex(Object ws,List list,int startcolumn,int startrow,int columns,int[] align,int rowheight)");
			e.printStackTrace();
			throw e;
		}	
	}
	
	//添加标题
	public void setTitle(Object ws,String title,int column,int row) throws Exception {
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCT());
			wcfFC.setAlignment(Alignment.CENTRE);	
			wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			wcfFC.setWrap(true);
			Label label = new Label(column, row, title, wcfFC);				
			((WritableSheet) ws).addCell(label);
		} catch (WriteException e) {
			System.out.println("添加标题错误：setTitle");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加标题
	  public void setBorderTitle(Object ws,String title,int column,int row) throws Exception {
		  try {
			  WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCT());
			  wcfFC.setAlignment(Alignment.CENTRE);	
			  wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			  wcfFC.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN,jxl.format.Colour.BLACK);
			  wcfFC.setWrap(true);
			  Label label = new Label(column, row, title, wcfFC);				
			  ((WritableSheet) ws).addCell(label);
		  } catch (WriteException e) {
			  System.out.println("添加标题错误：setTitle");
			  e.printStackTrace();
			  throw e;
		  }
	  }
	
	//添加标题,带行高
	public void setTitle(Object ws,String title,int column,int row,int rowheight) throws Exception {
		try {
			setTitle(ws,title,column,row);
			setRowHeight(ws,row,rowheight);
		} catch (WriteException e) {
			System.out.println("添加标题错误：setTitle");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加条件
	public void setCondition(Object ws,String condition,int column,int row) throws Exception {
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCC());
			wcfFC.setAlignment(Alignment.CENTRE);
			wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			wcfFC.setWrap(true);	
			Label label = new Label(column, row, condition, wcfFC);				
			((WritableSheet) ws).addCell(label);
		} catch (WriteException e) {
			System.out.println("添加条件错误：setCondition");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加条件,带行高
	public void setCondition(Object ws,String condition,int column,int row,int rowheight) throws Exception {
		try {
			setCondition(ws,condition,column,row);
			setRowHeight(ws,row,rowheight);
		} catch (WriteException e) {
			System.out.println("添加条件错误：setCondition");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据，默认对一个单元格操作,无边框
	public void setDataNoborder(Object ws,String data,int column,int row) throws Exception {
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCD());
			wcfFC.setAlignment(Alignment.CENTRE);
			wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			wcfFC.setWrap(true);
			Label label = new Label(column, row, data, wcfFC);				
			((WritableSheet) ws).addCell(label);
		} catch (WriteException e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据,可以指定对齐方式:0-CENTRE,1-LEFT,2-RIGHT,3-GENERAL,4-JUSTIFY,5-FILL,无边框
	public void setDataNoborder(Object ws,String data,int column,int row,int align) throws Exception {
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCD());
			wcfFC.setAlignment(getAlignment(align));
			wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			wcfFC.setWrap(true);	
			Label label = new Label(column, row, data, wcfFC);				
			((WritableSheet) ws).addCell(label);
		} catch (WriteException e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row,int align)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据,可以指定合并行列方式,无边框
	public void setDataNoborder(Object ws,String data,int column,int row,int mergecolumn,int mergerow) throws Exception {
		try {
			setDataNoborder(ws,data,column,row);
			setMergeCells(ws,column,row,mergecolumn,mergerow);
		} catch (Exception e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row,int mergecolumn,int mergerow)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据,可以指定合并行列方式及对齐方式:0-CENTRE,1-LEFT,2-RIGHT,3-GENERAL,4-JUSTIFY,5-FILL,无边框
	public void setDataNoborder(Object ws,String data,int column,int row,int mergecolumn,int mergerow,int align) throws Exception {
		try {
			setDataNoborder(ws,data,column,row,align);
			setMergeCells(ws,column,row,mergecolumn,mergerow);
		} catch (Exception e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row,int mergecolumn,int mergerow,int align)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据，默认对一个单元格操作,有边框
	public void setData(Object ws,String data,int column,int row) throws Exception {
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCD());
			wcfFC.setAlignment(Alignment.CENTRE);
			wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			wcfFC.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN,jxl.format.Colour.BLACK);
			wcfFC.setWrap(true);
			Label label = new Label(column, row, data, wcfFC);				
			((WritableSheet) ws).addCell(label);
		} catch (WriteException e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据,可以指定对齐方式:0-CENTRE,1-LEFT,2-RIGHT,3-GENERAL,4-JUSTIFY,5-FILL,有边框
	public void setData(Object ws,String data,int column,int row,int align) throws Exception {
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCD());
			wcfFC.setAlignment(getAlignment(align));
			wcfFC.setVerticalAlignment(VerticalAlignment.CENTRE);
			wcfFC.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN,jxl.format.Colour.BLACK);
			wcfFC.setWrap(true);	
			Label label = new Label(column, row, data, wcfFC);				
			((WritableSheet) ws).addCell(label);
		} catch (WriteException e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row,int align)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据,可以指定合并行列方式,有边框
	public void setData(Object ws,String data,int column,int row,int mergecolumn,int mergerow) throws Exception {
		try {
			setData(ws,data,column,row);
			setMergeCells(ws,column,row,mergecolumn,mergerow);
		} catch (Exception e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row,int mergecolumn,int mergerow)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//添加数据,可以指定合并行列方式及对齐方式:0-CENTRE,1-LEFT,2-RIGHT,3-GENERAL,4-JUSTIFY,5-FILL,有边框
	public void setData(Object ws,String data,int column,int row,int mergecolumn,int mergerow,int align) throws Exception {
		try {
			setData(ws,data,column,row,align);
			setMergeCells(ws,column,row,mergecolumn,mergerow);
		} catch (Exception e) {
			System.out.println("添加数据错误：setData(Object ws,String data,int column,int row,int mergecolumn,int mergerow,int align)");
			e.printStackTrace();
			throw e;
		}
	}
	
	//转换对齐方式
	public Alignment getAlignment(int align) throws Exception {		
		switch(align){
			case 0:return Alignment.CENTRE;
			case 1:return Alignment.LEFT;
			case 2:return Alignment.RIGHT;
			case 3:return Alignment.GENERAL;
			case 4:return Alignment.JUSTIFY;
			case 5:return Alignment.FILL;
			default:throw new Exception("齐方式指定错误");
		}
	}
	//设置数据缺省的字体
	public WritableCellFormat setDefaultDataFont(){
		WritableFont wfcc = new WritableFont(WritableFont.ARIAL,getDefaultDataFontsize(),WritableFont.NO_BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
		wcfFCD = new WritableCellFormat(wfcc);
		return wcfFCD;
	}
	
	//设置数据的字体
	public WritableCellFormat setDataFont(int fontsize){
		WritableFont wfcc = new WritableFont(WritableFont.ARIAL,fontsize,WritableFont.NO_BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
		wcfFCD = new WritableCellFormat(wfcc);
		return wcfFCD;
	}
	
	//设备字体的颜色 liuyc 2006-05-18
	public WritableCellFormat setDataFont(int fontsize,String color){
		if(color.equals("black")){
			WritableFont wfcc = new WritableFont(WritableFont.ARIAL,fontsize,WritableFont.NO_BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
			wcfFCD = new WritableCellFormat(wfcc);
		}else{
			WritableFont wfcc = new WritableFont(WritableFont.ARIAL,fontsize,WritableFont.NO_BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.RED);
			wcfFCD = new WritableCellFormat(wfcc);			
		}
		return wcfFCD;
	}
	
	//设备单元格背景色
	public WritableCellFormat setCellBackColor(String color){
		try {
			WritableCellFormat wcfFC = new WritableCellFormat(getWcfFCD());
			if(color.equals("GRAY_25")){
				wcfFC.setBackground(Colour.GRAY_25);
			}
			if(color.equals("PALE_BLUE")){
				wcfFC.setBackground(Colour.PALE_BLUE);
			}
			if(color.equals("")){
				wcfFC.setBackground(Colour.WHITE);
			}
			//.setBackGround(Colour.RED);//设置单元格的颜色为红色       XXXXXXXXXX
			//wcfc = new jxl.write.Label(6,0,"i love china",wcfFC);
			
			wcfFCD = new WritableCellFormat(wcfFC);
		} catch (WriteException e) {
			// TODO 自动生成 catch 块
			e.printStackTrace();
		}
		return wcfFCD;
	}
	
	//设置标题缺省的字体
	public WritableCellFormat setDefaultTitleFont(){
		WritableFont wfcc = new WritableFont(WritableFont.ARIAL,getDefaultTitleFontsize(),WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
		wcfFCT = new WritableCellFormat(wfcc);
		return wcfFCT;
	}
	
	//设置标题的字体
	public WritableCellFormat setTitleFont(int fontsize){
		WritableFont wfcc = new WritableFont(WritableFont.ARIAL,fontsize,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
		wcfFCT = new WritableCellFormat(wfcc);
		return wcfFCT;
	}
	
	//设置条件缺省的字体
	public WritableCellFormat setDefaultCondFont(){
		WritableFont wfcc = new WritableFont(WritableFont.ARIAL,getDefaultCondFontsize(),WritableFont.NO_BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
		wcfFCC = new WritableCellFormat(wfcc);
		return wcfFCC;
	}
	
	//设置条件的字体
	public WritableCellFormat setCondFont(int fontsize){
		WritableFont wfcc = new WritableFont(WritableFont.ARIAL,fontsize,WritableFont.NO_BOLD,false,UnderlineStyle.NO_UNDERLINE,Colour.BLACK);
		wcfFCC = new WritableCellFormat(wfcc);
		return wcfFCC;
	}
	

	/**
	 * Returns the defaultCondFontsize.
	 * @return int
	 */
	public int getDefaultCondFontsize() {
		return defaultCondFontsize;
	}

	/**
	 * Returns the defaultDataFontsize.
	 * @return int
	 */
	public int getDefaultDataFontsize() {
		return defaultDataFontsize;
	}

	/**
	 * Returns the defaultTitleFontsize.
	 * @return int
	 */
	public int getDefaultTitleFontsize() {
		return defaultTitleFontsize;
	}

	/**
	 * Returns the wcfFCC.
	 * @return WritableCellFormat
	 */
	public WritableCellFormat getWcfFCC() {
		return wcfFCC;
	}

	/**
	 * Returns the wcfFCD.
	 * @return WritableCellFormat
	 */
	public WritableCellFormat getWcfFCD() {
		return wcfFCD;
	}

	/**
	 * Returns the wcfFCT.
	 * @return WritableCellFormat
	 */
	public WritableCellFormat getWcfFCT() {
		return wcfFCT;
	}

	/**
	 * Sets the defaultCondFontsize.
	 * @param defaultCondFontsize The defaultCondFontsize to set
	 */
	public void setDefaultCondFontsize(int defaultCondFontsize) {
		this.defaultCondFontsize = defaultCondFontsize;
	}

	/**
	 * Sets the defaultDataFontsize.
	 * @param defaultDataFontsize The defaultDataFontsize to set
	 */
	public void setDefaultDataFontsize(int defaultDataFontsize) {
		this.defaultDataFontsize = defaultDataFontsize;
	}

	/**
	 * Sets the defaultTitleFontsize.
	 * @param defaultTitleFontsize The defaultTitleFontsize to set
	 */
	public void setDefaultTitleFontsize(int defaultTitleFontsize) {
		this.defaultTitleFontsize = defaultTitleFontsize;
	}	
	
	/**
　　* 如果找不到,则返回null
　　* @param sResourceName
　　* @return
　　*/
//	public String getResourceFilePath(String sResourceName){
//		return ResourcePath.getResourceFilePath(sResourceName);		
//	} 
}
