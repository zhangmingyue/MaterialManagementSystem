package com.igd.base.action;

import org.apache.struts2.ServletActionContext;

import com.igd.admin.model.User;
import com.igd.base.exception.BaseException;
import com.igd.base.pagination.Page;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class BaseAction extends ActionSupport implements Preparable{

	private  String msg;								//提示信息
	
	private String result;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	protected Page currentPage ;
	
	protected int currPage = 1;
	protected int pageSize = 5; 					//默认每页显示5个

	public int getCurrPage() {
		return currPage;
	}

	public void setCurrPage(int currPage) {
		this.currPage = currPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public Page getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Page page) {
		this.currentPage = page;
	}
	
	public String execute() throws Exception {

		throw new BaseException("您所请求的资源不存在!!");

	}
	public String getUserName(){
		User user=(User)this.get("user");
		if(user!=null)
			return user.getUserName();
		else
			return "";
	}

	protected Object get(String name) {		
		return ActionContext.getContext().getSession().get(name);
		
	}

	protected void set(String name, Object value) {
		ActionContext.getContext().getSession().put(name, value);
	}

	protected void remove(Object key) {
		ActionContext.getContext().getSession().remove(key);
	}

	protected void setTip(String tip){
		this.set("tip", tip);
	}

	public void prepare() throws Exception {
		this.clearErrorsAndMessages();
	}

	public String getActionName(){
		return this.getClass().getName()+"_";
		
	}
	
	public void clearSession(){
		ServletActionContext.getRequest().getSession().invalidate();
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


}
