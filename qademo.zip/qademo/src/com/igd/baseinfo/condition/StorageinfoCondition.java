package com.igd.baseinfo.condition;

import org.hibernate.Query;

import com.igd.base.pagination.Condition;

public class StorageinfoCondition extends Condition {

	public String getInitialHql(){
		this.setOrderByItem("mp.num");
		 return "from Storageinfo as mp where mp.status='1'";
	}
	public Query preparedParams(Query query) {
	
		return query;
	}


}
