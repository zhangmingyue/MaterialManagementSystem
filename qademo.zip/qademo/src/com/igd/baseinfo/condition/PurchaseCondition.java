package com.igd.baseinfo.condition;

import org.hibernate.Query;

import com.igd.base.pagination.Condition;

public class PurchaseCondition extends Condition {
	private String sname;
	private String linkm;
	private String spell;
	private int status = 1;
	public String getInitialHql(){
		this.setOrderByItem("m.spell");
		StringBuffer hql;
		if(status == 1){
			hql=new StringBuffer("from Purchaseinfo as m where  m.linkman like:linkm " +
				" and m.status='1' and( m.name like:sname or m.spell like :sname)");
		}else{
			hql=new StringBuffer("from Purchaseinfo as m where  m.linkman like:linkm " +
					" and m.status='0' and( m.name like:sname or m.spell like :sname)");
		}
		 return hql.toString();
	}
	public Query preparedParams(Query query) {
		query.setParameter("sname", (this.sname==null||"".equals(this.sname))?"%":this.getSname()+"%");
		query.setParameter("linkm", (this.linkm==null||"".equals(this.linkm))?"%":"%"+this.getLinkm()+"%");
	
		return query;
	}
	public String getSpell() {
		return spell;
	}
	public void setSpell(String spell) {
		this.spell = spell;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getLinkm() {
		return linkm;
	}
	public void setLinkm(String linkm) {
		this.linkm = linkm;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	


}
