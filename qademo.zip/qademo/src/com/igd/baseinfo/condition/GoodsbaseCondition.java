package com.igd.baseinfo.condition;

import org.hibernate.Query;

import com.igd.base.pagination.Condition;

public class GoodsbaseCondition extends Condition {
	private String gname;
	private String cid;
	private String gnum;
	public String getInitialHql(){
		this.setOrderByItem("g.num asc");
		
		if("002003".equals(this.cid)){
			StringBuffer hql=new StringBuffer("from Goodsbase as g where (g.name like:gname or g.spell like:gname) and " +
					" (g.cl_code='002003' or g.cl_code='002004')  and g.num like:gnum and g.status<>'0'");
			return hql.toString();
			
		}else{
			
			StringBuffer hql=new StringBuffer("from Goodsbase as g where (g.name like:gname or g.spell like:gname) and " +
					" g.cl_code like:cid  and g.num like:gnum and g.status<>'0'");
			return hql.toString();
		}
		
		 
	}
	public Query preparedParams(Query query) {
		query.setParameter("gname", (this.gname==null||"".equals(this.gname))?"%":"%"+this.getGname()+"%");
		query.setParameter("gnum", (this.gnum==null||"".equals(this.gnum))?"%":this.getGnum()+"%");
		if(!"002003".equals(this.cid)){
			
			query.setParameter("cid", (this.cid==null||"".equals(this.cid))?"%":this.getCid());
		}
		return query;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getGnum() {
		return gnum;
	}
	public void setGnum(String gnum) {
		this.gnum = gnum;
	}



}
