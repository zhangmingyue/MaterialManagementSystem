package com.igd.baseinfo.condition;

import org.hibernate.Query;

import com.igd.base.pagination.Condition;

public class StoreplaceCondition extends Condition {
	private String store;
	public String getInitialHql(){
		StringBuffer hql=new StringBuffer("from Storeplace as st ");
		if(store!=null && !"".equals(store)){
			hql=hql.append( "  where   st.storage.id ='"+store+"'");
		}

		 return hql.toString();
	}
	public Query preparedParams(Query query) {
	
		return query;
	}
	public String getStore() {
		return store;
	}
	public void setStore(String store) {
//		if(store==null||"".equals(store)){
//			store="%";
//		}
		this.store = store;
	}


}
