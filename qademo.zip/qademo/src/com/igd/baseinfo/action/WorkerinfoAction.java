package com.igd.baseinfo.action;

import java.util.List;

import com.igd.base.action.BaseAction;
import com.igd.baseinfo.condition.ManagerinfoCondition;
import com.igd.baseinfo.condition.WorkerinfoCondition;
import com.igd.baseinfo.model.Managerinfo;
import com.igd.baseinfo.model.Storageinfo;
import com.igd.baseinfo.model.Workerinfo;
import com.igd.baseinfo.service.IManagerinfoService;
import com.igd.baseinfo.service.IWorkerinfoService;





//库工信息Action
public class WorkerinfoAction extends BaseAction {
	private  Workerinfo wf;												
	private IWorkerinfoService workerinfoService;								
	
	private WorkerinfoCondition condition = new WorkerinfoCondition();	
	//库工ID
	private String id;
    private List ids;

    private boolean isempty=true;
    private List<Workerinfo> workerinfolist;

	//分页
	public String pagedQuery() {
		System.out.println(condition.getCname());
		System.out.println(condition.getCnum());
		try {
			currentPage = workerinfoService.pagedQuery(this.getCondition());
			this.set(getActionName(), condition);
			workerinfolist=this.getWorkerlist();
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}



	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("in it");
		return super.execute();
	}



	public String save() {
		try {
			System.out.println("id:"+wf.getId());
			System.out.println("name:"+wf.getName());
			System.out.println("remark:"+wf.getRemark());
			workerinfoService.saveObj(wf);
			id=wf.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存库工信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询库工信息数据
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {
			workerinfolist=this.getWorkerlist();
			wf=workerinfoService.queryById(id);
		
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询库工信息异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}
	


	/**
	 * 根据ID删除库工信息
	 * @return
	 */
	public String remove(){
		try {
			workerinfoService.remove(ids);
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除库工信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}

	//添加跳转查询 
	public String addQuery(){
		try {
			this.getWorkerlist();
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	
	public List <Workerinfo> getWorkerlist(){
		
		return workerinfoService.getWorkerlist();
		
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}


	public WorkerinfoCondition getCondition() {
		WorkerinfoCondition sessionCondition = (WorkerinfoCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(WorkerinfoCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}
	



	public Workerinfo getWf() {
		return wf;
	}



	public void setWf(Workerinfo wf) {
		this.wf = wf;
	}



	public IWorkerinfoService getWorkerinfoService() {
		return workerinfoService;
	}



	public void setWorkerinfoService(IWorkerinfoService workerinfoService) {
		this.workerinfoService = workerinfoService;
	}



	public boolean isIsempty() {
		return isempty;
	}



	public void setIsempty(boolean isempty) {
		this.isempty = isempty;
	}



	public List<Workerinfo> getWorkerinfolist() {
		return workerinfolist;
	}



	public void setWorkerinfolist(List<Workerinfo> workerinfolist) {
		this.workerinfolist = workerinfolist;
	}


}
