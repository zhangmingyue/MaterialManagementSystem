package com.igd.baseinfo.action;

import java.util.List;

import com.igd.admin.model.Dept;
import com.igd.admin.service.IDeptService;
import com.igd.base.action.BaseAction;
import com.igd.base.pagination.Condition;
import com.igd.baseinfo.condition.ManagerinfoCondition;
import com.igd.baseinfo.model.Managerinfo;
import com.igd.baseinfo.model.Storageinfo;
import com.igd.baseinfo.service.IManagerinfoService;





//保管员信息Action
public class ManagerinfoAction extends BaseAction {
	private  Managerinfo manager;												
	private IManagerinfoService managerinfoService;								
	private  ManagerinfoCondition condition=new ManagerinfoCondition();				
	private String id;
    private List ids;
    private List<Storageinfo> storagelist; 
    private boolean isempty=true;
    private List goodsList;
    private List codelist;
    private List otherlist;
    private List curgoodslist;
    private String cl_id;
    private String gname;
    private List<String> gids;
	//分页
	public String pagedQuery() {
		try {
			currentPage = managerinfoService.pagedQuery(this.getCondition());
			this.set(getActionName(), condition);
			storagelist=this.getStoragelist();
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}



	public String save() {
		try {
			managerinfoService.saveObj(manager);
			id=manager.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存保管员信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询保管员信息数据
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {
			storagelist=this.getStoragelist();
			manager=managerinfoService.queryById(id);
		
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询保管员信息异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}
	public void setStoragelist(List<Storageinfo> storagelist) {
		this.storagelist = storagelist;
	}


	/**
	 * 根据ID删除保管员信息
	 * @return
	 */
	public String remove(){
		try {
			managerinfoService.remove(ids);
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除保管员信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}

	//添加跳转查询 
	public String addQuery(){
		try {
			this.getStoragelist();
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	public String addGoodsInfoQuery(){
		isempty=false;
		System.out.println("isempty==="+isempty);
		try {
			goodsList=managerinfoService.queryGoodsListByType(cl_id,gname);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		System.out.println("goodsList==="+goodsList.size());
		codelist=managerinfoService.queryGoodsType();
		System.out.println("codelist==="+codelist.size());
		try {
			otherlist=managerinfoService.queryOtherGoodsList(goodsList);
			System.out.println("otherlist==="+otherlist.size());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		curgoodslist=managerinfoService.queryCurGoodslist(id);
		System.out.println("curgoodslist==="+curgoodslist.size());
		return "addGoods";
	}
	
	public String addGoodsInfoChoose(){
		
		try {
			managerinfoService.addGoods(id, gids,cl_id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			addActionError("选择物资信息处理错误:"+e.getMessage());
		}
		return "addGoods";
	}
	public String addGoodsInfo(){
//		System.out.println("id===*********"+id);
		goodsList=managerinfoService.queryGoodsList(id);
	
		codelist=managerinfoService.queryGoodsType();
		
		isempty=managerinfoService.isGoodsEmpty(id);
		
		curgoodslist=managerinfoService.queryCurGoodslist(id);
		
		try {
			cl_id=managerinfoService.queryById(id).getStorage().getType();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "addGoods";
	}
	
	public List <Storageinfo> getStoragelist(){
		return managerinfoService.getStoragelist();
		
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}



	public Managerinfo getManager() {
		return manager;
	}


	public void setManager(Managerinfo manager) {
		this.manager = manager;
	}


	public IManagerinfoService getManagerinfoService() {
		return managerinfoService;
	}


	public void setManagerinfoService(IManagerinfoService managerinfoService) {
		this.managerinfoService = managerinfoService;
	}


	public ManagerinfoCondition getCondition() {
		ManagerinfoCondition sessionCondition = (ManagerinfoCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(ManagerinfoCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}



	public boolean isIsempty() {
		return isempty;
	}



	public void setIsempty(boolean isempty) {
		this.isempty = isempty;
	}



	public List getGoodsList() {
		return goodsList;
	}



	public void setGoodsList(List goodsList) {
		this.goodsList = goodsList;
	}



	public List getCodelist() {
		return codelist;
	}



	public void setCodelist(List codelist) {
		this.codelist = codelist;
	}



	public List getOtherlist() {
		return otherlist;
	}



	public void setOtherlist(List otherlist) {
		this.otherlist = otherlist;
	}



	public List getCurgoodslist() {
		return curgoodslist;
	}



	public void setCurgoodslist(List curgoodslist) {
		this.curgoodslist = curgoodslist;
	}



	public String getCl_id() {
		return cl_id;
	}



	public void setCl_id(String cl_id) {
		this.cl_id = cl_id;
	}



	public String getGname() {
		return gname;
	}



	public void setGname(String gname) {
		this.gname = gname;
	}



	public List<String> getGids() {
		return gids;
	}



	public void setGids(List<String> gids) {
		this.gids = gids;
	}

}
