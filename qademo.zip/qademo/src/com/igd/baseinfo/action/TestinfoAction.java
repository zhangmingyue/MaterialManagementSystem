package com.igd.baseinfo.action;

import java.util.List;

import com.igd.admin.model.Code;
import com.igd.base.action.BaseAction;
import com.igd.base.pagination.Condition;
import com.igd.baseinfo.condition.GoodsbaseCondition;
import com.igd.baseinfo.condition.TestinfoCondition;
import com.igd.baseinfo.model.Goodsbase;
import com.igd.baseinfo.model.Testinfo;
import com.igd.baseinfo.service.IGoodsbaseService;
import com.igd.baseinfo.service.ITestinfoService;






//检验和效期Acton
public class TestinfoAction extends BaseAction {
	private  Testinfo test;												
	private ITestinfoService testifnoService;								
	private  TestinfoCondition condition=new TestinfoCondition();				
	private String id;
	private String gid;
	private String iszjt;
	//分页
	public String pagedQuery() {
		try {

		
			currentPage = testifnoService.pagedQuery(this.getCondition());

			this.set(getActionName(), condition);
			
	
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}

	public String save() {
		try {
			testifnoService.saveObj(test);
			id=test.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存检验单信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询物资基本信息
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {

			test=testifnoService.queryById(id);

		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询检验单信息异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}



	//添加跳转查询 
	public String addQuery(){
		System.out.println("********************");
		try {
			gid=this.gid;
			String iszjt=testifnoService.checkZjt(gid);
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	


	public TestinfoCondition getCondition() {
		TestinfoCondition sessionCondition = (TestinfoCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	} 


	public void setCondition(TestinfoCondition condition) {
		this.condition = condition;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public Testinfo getTest() {
		return test;
	}

	public void setTest(Testinfo test) {
		this.test = test;
	}

	public ITestinfoService getTestifnoService() {
		return testifnoService;
	}

	public void setTestifnoService(ITestinfoService testifnoService) {
		this.testifnoService = testifnoService;
	}

	public String getGid() {
		return gid;
	}

	public void setGid(String gid) {
		this.gid = gid;
	}

	public String getIszjt() {
		return iszjt;
	}

	public void setIszjt(String iszjt) {
		this.iszjt = iszjt;
	}


	

}
