package com.igd.baseinfo.action;

import java.util.List;

import com.igd.admin.model.Dept;
import com.igd.admin.model.User;
import com.igd.admin.service.IDeptService;
import com.igd.base.action.BaseAction;
import com.igd.base.pagination.Condition;
import com.igd.baseinfo.condition.SupplierCondition;
import com.igd.baseinfo.model.Supplierinfo;
import com.igd.baseinfo.service.ISupplierinfoService;

//供应商Action
public class SupplierinfoAction extends BaseAction {
	private  Supplierinfo supplier;												
	private ISupplierinfoService supplierService;								
	private  SupplierCondition condition=new SupplierCondition();				
	private String id;
    private List ids;
    private String curselected;
    private List goodsList;
    private List codelist;
    private String cl_id;
    private List curgoodslist;
    private List<String> gids;
    private boolean isempty=true;
    private String gname;
    private List otherlist;
	//分页
	public String pagedQuery() {
		try {

			User u=(User) this.get("user");
			String cid=supplierService.getCodeByUser(u);
			System.out.println("CID====="+cid);
			this.getCondition().setCid(cid);
			currentPage = supplierService.pagedQuery(this.getCondition());

			this.set(getActionName(), condition);

			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}

	

	public String save() {
		try {
			supplierService.saveObj(supplier);
			id=supplier.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存供应商信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询库位信息
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {
//			storagelist=this.getStoragelist();
			supplier=supplierService.queryById(id);
		
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询供应商异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}


	/**
	 * 根据ID删除供应商信息
	 * @return
	 */
	public String remove(){
		try {
			supplierService.remove(ids);
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除供应商异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}

	//添加跳转查询 
	public String addQuery(){
		try {
//			this.getStoragelist();
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	public String addGoodsInfoQuery(){
		isempty=false;
		
		goodsList=supplierService.queryGoodsListByType(cl_id,gname); 
		
		codelist=supplierService.queryGoodsType();
		
		try {
			otherlist=supplierService.queryOtherGoodsList(goodsList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		curgoodslist=supplierService.queryCurGoodslist(id);
		
		return "addGoods";
	}
	
	public List getOtherlist() {
		return otherlist;
	}



	public void setOtherlist(List otherlist) {
		this.otherlist = otherlist;
	}



	public String addGoodsInfo(){
//		System.out.println("id===*********"+id);
		goodsList=supplierService.queryGoodsList(id);
	
		codelist=supplierService.queryGoodsType();
		
		isempty=supplierService.isGoodsEmpty(id);
		
		curgoodslist=supplierService.queryCurGoodslist(id);
		
		try {
			cl_id=supplierService.queryById(id).getCl_id();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "addGoods";
	}
	
	public String addGoodsInfoChoose(){
		
		try {
			supplierService.addGoods(id, gids,cl_id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			addActionError("选择物资信息处理错误:"+e.getMessage());
		}
		return "addGoods";
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}



	public SupplierCondition getCondition() {
		SupplierCondition sessionCondition = (SupplierCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(SupplierCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}

	public Supplierinfo getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplierinfo supplier) {
		this.supplier = supplier;
	}

	public ISupplierinfoService getSupplierService() {
		return supplierService;
	}

	public void setSupplierService(ISupplierinfoService supplierService) {
		this.supplierService = supplierService;
	}

	public String getCurselected() {
		return curselected;
	}

	public void setCurselected(String curselected) {
		this.curselected = curselected;
	}

	public List getGoodsList() {
		return goodsList;
	}

	public void setGoodsList(List goodsList) {
		this.goodsList = goodsList;
	}

	public List getCodelist() {
		return codelist;
	}

	public void setCodelist(List codelist) {
		this.codelist = codelist;
	}

	public String getCl_id() {
		return cl_id;
	}

	public void setCl_id(String cl_id) {
		this.cl_id = cl_id;
	}



	public List<String> getGids() {
		return gids;
	}



	public void setGids(List<String> gids) {
		this.gids = gids;
	}



	public List getCurgoodslist() {
		return curgoodslist;
	}



	public void setCurgoodslist(List curgoodslist) {
		this.curgoodslist = curgoodslist;
	}



	public boolean isIsempty() {
		return isempty;
	}



	public void setIsempty(boolean isempty) {
		this.isempty = isempty;
	}



	public String getGname() {
		return gname;
	}



	public void setGname(String gname) {
		this.gname = gname;
	}

	

}
