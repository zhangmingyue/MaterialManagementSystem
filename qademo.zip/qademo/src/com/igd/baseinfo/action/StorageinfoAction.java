package com.igd.baseinfo.action;

import java.util.List;

import com.igd.base.action.BaseAction;
import com.igd.baseinfo.condition.StorageinfoCondition;
import com.igd.baseinfo.model.Storageinfo;
import com.igd.baseinfo.service.IStorageinfoService;

public class StorageinfoAction extends BaseAction {
	private Storageinfo storage;												
	private IStorageinfoService storageinfoService;									
	private StorageinfoCondition condition=new StorageinfoCondition();				
	private String id;
	private List curworklist;
	private List worklist;
	private List wids;
	private List typelist;

	private List ids;

	public String pagedQuery() {
		try {
			currentPage = storageinfoService.pagedQuery(this.getCondition());
			List<Storageinfo> storages = (List<Storageinfo>)storageinfoService.pagedQuery(this.getCondition()).getData();
			System.out.println("=============1");
			for(Storageinfo s:storages) {
				System.out.println("=============2");
				System.out.println(s.getId());
				System.out.println(s.getName());
				System.out.println("=============3");
			}
			this.set(getActionName(), condition);
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}

	public String save() {
		try {
			storageinfoService.saveObj(storage);
			id=storage.getId();
			typelist=storageinfoService.queryType();
			System.out.println("typelist====="+typelist.size());
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存库房信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询库房数据
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {
			storage=storageinfoService.queryById(id);
			typelist=storageinfoService.queryType();
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询库房信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "queryById";
	}

	public String remove(){
		try {
			storageinfoService.remove(ids);
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除库房信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}


	public String addQuery(){
		try {

			typelist=storageinfoService.queryType();
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	public String queryAllWorklist(){

		worklist=storageinfoService.qureyWorkerlist();
		curworklist=storageinfoService.queryCurWorklist(id);

		return "querychosework";
	}

	public String choseWorker() {
		storageinfoService.choseWorker(id, wids);
		return "chosework";
	}
	
	public String removeChoseWorker(){
		storageinfoService.remove_SW(id, wids);
		return "chosework"; 
	}
	public List getCurworklist() {
		return curworklist;
	}




	public void setCurworklist(List curworklist) {
		this.curworklist = curworklist;
	}


	public List getWorklist() {
		return worklist;
	}


	public void setWorklist(List worklist) {
		this.worklist = worklist;
	}


	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}


	public Storageinfo getStorage() {
		return storage;
	}


	public void setStorage(Storageinfo storage) {
		this.storage = storage;
	}


	public IStorageinfoService getStorageinfoService() {
		return storageinfoService;
	}


	public void setStorageinfoService(IStorageinfoService storageinfoService) {
		this.storageinfoService = storageinfoService;
	}


	public StorageinfoCondition getCondition() {
		StorageinfoCondition sessionCondition = (StorageinfoCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(StorageinfoCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}
	public List getWids() {
		return wids;
	}


	public void setWids(List wids) {
		this.wids = wids;
	}


	public List getTypelist() {
		return typelist;
	}


	public void setTypelist(List typelist) {
		this.typelist = typelist;
	}
}
