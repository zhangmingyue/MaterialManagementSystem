package com.igd.baseinfo.action;

import java.util.Date;
import java.util.List;

import com.igd.admin.model.Code;
import com.igd.admin.model.CodeCategory;
import com.igd.base.action.BaseAction;
import com.igd.baseinfo.condition.PurchaseCondition;
import com.igd.baseinfo.model.Purchaseinfo;
import com.igd.baseinfo.service.IPurchaseinfoService;

//供应商Action
public class PurchaseinfoAction extends BaseAction {
	private  Purchaseinfo purchase;												
	private IPurchaseinfoService purchaseService;								
	private  PurchaseCondition condition=new PurchaseCondition();
	private Code code;
	private List<Code> codes;
	private String id;
    private List ids;
    private String curselected;
	//分页
	public String pagedQuery() {
		try {
			condition = this.getCondition();
			condition.setStatus(1);
			currentPage = purchaseService.pagedQuery(condition);

			this.set(getActionName(), condition);

			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}
	public String recycle() {
		try {

			condition = this.getCondition();
			condition.setStatus(0);
			currentPage = purchaseService.pagedQuery(condition);

			this.set(getActionName(), condition);

			return "recycle";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}
	public String save() {
		try {
			System.out.println("codeid:"+code.getId());
			code = purchaseService.queryCodeById(code.getId());
			System.out.println("codeid:"+code.getId());
			purchase.setProvinceName(code.getName());
			purchase.setProvinceNumber(code.getCode());
			Date updateTime = new Date();
			purchase.setUpdateTime(updateTime);
			purchaseService.saveObj(purchase);
			id=purchase.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存购货方信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询购货方信息
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {
//			storagelist=this.getStoragelist();
			purchase=purchaseService.queryById(id);
			System.out.println(purchase.getProvinceNumber()+""+purchase.getProvinceName());
			CodeCategory cc = new CodeCategory();
			cc.setId("402882ea40d2f0880140d360d5db0007");
			codes = purchaseService.codeList(cc);
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询购货方异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}


	public Purchaseinfo getPurchase() {
		return purchase;
	}

	public void setPurchase(Purchaseinfo purchase) {
		this.purchase = purchase;
	}

	public IPurchaseinfoService getPurchaseService() {
		return purchaseService;
	}

	public void setPurchaseService(IPurchaseinfoService purchaseService) {
		this.purchaseService = purchaseService;
	}

	/**
	 * 根据ID删除购货方信息
	 * @return
	 */
	public String remove(){
		try {
			purchaseService.remove(ids);
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除购货方异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}

	//添加跳转查询 
	public String addQuery(){
		try {
//			this.getStoragelist();
			CodeCategory cc = new CodeCategory();
			cc.setId("402882ea40d2f0880140d360d5db0007");
			codes = purchaseService.codeList(cc);
			for(Code c:codes) {
				System.out.println(c.getName());
			}
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	

	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}



	public PurchaseCondition getCondition() {
		PurchaseCondition sessionCondition = (PurchaseCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(PurchaseCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}


	public String getCurselected() {
		return curselected;
	}

	public void setCurselected(String curselected) {
		this.curselected = curselected;
	}

	public Code getCode() {
		return code;
	}

	public void setCode(Code code) {
		this.code = code;
	}

	public List<Code> getCodes() {
		return codes;
	}

	public void setCodes(List<Code> codes) {
		this.codes = codes;
	}

	

	

}
