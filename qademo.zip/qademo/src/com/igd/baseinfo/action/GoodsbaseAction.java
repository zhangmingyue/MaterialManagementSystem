package com.igd.baseinfo.action;

import java.util.List;

import com.igd.admin.model.Code;
import com.igd.admin.model.User;
import com.igd.base.action.BaseAction;
import com.igd.base.pagination.Condition;
import com.igd.baseinfo.condition.GoodsbaseCondition;
import com.igd.baseinfo.model.Goodsarea;
import com.igd.baseinfo.model.Goodsbase;
import com.igd.baseinfo.service.IGoodsbaseService;






//库工Action
public class GoodsbaseAction extends BaseAction {
	private  Goodsbase gb;												
	private IGoodsbaseService goodsbaseService;								
	private  GoodsbaseCondition condition=new GoodsbaseCondition();				
	private String id;
    private List ids;
    private List<Code> gblist; 
    private List<Code> codelist;
    private String curselected;
    private String curnamed;
    private List agelist;
    private List arealist; //产地列表
    private Goodsarea garea;
    private List aids;
	//分页
	public String pagedQuery() {
		try {

			User u=(User) this.get("user");
			
			if(!"1".equals(u.getId())){
				String cid=goodsbaseService.getCodeByUser(u);
				System.out.println("****CID========="+cid);
				this.set("tcode", cid);
				this.getCondition().setCid(cid);
			}
			currentPage = goodsbaseService.pagedQuery(this.getCondition());

			this.set(getActionName(), condition);
			
			codelist=goodsbaseService.getCodeList();
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}

	public String save() {
		System.out.println("norms==="+gb.getNorms());
		System.out.println("status==="+gb.getStatus());
		try {
			goodsbaseService.saveObj(gb);
			id=gb.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存物资基本信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询物资基本信息
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {

			gb=goodsbaseService.queryById(id);
			codelist=goodsbaseService.getCodeList(); 
			agelist=goodsbaseService.getAgeList();
			arealist=goodsbaseService.queryAreaList(id);
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询物资基本信息异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}

	
	/**
	 * 根据ID删除物资基本信息
	 * @return
	 */
	public String remove(){
		try {
			goodsbaseService.remove(ids);
			id=id;
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除物资基本信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}

	//添加跳转查询 
	public String addQuery(){
		try {
//			this.getStoragelist();
			codelist=goodsbaseService.getCodeList(); 
//			curnamed=(String)goodsbaseService.getCurName(curselected);
			agelist=goodsbaseService.getAgeList();
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	public String addArea(){
		try {
			System.out.println("-------------over---"+id);
			arealist=goodsbaseService.queryAreaList(id);
			id=id;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
		return "addarea";
	}
	
	public String savaArea(){
		try {
			goodsbaseService.saveArea(garea);
		
			id=garea.getGb_id();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	
		return "savearea";
	}
	public String  removeArea(){
		try {
			goodsbaseService.removeArea(aids);
			id=id;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
		return "savearea";
	}
	public String getCurnamed() {
		return curnamed;
	}

	public void setCurnamed(String curnamed) {
		this.curnamed = curnamed;
	}

	public GoodsbaseCondition getCondition() {
		GoodsbaseCondition sessionCondition = (GoodsbaseCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(GoodsbaseCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}




	public String getCurselected() {
		return curselected;
	}



	public void setCurselected(String curselected) {
		this.curselected = curselected;
	}


	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}



	public Goodsbase getGb() {
		return gb;
	}


	public void setGb(Goodsbase gb) {
		this.gb = gb;
	}


	public IGoodsbaseService getGoodsbaseService() {
		return goodsbaseService;
	}


	public void setGoodsbaseService(IGoodsbaseService goodsbaseService) {
		this.goodsbaseService = goodsbaseService;
	}


	

	public List<Code> getGblist() {
		return gblist;
	}

	public void setGblist(List<Code> gblist) {
		this.gblist = gblist;
	}

	public List<Code> getCodelist() {
		return codelist;
	}


	public void setCodelist(List<Code> codelist) {
		this.codelist = codelist;
	}

	public List getAgelist() {
		return agelist;
	}

	public void setAgelist(List agelist) {
		this.agelist = agelist;
	}

	public List getArealist() {
		return arealist;
	}

	public void setArealist(List arealist) {
		this.arealist = arealist;
	}

	public Goodsarea getGarea() {
		return garea;
	}

	public void setGarea(Goodsarea garea) {
		this.garea = garea;
	}

	public List getAids() {
		return aids;
	}

	public void setAids(List aids) {
		this.aids = aids;
	}

	

}
