package com.igd.baseinfo.action;

import java.util.List;

import com.igd.admin.model.Dept;
import com.igd.admin.service.IDeptService;
import com.igd.base.action.BaseAction;
import com.igd.base.pagination.Condition;

import com.igd.baseinfo.condition.StoreplaceCondition;
import com.igd.baseinfo.model.Storageinfo;
import com.igd.baseinfo.model.Storeplace;
import com.igd.baseinfo.service.IStoreplaceService;





//库位Action
public class StoreplaceAction extends BaseAction {
	private  Storeplace sp;												
	private IStoreplaceService storeplaceService;								
	private  StoreplaceCondition condition=new StoreplaceCondition();				
	private String id;
    private List ids;
    private List<Storageinfo> storagelist; 
    private String curselected;
	//分页
	public String pagedQuery() {
		try {
			currentPage = storeplaceService.pagedQuery(this.getCondition());
			this.set(getActionName(), condition);
			storagelist=this.getStoragelist();
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("分页异常错误:"+e.getMessage());
			return "errors";
		}
	}



	public String getCurselected() {
		return curselected;
	}



	public void setCurselected(String curselected) {
		this.curselected = curselected;
	}



	public String save() {
		try {
			storeplaceService.saveObj(sp);
			id=sp.getId();
			setTip("保存成功!");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("保存库位信息异常错误:"+e.getMessage());
			return "errors";
		}
		return "save";
	}

	/**
	 * 根据id查询库位信息
	 * 
	 * @return String对象
	 */
	public String queryById() {
		try {
			storagelist=this.getStoragelist();
			sp=storeplaceService.queryById(id);
		
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("查询库位异常错误:"+e.getMessage());
			return "errors";
		}

		return "queryById";
	}
	public void setStoragelist(List<Storageinfo> storagelist) {
		this.storagelist = storagelist;
	}


	/**
	 * 根据ID删除库位信息
	 * @return
	 */
	public String remove(){
		try {
			storeplaceService.remove(ids);
			setTip("删除成功！");
		} catch (Exception e) {
			e.printStackTrace();
			addActionError("删除库位异常错误:"+e.getMessage());
			return "errors";
		}
		return "remove";
	}

	//添加跳转查询 
	public String addQuery(){
		try {
			this.getStoragelist();
			return "queryAdd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	public List <Storageinfo> getStoragelist(){
		return storeplaceService.getStoragelist();
		
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}



	public StoreplaceCondition getCondition() {
		StoreplaceCondition sessionCondition = (StoreplaceCondition)get(getActionName());
		if (sessionCondition != null) {
			condition = sessionCondition;
		}
		return condition;
	}


	public void setCondition(StoreplaceCondition condition) {
		this.condition = condition;
	}


	public List getIds() {
		return ids;
	}


	public void setIds(List ids) {
		this.ids = ids;
	}



	public Storeplace getSp() {
		return sp;
	}



	public void setSp(Storeplace sp) {
		this.sp = sp;
	}



	public IStoreplaceService getStoreplaceService() {
		return storeplaceService;
	}



	public void setStoreplaceService(IStoreplaceService storeplaceService) {
		this.storeplaceService = storeplaceService;
	}

}
