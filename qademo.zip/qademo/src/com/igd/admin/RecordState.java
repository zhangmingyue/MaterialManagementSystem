package com.igd.admin;

public final class RecordState {
	public static final RecordState HISTORY = new RecordState("H","历史记录");
	public static final RecordState NOW = new RecordState("N","当前记录");
	private String id;
	private String name;
	
	private RecordState(String p_id,String p_name){
		this.id = p_id;
		this.name = p_name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String toString() {		
		return this.id;
	}

	public boolean equals(Object obj) {
		if(null!=obj && obj instanceof RecordState){
			if(((RecordState)obj).getId().equals(this.id)) return true;
		}
		return false;
	}	
	
}
