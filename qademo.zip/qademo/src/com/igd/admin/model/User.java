package com.igd.admin.model;

import java.util.Date;


public class User implements java.io.Serializable {

	private String id;				
	private Role role;						//所属角色
	private String userName;				//用户名
	private String password;				//登陆密码
	private String realName;				//真实姓名
	private String identification;			//身份证号
	private String email;                   //邮箱
	private String telephone;               //联系电话
	private String fax;                     //传真
	private Date loginTime;					//登录时间
	private String islogin;					//登录状态(Y:允许登录，N:不允许登录)
	private String state;					//状态
	private String remark;					//备注
	private String changeLogin;
	
	public User() {
		super();
	}
	
	public String getChangeLogin() {
		if("Y".equals(islogin))
			return "允许";
		else
			return "不允许";
	}

	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getIdentification() {
		return identification;
	}
	public void setIdentification(String identification) {
		this.identification = identification;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getIslogin() {
		return islogin;
	}
	public void setIslogin(String islogin) {
		this.islogin = islogin;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
}