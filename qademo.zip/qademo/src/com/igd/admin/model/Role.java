package com.igd.admin.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class Role implements java.io.Serializable {

	private String id;				
	private Dept dept;				        //所属机构
	private String no;						//角色编码
	private String name;					//角色名称
	private String state;                   //状态
	private String remark;					//备注
	
	public Role() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Dept getDept() {
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}