package com.igd.admin.model;



public class Menu implements java.io.Serializable {

	private String id;				
	private String no;						//菜单编号
	private String name;					//菜单名称
	private String linkAddress;				//链接地址
	private int sequence;					//显示顺序
	private String islink;					//是否链接
	private String isAccredit;				//是否授权
	private String remark;					//备注
	
	
	public String getParentMenuNo(String menuNo) throws Exception{
		if(no.equals("") || no.length() < 2) return "1";
		return no.substring(0,no.length() - 2);		
	}
	
	public Menu() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLinkAddress() {
		return linkAddress;
	}
	public void setLinkAddress(String linkAddress) {
		this.linkAddress = linkAddress;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getIslink() {
		return islink;
	}
	public void setIslink(String islink) {
		this.islink = islink;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getIsAccredit() {
		return isAccredit;
	}
	public void setIsAccredit(String isAccredit) {
		this.isAccredit = isAccredit;
	}
	
}