package com.igd.admin.model;



public class RoleMenu implements java.io.Serializable {

	private String id;				
	private String menuId;				//用户名
	private String roleId;				//真实姓名
	
	public RoleMenu() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	
}