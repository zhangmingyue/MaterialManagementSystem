package com.igd.admin.webService;

import com.igd.admin.model.User;
import com.igd.admin.service.ILoginService;

public class LoginRemoteInterface {
	private ILoginService loginService;
	
	public String queryUser(String userName,String password){
		try {
			User user = loginService.userLogin(userName, password);
			if (user != null) 
				return "Y";
			return "N";
		} catch (Exception e) {
			return "E";
		}
	}

	public ILoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;
	}
	
	
}
