package com.igd.admin.condition;

import org.hibernate.Query;

import com.igd.admin.RecordState;
import com.igd.base.pagination.Condition;



public class DeptCondition extends Condition {

	private String parent;
	
	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public String getInitialHql(){
		//查询当前可用单位；
		if(parent!=null && !"".equals(parent))
			return "from Dept as dept where dept.parentCode like :parent and dept.state='" + RecordState.NOW.toString() + "'"  ;
		else
			return "from Dept as dept where dept.parentCode is null and dept.state='" + RecordState.NOW.toString() + "'"  ;
	}
	
	public Query preparedParams(Query query) {
		if(parent!=null && !"".equals(parent))
			query.setParameter("parent", parent);
		
		return query;
	}	
}