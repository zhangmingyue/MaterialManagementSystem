package com.igd.admin.condition;

import org.hibernate.Query;

import com.igd.admin.RecordState;
import com.igd.base.pagination.Condition;



public class UserCondition extends Condition {

	/**
	 * 
	 */
	
	private String deptId;
	
	private static final long serialVersionUID = -5517704137284488726L;

	public String getInitialHql() {
		 	return "from User as user where user.role.dept.id = :deptId and user.state='" + RecordState.NOW.toString() + "'";
	}
	
	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public Query preparedParams(Query query) {
			query.setParameter("deptId",this.getDeptId());
		return query;
	}

}
