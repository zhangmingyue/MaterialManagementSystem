package com.igd.admin.condition;

import org.hibernate.Query;

import com.igd.admin.RecordState;
import com.igd.base.pagination.Condition;



public class CodeCondition extends Condition {
	
	public String getInitialHql(){
	//	this.setOrderByItem("cc.code asc");
			return "from CodeCategory as cc where cc.state<>'"+RecordState.HISTORY.getId()+"' order by cc.code asc"  ;
	}
	
	public Query preparedParams(Query query) {
		return query;
	}

}