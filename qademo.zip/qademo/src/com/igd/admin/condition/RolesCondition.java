package com.igd.admin.condition;

import org.hibernate.Query;

import com.igd.admin.RecordState;
import com.igd.base.pagination.Condition;



public class RolesCondition extends Condition {

	private String deptId;
	
	private static final long serialVersionUID = -3541357033274345667L;

	public String getInitialHql() {
		return "from Role as r where r.dept.id like :deptId and r.state='" + RecordState.NOW.toString() + "'";
	}
	
	public Query preparedParams(Query query) {
		query.setParameter("deptId", (deptId==null || deptId.trim().equals(""))?"%":this.getDeptId());
		return query;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}	
	
	
}
