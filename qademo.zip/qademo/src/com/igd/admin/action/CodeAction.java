
package com.igd.admin.action;

import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.igd.admin.condition.CodeCondition;
import com.igd.admin.condition.DeptCondition;
import com.igd.admin.model.Code;
import com.igd.admin.model.CodeCategory;
import com.igd.admin.service.ICodeService;
import com.igd.base.action.BaseAction;


public class CodeAction extends BaseAction {
	private ICodeService codeService;
	private CodeCategory codeCategory;
	private Code code;
	private Collection<String> ids = null;
	private List<Code> codeList;
	private String id;
	private String codeId;
	private String codeCategoryId;
	private CodeCondition condition = new CodeCondition();
	private static final Log logger = LogFactory.getLog(CodeAction.class);

	// 查询
	public String pagedQuery() {
		try {
			currentPage = codeService.pagedQuery(this.getCondition());
			this.set(getActionName(), condition);
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	// 保存
	public String save() {
		try {
			codeService.save(codeCategory);
			id = codeCategory.getId();
			//设置提示信息
			setTip("保存成功!");
			return "save";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	// 保存Code
	public String saveCode() {
		try {
			codeService.saveCode(code);
			id = code.getCodeCategory().getId();
			//设置提示信息
			setTip("保存成功!");
			return "saveCode";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	//删除方法
	public String remove() {
		try {
			codeService.remove(ids);
			//设置提示信息
			setTip("删除成功！");
			return "remove";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	public String removeCode(){
		try {
			code = codeService.queryCodeById(codeId);
			codeService.remove(code);
			id = code.getCodeCategory().getId();
			//设置提示信息
			setTip("删除成功！");
			return "removeCode";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	// 根据id加载对象
	public String queryById() {
		try {
			codeCategory = codeService.queryById(id);
			return "queryById";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	// 根据id加载对象
	public String showCode() {
		try {
			codeList = codeService.queryCodeByCcid(id);
			codeCategoryId = id;
			return "showCode";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	public void setCondition(CodeCondition condition) {
		this.condition = condition;
	}

	public CodeCondition getCondition() {
		CodeCondition sessionCondition = (CodeCondition) get(getActionName());
		if (sessionCondition != null)
			condition = sessionCondition;
		return condition;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Collection<String> getIds() {
		return ids;
	}

	public void setIds(Collection<String> ids) {
		this.ids = ids;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

	public CodeCategory getCodeCategory() {
		return codeCategory;
	}

	public void setCodeCategory(CodeCategory codeCategory) {
		this.codeCategory = codeCategory;
	}

	public List<Code> getCodeList() {
		return codeList;
	}

	public void setCodeList(List<Code> codeList) {
		this.codeList = codeList;
	}

	public String getCodeCategoryId() {
		return codeCategoryId;
	}

	public void setCodeCategoryId(String codeCategoryId) {
		this.codeCategoryId = codeCategoryId;
	}

	public Code getCode() {
		return code;
	}

	public void setCode(Code code) {
		this.code = code;
	}

	public String getCodeId() {
		return codeId;
	}

	public void setCodeId(String codeId) {
		this.codeId = codeId;
	}

}