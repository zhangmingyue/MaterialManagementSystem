package com.igd.admin.action;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.igd.admin.model.Dept;
import com.igd.admin.model.User;
import com.igd.admin.service.IDeptService;
import com.igd.admin.service.ILoginService;
import com.igd.base.action.BaseAction;
import com.igd.base.exception.BaseException;
import com.igd.base.utils.date.DateUtil;


public class LoginAction extends BaseAction {
	private String username;
	private String password;
	private String rand; // 随机验证码
	private User user;
	private ILoginService loginService;
	private IDeptService deptService;	
	private int valicue;
	private int retcue;
	
	private static final Log logger = LogFactory.getLog(LoginAction.class);

	//登录
	public String execute(){
		try {
//			if (null == rand
//					|| !rand.equalsIgnoreCase(((String) this.get("rand"))
//							.toLowerCase())) {
//				addActionError("验证码输入错误！");
//				return "errors";
//			} else {
				user = loginService.userLogin(username, password);
				if (user != null) {
					logger.info(user.getUserName() + " 用户登录！时间："+ DateUtil.curDateTime());
					//user存入session
					this.set("user", user);
					//获得部门对象
					Dept dept = deptService.queryDeptByRoleId(user.getRole().getId());
					//dept存入session
					this.set("dept", dept);
					//设置登录时间
					user.setLoginTime(new Date());
					loginService.updatelogintime(user);
					Date date = new Date();
					set("loginTime", DateUtil.getStringCalendarAndWeek());
					
				} else {
					addActionError("用户名或密码错误！");
					return "errors";
				}
			//}
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
		return "success";
	}

	/**
	 * 重新登陆操作执行
	 * 
	 * @return
	 * @throws Exception
	 */
	public String reLogin() throws BaseException {
		try {
			user = (User) this.get("user");
			if (user != null)
				logger.info(user.getUserName() + " 用户退出系统！时间："
						+ DateUtil.curDateTime());
			this.clearSession();
			return "reLogin";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}

	public void getCueCount() throws Exception{
		user=(User) this.get("user");

		System.out.println("效期提醒数量***************"+valicue);
		System.out.println("复检提醒数量***************"+retcue);
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public ILoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getRand() {
		return rand;
	}

	public void setRand(String rand) {
		this.rand = rand;
	}

	public IDeptService getDeptService() {
		return deptService;
	}

	public void setDeptService(IDeptService deptService) {
		this.deptService = deptService;
	}



	public int getValicue() {
		return valicue;
	}

	public void setValicue(int valicue) {
		this.valicue = valicue;
	}

	public int getRetcue() {
		return retcue;
	}

	public void setRetcue(int retcue) {
		this.retcue = retcue;
	}
	
}
