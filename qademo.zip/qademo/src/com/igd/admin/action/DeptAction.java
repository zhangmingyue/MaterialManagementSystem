package com.igd.admin.action;

import java.util.Collection;
import java.util.List;

import com.igd.admin.condition.DeptCondition;
import com.igd.admin.model.Dept;
import com.igd.admin.service.IDeptService;
import com.igd.base.action.BaseAction;


public class DeptAction extends BaseAction {

	private IDeptService deptService;

	private Dept dept;

	private Collection<String> ids = null;

	private String id;
	
	private String parentId;

	private List<Dept> deptTreeList;

	private DeptCondition condition = new DeptCondition();

	public void setCondition(DeptCondition condition) {
		this.condition = condition;
	}

	public DeptCondition getCondition() {
		DeptCondition sessionCondition = (DeptCondition) get(getActionName());
		if (sessionCondition != null)
			condition = sessionCondition;
		return condition;
	}

	public String init() {
		deptTreeList = deptService.list();
		return null;
	}


	public String pagedQuery() {
		try {
			this.init();
			currentPage = deptService.pagedQuery(this.getCondition());
			this.set(getActionName(), condition);
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}


	public String save() {
		try {
			deptService.save(dept);
			
			id = dept.getId();
			//设置提示信息
			setTip("保存成功!");
			return "save";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}

	public String queryById() {
		try {
			dept = deptService.queryById(id);
			if(null == dept.getId() || "".equals(dept.getId()))
				dept.setParentCode(parentId);
			return "queryById";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}

	public String remove() {
		try {
			deptService.remove(ids);
			//设置提示信息
			setTip("删除成功！");
			return "remove";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}

	public List<Dept> getDeptTreeList() {
		return deptTreeList;
	}

	public void setDeptTreeList(List<Dept> deptTreeList) {
		this.deptTreeList = deptTreeList;
	}

	public String execute() throws Exception {
		return this.init();
	}

	public void setDeptService(IDeptService deptService) {
		this.deptService = deptService;
	}

	public IDeptService getDeptService() {
		return this.deptService;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public Dept getDept() {
		return dept;
	}



	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return this.id;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public void setIds(Collection<String> ids) {
		this.ids = ids;
	}

	public Collection<String> getIds() {
		return ids;
	}

}