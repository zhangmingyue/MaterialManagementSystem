package com.igd.admin.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;

import com.igd.admin.condition.UserCondition;
import com.igd.admin.model.Dept;
import com.igd.admin.model.Role;
import com.igd.admin.model.User;
import com.igd.admin.service.IDeptService;
import com.igd.admin.service.IRoleService;
import com.igd.admin.service.IUserService;
import com.igd.base.action.BaseAction;

public class UserAction extends BaseAction {
	
	private String userNo;									//用户编号

	private User user;										//用户对象

	private Collection<String> ids;							//用户集合

	private List<Role> userRoles;							//授权角色集合

	private List<Role> allRoles;							//角色总集合

	private List<User> users;								//用户集合
		
	private String id;										//User对象主键

	private List<Dept> deptTreeList;						//部门列表

	private String deptId;									//部门ID
	
	private String newPassword;								//新密码

	private UserCondition condition = new UserCondition();

	private IUserService userService;

	private IRoleService roleService;
	
	private IDeptService deptService;

	public void init() throws Exception {
		deptTreeList = deptService.list();
		userRoles = roleService.queryByDeptId(condition.getDeptId());
	}
	
	//显示用户集合
	public String pagedQuery() throws Exception {
		try {
			currentPage = userService.pagedQuery(this.getCondition());
			this.init();
			this.set(getActionName(), condition);
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}

	}


	//保存修改的用户对象
	public String save() throws Exception {
		try {
			userService.save(user);
			//设置提示信息
			setTip("保存成功!");
			return "save";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	//修改的用户对象
	public String update() throws Exception {
		try {
			userService.save(user);
			return "update";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}


	/**
	 * 删除用户对象
	 * 
	 * @return
	 * @throws Exception
	 */
	public String remove() throws Exception {
		try {
			userService.removeUser(ids);
			//设置提示信息
			setTip("删除成功！");
			return "remove";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}

	/**
	 * 修改用户密码
	 * @return
	 */
	public String savepwd(){
		try {
			User usertemp = userService.queryById(user.getId());
			if(user.getPassword().equals(usertemp.getPassword())){
				usertemp.setPassword(newPassword);
				userService.save(usertemp);
				this.set("user", usertemp);
				setTip("修改成功!");
			}else{
			throw new Exception("修改失败,旧密码不匹配！" );
			}
			
			return "savepwd";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}
	
	/**
	 * 根据Id查询用户对象
	 * 
	 * @return
	 * @throws Exception
	 */
	public String queryById() throws Exception {
		try {
			userRoles = roleService.queryByDeptId(deptId);
			user = userService.queryById(id);
			return "queryById";
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return "errors";
		}
	}


	public String getUserNo() {
		return userNo;
	}


	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Collection<String> getIds() {
		return ids;
	}


	public void setIds(Collection<String> ids) {
		this.ids = ids;
	}


	public List<Role> getUserRoles() {
		return userRoles;
	}


	public void setUserRoles(List<Role> userRoles) {
		this.userRoles = userRoles;
	}


	public List<Role> getAllRoles() {
		return allRoles;
	}


	public void setAllRoles(List<Role> allRoles) {
		this.allRoles = allRoles;
	}


	public List<User> getUsers() {
		return users;
	}


	public void setUsers(List<User> users) {
		this.users = users;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}

	public List<Dept> getDeptTreeList() {
		return deptTreeList;
	}

	public void setDeptTreeList(List<Dept> deptTreeList) {
		this.deptTreeList = deptTreeList;
	}

	public String getDeptId() {
		return deptId;
	}


	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}


	public UserCondition getCondition() {
		UserCondition sessionCondition = (UserCondition) get(getActionName());
		if (sessionCondition != null)
			condition = sessionCondition;
		return condition;
	}


	public void setCondition(UserCondition condition) {
		this.condition = condition;
	}


	public IUserService getUserService() {
		return userService;
	}


	public void setUserService(IUserService userService) {
		this.userService = userService;
	}


	public IRoleService getRoleService() {
		return roleService;
	}


	public void setRoleService(IRoleService roleService) {
		this.roleService = roleService;
	}

	public IDeptService getDeptService() {
		return deptService;
	}

	public void setDeptService(IDeptService deptService) {
		this.deptService = deptService;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}



	
}
