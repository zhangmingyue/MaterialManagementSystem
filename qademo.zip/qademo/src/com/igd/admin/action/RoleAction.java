package com.igd.admin.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.igd.admin.condition.RolesCondition;
import com.igd.admin.condition.UserCondition;
import com.igd.admin.model.Dept;
import com.igd.admin.model.Menu;
import com.igd.admin.model.Role;
import com.igd.admin.service.IDeptService;
import com.igd.admin.service.IMenuTreeService;
import com.igd.admin.service.IRoleService;
import com.igd.base.action.BaseAction;

public class RoleAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5124879509161152560L;
	
	private RolesCondition condition = new RolesCondition();
	
	private String id;      //角色编号

	private Role role;

	private Collection<String> ids = null;

	private List<Role> roleList = new ArrayList<Role>();

	private List<String> roleMenus = new ArrayList<String>();

	private List<Menu> allMenus = new ArrayList<Menu>();

	private String deptId;
	
	private IRoleService roleService;

	private IMenuTreeService menuTreeService;
	
	private List<Dept> deptTreeList;

	private IDeptService deptService;
	
	public String init() {
		deptTreeList = deptService.list();
		return null;
	}
	
	public String pagedQuery() throws Exception {
		try {
			init();
			currentPage = roleService.pagedQuery(this.getCondition()) ;
			this.set(getActionName(), condition);
			return "pagedQuery";
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError(e.getMessage());
			return "errors";
		}
	}


	public String save() {
		try {
			roleService.save(role);
			//设置提示信息
			setTip("保存成功!");
			return "save";
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError(e.getMessage());
			return "errors";
		}
	}


	public String setRoleMenu() throws Exception {
		try {
			roleService.setRoleMenu(id, roleMenus);
			return "setRoleMenu";
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError(e.getMessage());
			return "errors";
		}
	}


	public String remove() throws Exception {
		try {
			roleService.remove(ids);
			//设置提示信息
			setTip("删除成功！");
			return "remove";
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError(e.getMessage());
			return "errors";
		}
	}


	public String queryById() throws Exception {
		try {
				role = roleService.queryById(id);
				if(null == role.getId() || "".equals(role.getId())){
					Dept d = new Dept();
					d.setId(deptId);
					role.setDept(d);
				}
			return "queryById";
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError(e.getMessage());
			return "errors";
		}
	}


	public String showRoleMenus() throws Exception {
		try {
			allMenus = menuTreeService.accreditMenu(id);
			return "showMenu";
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError(e.getMessage());
			return "errors";
		}
	}
	
	


	public RolesCondition getCondition() {
		RolesCondition sessionCondition = (RolesCondition) get(getActionName());
		if (sessionCondition != null)
			condition = sessionCondition;
		return condition;
	}


	public void setCondition(RolesCondition condition) {
		this.condition = condition;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}


	public Collection<String> getIds() {
		return ids;
	}


	public void setIds(Collection<String> ids) {
		this.ids = ids;
	}


	public List<Role> getRoleList() {
		return roleList;
	}


	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}


	public List<String> getRoleMenus() {
		return roleMenus;
	}


	public void setRoleMenus(List<String> roleMenus) {
		this.roleMenus = roleMenus;
	}


	public List<Menu> getAllMenus() {
		return allMenus;
	}


	public void setAllMenus(List<Menu> allMenus) {
		this.allMenus = allMenus;
	}


	public IRoleService getRoleService() {
		return roleService;
	}


	public void setRoleService(IRoleService roleService) {
		this.roleService = roleService;
	}


	public IMenuTreeService getMenuTreeService() {
		return menuTreeService;
	}


	public void setMenuTreeService(IMenuTreeService menuTreeService) {
		this.menuTreeService = menuTreeService;
	}


	public String getDeptId() {
		return deptId;
	}


	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}


	public List<Dept> getDeptTreeList() {
		return deptTreeList;
	}


	public void setDeptTreeList(List<Dept> deptTreeList) {
		this.deptTreeList = deptTreeList;
	}

	public IDeptService getDeptService() {
		return deptService;
	}

	public void setDeptService(IDeptService deptService) {
		this.deptService = deptService;
	}

	
}
