package com.igd.admin.service;

import java.util.Collection;

import com.igd.admin.model.User;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;

public interface IUserService {
	/**
	 * 添加或更新用户对象
	 * 
	 * @param user
	 * @param deptNo
	 * @return
	 * @throws Exception
	 */
	public void save(User user) throws Exception;

	/**
	 * 查找单个用户对象
	 * 
	 * @param p_userId
	 * @return
	 * @throws Exception
	 */
	public User queryById(String id) throws Exception;
	
	/**
	 * 删除多个用户
	 * 
	 * @param userNos
	 * @throws Exception
	 */
	public void removeUser(Collection<String> ids) throws Exception;
	

	public Page pagedQuery(Condition condition);
	
}
