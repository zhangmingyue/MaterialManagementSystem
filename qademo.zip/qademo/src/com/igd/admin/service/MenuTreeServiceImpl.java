
package com.igd.admin.service;

import java.util.List;

import com.igd.admin.dao.IMenuTreeDao;
import com.igd.admin.model.Menu;
import com.igd.admin.model.RoleMenu;

public class MenuTreeServiceImpl implements IMenuTreeService {
	
	private IMenuTreeDao menuTreeDao;
	
	//通过登录用户获得此用户的权限菜单
	public List<Menu> getAccreditMenu(String rid) throws Exception {
		if(null != rid && !"".equals(rid)){
			return menuTreeDao.getAccreditMenu(rid);
		}else{
			return null;
		}
	}
	//获得所有菜单
	public List<Menu> getAllMenu() throws Exception {
		return menuTreeDao.getAllMenu();
	}
	
	//授权菜单 
	public List<Menu> accreditMenu(String roleId) throws Exception {
		List<Menu> menulist = getAllMenu();
		List<RoleMenu> rmlist = menuTreeDao.queryByRId(roleId);
		for(Menu menu : menulist){
			for(RoleMenu rm :rmlist){
				if (rm.getMenuId().equals(menu.getId())) {
					menu.setIsAccredit("1");
					break;
				}
			}
		}
		return menulist;
	}
	
	public IMenuTreeDao getMenuTreeDao() {
		return menuTreeDao;
	}

	public void setMenuTreeDao(IMenuTreeDao menuTreeDao) {
		this.menuTreeDao = menuTreeDao;
	}

}
