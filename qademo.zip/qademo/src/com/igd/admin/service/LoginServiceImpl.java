package com.igd.admin.service;

import org.apache.log4j.Logger;

import com.igd.admin.dao.ILoginDao;
import com.igd.admin.model.User;

public class LoginServiceImpl implements ILoginService {
	private final Logger logger = Logger.getLogger(LoginServiceImpl.class);
	private ILoginDao loginDao;
	//修改密码
	public void changepwd(User user) throws Exception {
		loginDao.updateObject("password", user);

	}
	//修改登录时间
	public void updatelogintime(User user) throws Exception {
		loginDao.updateObject("user", user);

	}
	//通过用户名，密码查找用户
	public User userLogin(String userName, String password) throws Exception {
		User user = loginDao.userLogin(userName, password);
		return user;

	}

	public ILoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}
}
