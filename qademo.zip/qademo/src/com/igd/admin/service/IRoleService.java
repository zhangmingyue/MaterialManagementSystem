
package com.igd.admin.service;

import java.util.Collection;
import java.util.List;

import com.igd.admin.model.Role;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;

public interface IRoleService {
	/**
	 * 显示角色列表
	 * 
	 * @return
	 * @throws Exception
	 */
	public List showRoleList() throws Exception;

	/**
	 * 添加或更新角色对象
	 * 
	 * @param role
	 * @return
	 * @throws Exception
	 */
	public void save(Role role) throws Exception;

	/**
	 * 查找单个角色对象
	 * 
	 * @param roleNo
	 * @return
	 * @throws Exception
	 */
	public Role queryById(String roleNo) throws Exception;


	/**
	 * 删除多个角色
	 * 
	 * @param roleNos
	 * @throws Exception
	 */
	public void remove(Collection<String> ids) throws Exception;
	
	/**
	 * 设置角色授权
	 * @param roleNo
	 * @param sysMenuNos
	 * @throws Exception
	 */
	public void setRoleMenu(String roleNo,Collection<String> sysMenuNos) throws Exception;
	/**
	 * 通过部门ID查询些部门下所有角色
	 * @param deptId 部门ID
	 * @return 角色列表
	 * @throws Exception
	 */
	public List<Role> queryByDeptId(String deptId)throws Exception;
	
	public Page pagedQuery(Condition conditon);
}
