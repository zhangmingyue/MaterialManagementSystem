package com.igd.admin.service;

import java.util.Collection;

import com.igd.admin.RecordState;
import com.igd.admin.dao.IUserDao;
import com.igd.admin.model.User;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;

public class UserServiceImpl implements IUserService {
	private IUserDao userDao;

	public IUserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}

	public void save(User user) throws Exception {
		try {
			
			if (user.getRole().getId() == null || user.getRole().getId().equals(""))
				throw new Exception("请选择角色名称" );
			if(user.getId() == null || user.getId().equals("")){
				if (userDao.CheckRepeatUserId(user.getUserName(), null,user.getRole().getId()))
					throw new Exception("登录名称'" + user.getUserName()+ "'已经存在,请重新对登录名称命名!");
			
				user.setState(RecordState.NOW.getId());
				userDao.save(user);	
			}
			if(user.getId() != null || ! user.getId().equals("")){
				if (userDao.CheckRepeatUserId(user.getUserName(), user.getId(),user.getRole().getId()))
					throw new Exception("登录名称'" + user.getUserName()+ "'已经存在,请重新对登录名称命名!");
			userDao.saveOrUpdate(user);}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("用户保存错误：" + e.getMessage());
		}
	}

	public User queryById(String id) throws Exception {
		try {
			Object obj = userDao.loadById(User.class, id);
			if (obj == null) {
				return new User();
			}
			return (User) obj;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("用户对象加载异常错误：" + e.getMessage());
		}
	}


	public void removeUser(Collection<String> ids) throws Exception {
		try {
			for(String id : ids){
				if (id != null && !id.equals("")) {
					User user = this.queryById(id);
					user.setState(RecordState.HISTORY.getId());
					//userDao.delete(user);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("用户删除异常错误：" + e.getMessage());
		}
	}


	public Page pagedQuery( Condition condition) {
		return userDao.pagedQuery(condition);
	}
}
