
package com.igd.admin.service;

import java.util.Collection;
import java.util.List;

import com.igd.admin.model.Code;
import com.igd.admin.model.CodeCategory;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;



 
public interface ICodeService{

	public Page pagedQuery(Condition condition);
	
	public void save(CodeCategory cc) throws Exception;
	
	public void saveCode(Code code)throws Exception;

	public void remove(Collection<String> ids) throws Exception;
	
	public void remove(Code code) throws Exception;
	
	public CodeCategory queryById(String id )throws Exception;
	
	public Code queryCodeById(String cid )throws Exception;
	
	public List<Code> queryCodeByCcid(String ccid)throws Exception;
	
	/**
	 * 根据代码编号 查询
	 * @param code 代码编号
	 * @return     代码表
	 * @throws Exception
	 */
	public List<Code> queryByCode(String code) throws Exception;
	/**
	 * 根据代码编号 长度查询
	 * @param code  代码编号
	 * @param len 长度
	 * @return 代码表
	 * @throws Exception
	 */
	public List<Code> queryByCodeLength(String code,int len) throws Exception;
	/**
	 * 根据代码编号 模糊查询
	 * 
	 * @param code 代码编号
	 * @return 代码表
	 * @throws Exception
	 */
	public List<Code> queryLikeCode(String code) throws Exception;

	/**
	 * 根据代码编号 查询一条记录
	 * @param code 代码编号
	 * @return     代码表
	 * @throws Exception
	 */
	public Code queryCodeByTypeCode(String typeCode)throws Exception;
	
	/**
	 * googleMap异步调用 codeArea区List并拼接成
	 * @return String对象拼接好的Select代码
	 */
	public String inintArea();
	
	
	
	
	
	
}