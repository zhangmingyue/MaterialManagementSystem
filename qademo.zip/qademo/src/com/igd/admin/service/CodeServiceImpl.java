package com.igd.admin.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.igd.admin.RecordState;
import com.igd.admin.dao.ICodeDao;
import com.igd.admin.model.Code;
import com.igd.admin.model.CodeCategory;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;

public class CodeServiceImpl implements ICodeService {

	private ICodeDao codeDao;

	public void save(CodeCategory cc) throws Exception {

		if (codeDao.checkCodeCategoryRepeatCode(cc.getId(), cc.getCode()) > 0)
			throw new Exception("编号：" + cc.getCode() + "已经存在,请重新输入！");
		if (cc.getId() == null || "".equals(cc.getId())) {
			cc.setState(RecordState.NOW.getId());
			codeDao.save(cc);
			return;
		}
		codeDao.saveOrUpdate(cc);
	}
	
	@Override
	public void saveCode(Code code) throws Exception {
		if (codeDao.checkCodeRepeatCode(code.getId(), code.getCode(),code.getCodeCategory().getId()) > 0)
			throw new Exception("编号：" + code.getCode() + "已经存在,请重新输入！");
		if (code.getId() == null || "".equals(code.getId())) {
			code.setState(RecordState.NOW.getId());
			codeDao.save(code);
			return;
		}
		codeDao.saveOrUpdate(code);
		
	}

	public void remove(Collection<String> ids) throws Exception {
		List<CodeCategory> lst = new ArrayList<CodeCategory>();
		CodeCategory cc;
		for (String id : ids) {
			if (id != null && !id.equals("")) {
				cc = (CodeCategory) queryById(id); 
				if (cc != null && cc.getId() != null)
					cc.setState(RecordState.HISTORY.getId());// 删除标志
				codeDao.saveOrUpdate(cc);
			}
		} 
	}
	
	@Override
	public void remove(Code code) throws Exception {
		if(null != code.getId() && !"".equals(code.getId())){
			code.setState(RecordState.HISTORY.getId());
			codeDao.saveOrUpdate(code);
		}
		
	}

	public CodeCategory queryById(String id) {
		if (id == null || "".equals(id)) {
			CodeCategory cc = new CodeCategory();
			return cc;
		} else {
			return codeDao.queryById(id);
		}
	}
	
	@Override
	public Code queryCodeById(String cid) throws Exception {
		if(null != cid && !"".equals(cid)){
			return codeDao.queryCodeById(cid);
		}
		return null;
	}
	
	/**
	 * 根据代码编号 查询
	 * @param code 代码编号
	 * @return     代码表
	 * @throws Exception
	 */
	@Override
	public List<Code> queryByCode(String code) throws Exception {
		if (null!=code &&!"".equals(code)) {
			CodeCategory co=codeDao.queryByCode(code);
			if(null!=co &&!"".equals(code)){
			List<Code>	list=codeDao.queryCodeByCcid(co.getId());
			return list;
			}
		}
		return null;
	}
	
	@Override
	public List<Code> queryCodeByCcid(String ccid) throws Exception {
		return codeDao.queryCodeByCcid(ccid);
	}
	
	@Override
	public List<Code> queryByCodeLength(String code,int len) throws Exception {
		if (null!=code &&!"".equals(code)) {
			CodeCategory co=codeDao.queryByCode(code);
			if(null!=co &&!"".equals(code)){
			List<Code>	list=codeDao.queryCodeByLen(co.getId(),len);
			return list;
			}
		}
		return null;
	}
	
	@Override
	public List<Code> queryLikeCode(String code) throws Exception {
		List<Code>	list=new ArrayList<Code>();
		if (null!=code&&!"".equals(code)) {
			Code co=codeDao.queryCode(code);
			if(null!=co &&!"".equals(co)){
		    list=codeDao.queryLikeCode(co.getCodeCategory().getId(),co.getCode());
			return list;
			}
		}
		return list;
	}


	@Override
	public Code queryCodeByTypeCode(String typeCode) throws Exception {
		return codeDao.queryCodeTypeCode(typeCode);
	}
	
	/**
	 * 异步调用 codeArea区List并拼接成
	 * @return String对象拼接好的Select代码
	 */
	public String inintArea(){
		 List<Code> areaCode = new ArrayList<Code>();     
			StringBuffer bf=new StringBuffer("<option value=''>全部</option>");//区
		try {
			areaCode = (List<Code>)this.queryByCodeLength("areaCode", 6);
			for(Code temp:areaCode){
				bf.append("<option value="+temp.getCode()+">"+temp.getName()+"</option>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bf.toString();
	}
	
	
	public Page pagedQuery(Condition condition) {
		return codeDao.pagedQuery(condition);
	}

	public ICodeDao getCodeDao() {
		return codeDao;
	}

	public void setCodeDao(ICodeDao codeDao) {
		this.codeDao = codeDao;
	}


}