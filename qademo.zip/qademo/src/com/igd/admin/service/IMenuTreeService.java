
package com.igd.admin.service;

import java.util.List;

import com.igd.admin.model.Menu;

public interface IMenuTreeService {
	/**
	 * 通过登录用户获得此用户的权限菜单
	 * @param role_id 
	 * @return 菜单列表
	 * @throws Exception
	 */
	public List<Menu> getAccreditMenu(String rid) throws Exception;
	
	/**
	 * 获得所有菜单
	 * @return 菜单列表
	 * @throws Exception
	 */
	public List<Menu> getAllMenu() throws Exception;
	
	public List<Menu> accreditMenu(String roleId)throws Exception;
}
