package com.igd.admin.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.igd.admin.RecordState;
import com.igd.admin.dao.IDeptDao;
import com.igd.admin.model.Dept;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;


 
public class DeptServiceImpl implements IDeptService{

	private IDeptDao deptDao;


	public IDeptDao getDeptDao() {
		return deptDao;
	}

	public void setDeptDao (IDeptDao  deptDao) {
		this.deptDao = deptDao;
	}

	public void save(Dept dept) throws Exception{
		if (deptDao.checkDeptNameList(dept.getParentCode(), dept.getId(),dept.getName()) =="false")
		throw new Exception("部门：" + dept.getName() + "已经存在,请重新输入！");
		dept.setState(RecordState.NOW.getId());	//设置机构默认状态；
		if(dept.getParentCode()!=null && dept.getParentCode().equals(""))
			dept.setParentCode(null);
		if(dept.getId()== null||"".equals(dept.getId())){
			dept.setCode(deptDao.generator(dept.getParentCode(),3));
			deptDao.save(dept);
			return;
		}
		deptDao.saveOrUpdate(dept);
	}

	public Dept queryById(Serializable id ){
		if(null == id || "".equals(id))
			return new Dept();
		Object obj = deptDao.loadById(Dept.class, id);
		if (obj == null) {
			return new Dept();
		}
		return (Dept) obj;
	}

	public void remove(Collection ids) throws Exception{
		//	List lst = new ArrayList();
			Dept dept;
			for (Iterator it = ids.iterator(); it.hasNext();) {
				String id = (String) it.next();
				if (id != null && !id.equals("")) {
					dept = (Dept)queryById(id);
					List deptChildren = deptDao.getChildDept(dept.getCode());
					if(deptChildren!=null && deptChildren.size()>0)
						throw new Exception("请先删除相关子部门！");
					int roleNum = deptDao.countRoleByDeptId(id);
					if(roleNum > 0)
						throw new Exception("请先删除部门角色！");					
					dept.setState(RecordState.HISTORY.getId());
				}
			}
	}
	
	/**
	 * 根据给定 CommonCodeId 和  CategoryCodeId 查询  部门表 
	 * @param CommonCodeId 		CategoryCodeID;
	 * @param CategoryCodeId 	 CategoryCodeId;
	 * @return List<Dept>
	 */
	public List<Dept> queryList(String CommonCodeId,String CategoryCodeId)throws Exception{
		return (List<Dept>)deptDao.queryList(CommonCodeId,CategoryCodeId);
	}
	public Page pagedQuery(Condition condition){
		return deptDao.pagedQuery(condition);
	}
	
	public Page lastOfPagedQuery(Condition condition){
		return deptDao.lastOfPagedQuery(condition);
	}

	public List<Dept> list() {
		return this.deptDao.list();
	}

	@Override
	public Dept queryDeptByRoleId(String roleId) throws Exception {
		// TODO Auto-generated method stub
		return deptDao.queryDeptByRoleId(roleId);
	}

	

}