
package com.igd.admin.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import com.igd.admin.model.Dept;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;
 
public interface IDeptService{

	public Page pagedQuery(Condition condition);
	
	public Page lastOfPagedQuery(Condition condition);

	public void save(Dept dept) throws Exception;

	public Dept queryById(Serializable id ) ;

	public void remove(Collection ids) throws Exception;
	
	public List<Dept> list();
	
	public Dept queryDeptByRoleId(String userId)throws Exception;
	
	/**
	 * 根据给定 CommonCodeId 和  CategoryCodeId 查询  部门表 
	 * @param CommonCodeId 		CategoryCodeID;
	 * @param CategoryCodeId 	 CategoryCodeId;
	 * @return List<Dept>
	 */
	public List<Dept> queryList(String CommonCodeId,String CategoryCodeId)throws Exception;
}