package com.igd.admin.service;

import com.igd.admin.model.User;

public interface ILoginService {
	/**
	 * 通过用户名，密码查找用户
	 * 
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @return User（User类）
	 */
	public User userLogin(String userName,String password)throws Exception;
	/**
	 * 修改密码
	 * 
	 * @param admin
	 *            用户类
	 */
	public void changepwd(User user)throws Exception;

	/**
	 * 修改登录时间
	 * 
	 * @param admin
	 *            用户类
	 */
	public void updatelogintime(User user)throws Exception;
}
