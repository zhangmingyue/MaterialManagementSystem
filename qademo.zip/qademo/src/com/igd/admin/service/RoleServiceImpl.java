
package com.igd.admin.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.igd.admin.RecordState;
import com.igd.admin.dao.IRoleDao;
import com.igd.admin.model.Role;
import com.igd.admin.model.RoleMenu;
import com.igd.base.pagination.Condition;
import com.igd.base.pagination.Page;






/**
 * @author Administrator
 * 
 */
public class RoleServiceImpl implements IRoleService {
	private IRoleDao roleDao;

	public IRoleDao getRoleDao() {
		return roleDao;
	}

	public void setRoleDao(IRoleDao roleDao) {
		this.roleDao = roleDao;
	}


	public List showRoleList() throws Exception {
		try {
			return roleDao.listRole();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("角色查询异常错误：" + e.getMessage());
		}
	}


	public void save(Role role) throws Exception {
		try {
			if(role.getId()== null || "".equals(role.getId())){
			if (roleDao.checkRepeatRoleName(role.getName(), role.getId()))
				throw new Exception("角色名称'" + role.getName() + "'已经存在,请重新对角色命名!");
			
				role.setState(RecordState.NOW.getId());
				roleDao.save(role);
			}else{
				if(role.getId()!= null|| !"".equals(role.getId())){
					if (roleDao.checkRepeatRoleName(role.getName(), role.getId()))
						throw new Exception("角色名称'" + role.getName() + "'已经存在,请重新对角色命名!");
					role.setState(RecordState.NOW.getId());
			roleDao.saveOrUpdate(role);}
			} 
			}catch (Exception e) {
			e.printStackTrace();
			throw new Exception("角色保存错误：" + e.getMessage());
		}
	}


	public Role queryById(String id) throws Exception {
		try {
			if(null == id || "".equals(id)) 
				return new Role();
			Object obj = roleDao.loadById(Role.class, id);
			if (obj == null) {
				return new Role();
			}
			return (Role) obj;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("角色对象加载异常错误!");
		}
	}

	public void remove(Collection<String> ids) throws Exception {
	
			List<Role> lst = new ArrayList<Role>();
			for(String id : ids){
				if(null !=id && !"".equals(id)){
					Role r = this.queryById(id);
					if(roleDao.countRoleMenuByRid(r.getId())>0){
						throw new Exception("请先删除角色的授权菜单！");
					}
					if (roleDao.countUserByRid(r.getId())>0){
						throw new Exception("请先删除角色的用户！");
					}
					r.setState(RecordState.HISTORY.getId());
				//	lst.add(r);
				}
			}
		//	roleDao.deleteObjects(lst);
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.olive.sys.service.Role#setRoleMenu(java.lang.String,
	 *      java.util.Collection)
	 */
	public void setRoleMenu(String id, Collection<String> sysMenuNos)
			throws Exception {
		try {
			Role role = (Role) roleDao.loadById(Role.class, id);
			if(null != role.getId() && !"".equals(role.getId())){
				List<RoleMenu> rmlist = roleDao.queryRoleMenus(role.getId());
				if(null != rmlist && rmlist.size()>0){
					roleDao.deleteObjects(rmlist);
				}
				for (String mid : sysMenuNos) {
					if (null != mid && !"".equals(mid)) {
						RoleMenu rm = new RoleMenu();
						rm.setMenuId(mid);
						rm.setRoleId(role.getId());
						roleDao.save(rm);
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("角色授权错误：" + e.getMessage());
		}

	}
	
	public Page pagedQuery(Condition conditon) {
		return roleDao.pagedQuery(conditon);
	}

	@Override
	public List<Role> queryByDeptId(String deptId) throws Exception {
		// TODO Auto-generated method stub
		return roleDao.queryByDeptId(deptId);
	}

}
