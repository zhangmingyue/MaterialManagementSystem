package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.model.Menu;
import com.igd.admin.model.RoleMenu;
import com.igd.base.dao.BaseDaoImpl;


public class MenuTreeDaoImpl extends BaseDaoImpl implements IMenuTreeDao {
	
	//返回登录用户所属角色中的菜单
	public List<Menu> getAccreditMenu(String roleId) throws Exception {
		List<Menu> list =this.query("select m from RoleMenu as rm,Menu as m where rm.roleId='"+roleId+"' and rm.menuId = m.id order by m.sequence asc");
		return list;
	}
	//返回全部菜单
	public List<Menu> getAllMenu() throws Exception {
		return this.query("from Menu as menu order by menu.sequence asc");
	}
	@Override
	public List<RoleMenu> queryByRId(String roleId) throws Exception {
		List<RoleMenu> list =this.query("from RoleMenu as rm where rm.roleId='"+roleId+"'");
		return list;
	}

}
