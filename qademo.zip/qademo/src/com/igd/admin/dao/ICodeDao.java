package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.model.Code;
import com.igd.admin.model.CodeCategory;
import com.igd.base.dao.IBaseDao;

public interface ICodeDao extends IBaseDao { 
	
	public CodeCategory queryById(String id);
	
	public Code queryCodeById(String id);
	/**
	 * 判断编号是否重复
	 * @param id 主键
	 * @param code 编号
	 * @return 相同编号的个数 
	 */
	public int checkCodeCategoryRepeatCode(String id,String code);
	/**
	 * 判断编号是否重复
	 * @param id 主键
	 * @param code 编号
	 * @return 相同编号的个数 
	 */
	public int checkCodeRepeatCode(String id,String code,String ccid);
	
	public List<Code> queryCodeByCcid(String ccid);
	/**
	 * 根据代码编号 查询
	 * @param code 代码编号
	 * @return  CodeCategory   码基础表
	 * @throws Exception
	 */
	public CodeCategory queryByCode(String code);
	
	public List<Code> queryCodeByLen(String ccid,int len);
	
	public List<Code> queryLikeCode(String ccid,String code);
	public Code queryCode(String code);
	public Code queryCodeTypeCode(String typeCode);
	
	
}