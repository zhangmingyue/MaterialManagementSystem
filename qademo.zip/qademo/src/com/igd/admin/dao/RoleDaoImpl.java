package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.RecordState;
import com.igd.admin.model.Role;
import com.igd.admin.model.RoleMenu;
import com.igd.base.dao.BaseDaoImpl;

public class RoleDaoImpl extends BaseDaoImpl implements IRoleDao {

	public boolean checkRepeatRoleName(String name, String id) throws Exception {
		String queryHql = null;
		if(id == null || id.equals("")) {
			queryHql ="from Role as role where role.name='"
				+ name + 
				 "' and role.state='" + RecordState.NOW.toString() + "'";
		}else {
			queryHql ="from Role as role where role.name='"
				+ name + "' and role.id <> '"
				+ id + "'and role.state='" + RecordState.NOW.toString() + "'";
		}
		return this.checkRepeatObject(queryHql);
	}

	public List listRole() {
		return this.query("from Role as role where role.id<>'001' order by id asc");
	}

	public String generateRoleLevelCode()  throws Exception {
		String genStr = "select max(role.id) from Role as role";
		return this.generator(1, "2", "", genStr);
	}

	@Override
	public List<RoleMenu> queryRoleMenus(String rid) {
		String hql="from RoleMenu as roleMenu  where roleMenu.roleId like '"+rid+"'";
		return this.query(hql);
	}

	@Override
	public int countRoleMenuByRid(String rid) {
		String hql="select count(roleMenu.id) from RoleMenu as roleMenu  where roleMenu.roleId like '"+rid+"'";
		return this.countQuery(hql);
	}

	@Override
	public List<Role> queryByDeptId(String deptId) {
		String hql="from Role as r  where r.dept.id like '"+deptId+"'" + "and r.state='" + RecordState.NOW.toString() + "'";
		return this.query(hql);
	}

	
	public boolean checkRepeatRoleCode(String roleName, String id)
			throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	public int countUserByRid(String rid) {
		String hql="select count(user.id) from User as user  where user.role.id like '"+rid+"' and user.state='" + RecordState.NOW.toString() +"'";
		return this.countQuery(hql);
	}
	
	

	
}
