package com.igd.admin.dao;


import java.util.List;

import com.igd.admin.RecordState;
import com.igd.admin.model.Dept;
import com.igd.base.dao.BaseDaoImpl;
import com.igd.base.utils.LevelCodeGenerator;

public class DeptDaoImpl extends BaseDaoImpl implements IDeptDao {

	public List<Dept> list() {
		String hql = "from Dept as dept where dept.state='" + RecordState.NOW.toString() + "'";
		return this.query(hql);
	}

	public String generator(String parent, int levelLength) throws Exception {
		String hql;
		if(parent ==null || "".equals(parent))
			hql = "select max(dept.code) from Dept as dept where dept.parentCode is null";
		else
			hql = "select max(dept.code) from Dept as dept where dept.parentCode='" + parent +"'";
		List lst = this.query(hql);	
		if(parent==null) parent="";
		return  LevelCodeGenerator.getNonRepeatedSequenceNumber_(lst, parent, levelLength);		
	}

	public List getChildDept(String parentId) {
		String hql = "from Dept as dept where dept.parentCode='" + parentId + "' and dept.state='" + RecordState.NOW.toString() + "'" ;
		return this.query(hql);
	}

	
	public String checkDeptNameList(String parent,String id , String name)
	{   
		String hql;
		if(parent ==null || "".equals(parent))
			 hql = "from Dept as d where d.id <> '"+id+"' and d.name = '"+name+"' and d.parentCode is null and d.state='" + RecordState.NOW.toString() + "'";	
			else
			 hql = "from Dept as d where d.id <> '"+id+"' and d.name = '"+name+"' and d.parentCode = '"+parent+"' and d.state='" + RecordState.NOW.toString() + "'";
		if(this.query(hql).size()>0)
		{
			return "false";
			
		}else
		{
			return "true";
		}
	}

	public String checkDeptNameEdit(String parent,String name)
	{
		String hql = "from Dept as d where d.name = '"+name+"'  and d.parentCode = '"+parent+"'";
		if(this.query(hql).size()>0)
		{
			return "false";
		}else
		{
			return "true";
		}
 
	}
	

	@Override
	public int countRoleByDeptId(String deptId) {
		String hql = "select count(r.id) from Role as r where r.dept.id = '" + deptId + "'";
		return this.countQuery(hql);
	}

	@Override
	public Dept queryDeptByRoleId(String roleId) {
		String hql="select r.dept from Role as r where r.id = '"+roleId+"' and r.state='" + RecordState.NOW.toString() + "'";
		return (Dept)this.loadObject(hql);
	}

	/**
	 * 根据给定 CommonCodeId 和  CategoryCodeId 查询  部门表 
	 * @param CommonCodeId 		CategoryCodeID;
	 * @param CategoryCodeId 	 CategoryCodeId;
	 * @return List<Dept>
	 */
	public List<Dept> queryList(String commonCodeId, String categoryCodeId){
		String hql="from Dept as dpt where dpt.commonCode='"+commonCodeId+"' and dpt.categoryCode='"+categoryCodeId+"' and dpt.parentCode is not NULL and dpt.state='N' " ;
		return (List<Dept>)this.query(hql);
	}
	
}