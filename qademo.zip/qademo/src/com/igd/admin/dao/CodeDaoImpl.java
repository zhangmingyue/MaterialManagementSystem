package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.RecordState;
import com.igd.admin.model.Code;
import com.igd.admin.model.CodeCategory;
import com.igd.base.dao.BaseDaoImpl;


public class CodeDaoImpl extends BaseDaoImpl implements ICodeDao {

	public CodeCategory queryById(String id) {
		return (CodeCategory)this.loadById(CodeCategory.class, id);
	}

	@Override
	public Code queryCodeById(String id) {
		return (Code)this.loadById(Code.class, id);
	}
	
	@Override
	public int checkCodeCategoryRepeatCode(String id, String code) {
		String hql="select count(cc.id) from CodeCategory as cc where  cc.code = '"+code+"' and cc.state = '"+RecordState.NOW.toString()+"'";
		if(null!=id && !"".equals(id))
			hql+=" and  cc.id <> '"+id+"'";
		return this.countQuery(hql);
	}


	@Override
	public int checkCodeRepeatCode(String id, String code,String ccid) {
		String hql="select count(c.id) from Code as c where  c.codeCategory.id = '"+ccid+"' and c.code = '"+code+"' and c.state = '"+RecordState.NOW.toString()+"'";
		if(id!=null && !"".equals(id))
			hql+=" and  c.id <> '"+id+"'";
		return this.countQuery(hql);
	}


	@Override
	public List<Code> queryCodeByCcid(String ccid) {
		String hql = "from Code as code where code.codeCategory.id ='"+ccid+"' and code.state = '"+RecordState.NOW.toString()+"' order by code.code asc";
		return this.query(hql);
	}

	@Override
	public CodeCategory queryByCode(String code) {
		String hql = "from CodeCategory as cc where cc.code ='"+code+"' and cc.state = '"+RecordState.NOW.toString()+"'";
		return (CodeCategory) this.loadObject(hql);
	}

	@Override
	public List<Code> queryCodeByLen(String ccid, int len) {
		String hql = "from Code as code where code.codeCategory.id ='"+ccid+"' and code.state = '"+RecordState.NOW.toString()+"' and length(code.code)="+len;
		return this.query(hql);
	}

	@Override
	public List<Code> queryLikeCode(String ccid, String code) {
		String hql = "from Code as code where code.codeCategory.id ='"+ccid+"' and code.state = '"+RecordState.NOW.toString()+"' and code.code like '"+code+"%' and code.code!='"+code+"'";
		return this.query(hql);
	}

	@Override
	public Code queryCode(String code) {
		String hql = "from Code as cc where cc.code ='"+code+"' and cc.state = '"+RecordState.NOW.toString()+"'";
		return (Code) this.loadObject(hql);
	}

	@Override
	public Code queryCodeTypeCode(String typeCode) {
		String hql ="from Code as cc where cc.code='"+typeCode+"'";
		return (Code) this.loadObject(hql);
	}
	

}