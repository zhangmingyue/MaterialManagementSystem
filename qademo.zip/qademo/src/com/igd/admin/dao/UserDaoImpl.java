package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.RecordState;
import com.igd.base.dao.BaseDaoImpl;

public class UserDaoImpl extends BaseDaoImpl implements IUserDao {
	

	public boolean CheckRepeatUserId(String userName, String id,String rId) {
		String queryHql;
		if(id == null || id.equals("")) {
			queryHql = "from User as user where user.userName='"+ userName + "' and user.role.id='" + rId + "' and user.state='" + RecordState.NOW.toString() + "'";			
		}else{			
			queryHql = "from User as user where user.userName='"
				+ userName + "' and user.id <> '"
				+ id+ "' and user.role.id='" + rId + "' and user.state='" + RecordState.NOW.toString() + "'";
		}
		return this.checkRepeatObject(queryHql);
	}

	public List queryUserByUserName(String userName) {
		return this.query("from User as user where user.userName='"+ userName + "'");
	}
}
