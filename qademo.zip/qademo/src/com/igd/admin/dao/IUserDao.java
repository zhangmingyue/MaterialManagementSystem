package com.igd.admin.dao;

import java.util.List;

import com.igd.base.dao.IBaseDao;

public interface IUserDao extends IBaseDao{
	public boolean CheckRepeatUserId(String userName,String id,String rId);
	public List  queryUserByUserName(String loginId);
}
