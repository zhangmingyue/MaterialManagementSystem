package com.igd.admin.dao;

import com.igd.admin.model.User;
import com.igd.base.dao.IBaseDao;

public interface ILoginDao extends IBaseDao{
	/**
	 * 通过用户名，密码查找用户
	 * @param userName 用户名
	 * @param password 密码
	 * @return 用户对象
	 */
	public User userLogin(String userName,String password);
}
