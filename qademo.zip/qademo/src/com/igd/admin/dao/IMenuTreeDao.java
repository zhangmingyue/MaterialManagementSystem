package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.model.Menu;
import com.igd.admin.model.RoleMenu;
import com.igd.base.dao.IBaseDao;



public interface IMenuTreeDao extends IBaseDao {
	/**
	 * 返回登录用户所属角色中的菜单
	 * @param userId 用户ID
	 * @return 菜单列表
	 * @throws Exception
	 */
	public List<Menu> getAccreditMenu(String roleId) throws Exception;
	/**
	 * 返回全部菜单
	 * @return 菜单列表
	 * @throws Exception
	 */
	public List<Menu> getAllMenu() throws Exception ;
	
	public List<RoleMenu> queryByRId(String roleId)throws Exception;
}
