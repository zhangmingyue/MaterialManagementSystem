package com.igd.admin.dao;

import com.igd.admin.RecordState;
import com.igd.admin.model.User;
import com.igd.base.dao.BaseDaoImpl;
		
public class LoginDaoImpl extends BaseDaoImpl implements ILoginDao {
	//通过用户名，密码查找用户
	public User userLogin(String userName,String password){
		String[] param = new String[] { userName, password ,RecordState.NOW.getId()};
		String hql = "from User as user where user.userName=? and user.password=? and user.state = ? and user.islogin = 'Y' ";
		return (User)this.loadObject(hql, param);
	}
}
