package com.igd.admin.dao;

import java.util.List;

import com.igd.admin.model.Role;
import com.igd.admin.model.RoleMenu;
import com.igd.base.dao.IBaseDao;



public interface IRoleDao extends IBaseDao {
	
	public List    listRole();
	public boolean checkRepeatRoleName(String roleName,String id) throws Exception;
	public boolean checkRepeatRoleCode(String roleName,String id) throws Exception;
	public String  generateRoleLevelCode() throws Exception;
	public List<RoleMenu> queryRoleMenus(String rid);
	public int countRoleMenuByRid(String rid);
	
	/**
	 * 通过部门ID查询些部门下所有角色
	 * @param deptId 部门ID
	 * @return 角色列表
	 * @throws Exception
	 */
	public List<Role> queryByDeptId(String deptId);
	public int countUserByRid(String id);

}
