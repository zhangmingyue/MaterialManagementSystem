package com.igd.admin.dao;


import java.util.List;

import com.igd.admin.model.Dept;
import com.igd.base.dao.IBaseDao;

public interface IDeptDao extends IBaseDao { 
	public List<Dept> list();
	public String generator(String parent,int levelLength)throws Exception ;
	public List<Dept> getChildDept(String parentId);
	public int countRoleByDeptId(String deptId);
	public String	checkDeptNameList(String parent, String id , String name);
	public String 	checkDeptNameEdit(String parent,String name);
	public Dept queryDeptByRoleId(String roleId);
	/**
	 * 根据给定 CommonCodeId 和  CategoryCodeId 查询  部门表 
	 * @param CommonCodeId 		CategoryCodeID;
	 * @param CategoryCodeId 	 CategoryCodeId;
	 * @return List<Dept>
	 */
	public List<Dept> queryList(String commonCodeId, String categoryCodeId);
}